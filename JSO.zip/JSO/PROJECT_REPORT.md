# 💎 Project Report: Jewellery Shop Management System

**Project Name:** JSO (Jewellery Shop Online)  
**Date:** 2025-12-19  
**Technology:** PHP, MySQL, HTML5, CSS3, JavaScript

---

## 📑 Table of Contents

| Chapter | Title |
|:---:|:---|
| **1** | **Introduction** |
| 1.1 | Abstract |
| 1.2 | Existing System and Need for System |
| 1.3 | Scope of System |
| 1.4 | Operating Environment |
| 1.5 | Brief Description of Technology Used |
| **2** | **Proposed System** |
| 2.1 | Study of Similar Systems |
| 2.2 | Objectives of Proposed System |
| 2.3 | Users of System |
| **3** | **Analysis and Design** |
| 3.1 | System Requirements |
| 3.2 | Entity Relationship Diagram (ERD) |
| 3.3 | Table Structure |
| 3.4 | Use Case Diagrams |
| 3.5 | Class Diagram |
| 3.6 | Activity Diagram |
| 3.7 | Deployment Diagram |
| 3.8 | Module Hierarchy Diagram |
| 3.9 | Sample Input & Output Screens |
| **4** | **Coding** |
| 4.1 | Algorithms |
| 4.2 | Code Snippets |
| **5** | **Limitations of Proposed System** |
| **6** | **Proposed Enhancements** |
| **7** | **Conclusion** |
| **8** | **Bibliography** |

---

# Chapter 1: Introduction

## 1.1 Abstract
The **Jewellery Shop Management System** is a comprehensive web-based application designed to streamline the operations of a modern jewellery store. It bridges the gap between traditional retail and digital convenience, allowing customers to browse high-quality collections (Gold, Diamond, Platinum, etc.), manage their carts, and place orders securely. For administrators, it provides a robust backend to manage inventory, track orders, and handle customer data.

## 1.2 Existing System and Need for System
**Existing System:**
Many traditional jewellery businesses rely on manual record-keeping or disconnected legacy software. Customers must physically visit stores to view collections, leading to limited reach and convenience. Inventory management is often prone to human error.

**Need for System:**
- **Global Reach:** To allow customers to shop from anywhere, 24/7.
- **Inventory Accuracy:** To automate stock tracking and reduce manual errors.
- **Customer Convenience:** To provide features like instant search, filtering, and home delivery.
- **Data Management:** To securely store customer and order data for analysis.

## 1.3 Scope of System
The scope includes:
- **Customer Portal:** Registration, Login, Product Catalog (Search/Filter), Cart Management, Checkout, Order History, Profile Management.
- **Admin Portal:** Dashboard (Sales Stats), Product CRUD (Create, Read, Update, Delete), Category Management, Order Status Updates, User Management.
- **Security:** Password hashing, session management, and secure database interactions.

## 1.4 Operating Environment – Hardware and Software
**Hardware Requirements (Server/Client):**
- Processor: Intel Core i3 or higher
- RAM: 4GB or higher
- Storage: 500MB free space for application and database
- Internet Connection: Broadband for remote access

**Software Requirements:**
- **Operating System:** Windows 10/11, Linux, or macOS
- **Web Server:** Apache (via XAMPP/WAMP)
- **Database Server:** MySQL 5.7+
- **Server-Side Scripting:** PHP 7.2+
- **Browser:** Chrome, Firefox, Edge (for client access)

## 1.5 Brief Description of Technology Used
- **PHP (Hypertext Preprocessor):** A server-side scripting language used to handle application logic and database connections.
- **MySQL:** A relational database management system used to store user, product, and order data.
- **HTML5 & CSS3:** Used for structuring and styling the frontend, including responsive design and animations.
- **JavaScript:** Used for client-side interactivity, AJAX requests (e.g., adding to cart), and dynamic content.
- **XAMPP:** A local development environment containing Apache, MySQL, and PHP.

---

# Chapter 2: Proposed System

## 2.1 Study of Similar Systems
We analyzed platforms like *CaratLane* and *BlueStone*.
- **Strengths observed:** User-friendly filters, high-quality imagery, trust signals (certifications).
- **Weaknesses observed:** Complex navigation on some mobile views, slow load times.
**Takeaway:** Our system focuses on a lightweight, fast-loading interface with intuitive navigation and "Express Delivery" style quick checkout.

## 2.2 Objectives of Proposed System
1.  **Efficiency:** Reduce time spent on order processing and inventory updates.
2.  **User Experience:** Provide a visually appealing, responsive interface with animated interactions.
3.  **Accuracy:** Ensure real-time stock updates and precise order tracking.
4.  **Scalability:** Design a database structure that can handle thousands of products and users.

## 2.3 Users of System
1.  **Guest:** Can browse products, view details, and register.
2.  **Registered Customer:** Can add to cart, place orders, view history, and manage profile.
3.  **Administrator:** Has full control over the system (Products, Orders, Users, Settings).

---

# Chapter 3: Analysis and Design

## 3.1 System Requirements
**Functional Requirements:**
- System must allow users to register and login.
- System must display products with images, prices, and descriptions.
- System must support "Add to Cart" and "Checkout" functionality.
- System must generate unique Order IDs and Tracking IDs.
- Admin must be able to update delivery status.

**Non-Functional Requirements:**
- **Performance:** Pages should load within 2 seconds.
- **Security:** User passwords must be encrypted.
- **Reliability:** System should be available 99.9% of the time.
- **Usability:** Interface should be intuitive for non-technical users.

## 3.2 Entity Relationship Diagram (ERD)

**Mermaid UML Code:**
```mermaid
erDiagram
    USERS ||--o{ ORDERS : places
    USERS ||--o{ CART : manages
    USERS {
        int id PK
        string name
        string email
        string password
        string role
    }
    CATEGORIES ||--|{ PRODUCTS : contains
    CATEGORIES {
        int id PK
        string name
    }
    PRODUCTS ||--o{ CART : included_in
    PRODUCTS ||--o{ ORDER_ITEMS : listed_in
    PRODUCTS {
        int id PK
        string name
        decimal price
        int stock
        int category_id FK
    }
    ORDERS ||--|{ ORDER_ITEMS : contains
    ORDERS ||--o{ DELIVERY_STATUS : has
    ORDERS {
        int id PK
        int user_id FK
        decimal total
        string status
        timestamp created_at
    }
    ORDER_ITEMS {
        int id PK
        int order_id FK
        int product_id FK
        int quantity
        decimal price
    }
    DELIVERY_STATUS {
        int id PK
        int order_id FK
        string status
        timestamp update_time
    }
```

## 3.3 Table Structure

**1. Table: `users`**
| Column | Type | Constraints | Description |
|---|---|---|---|
| id | INT | PK, Auto Increment | Unique User ID |
| name | VARCHAR(150) | NOT NULL | Full Name |
| email | VARCHAR(150) | UNIQUE | Email Address |
| password | VARCHAR(255) | NOT NULL | Hashed Password |
| role | ENUM | 'user', 'admin' | User Privilege Level |

**2. Table: `products`**
| Column | Type | Constraints | Description |
|---|---|---|---|
| id | INT | PK, Auto Increment | Unique Product ID |
| name | VARCHAR(200) | NOT NULL | Product Name |
| price | DECIMAL(10,2) | NOT NULL | Price per unit |
| category_id | INT | FK | References `categories` |
| stock | INT | DEFAULT 0 | Inventory Count |

**3. Table: `orders`**
| Column | Type | Constraints | Description |
|---|---|---|---|
| id | INT | PK, Auto Increment | Unique Order ID |
| user_id | INT | FK | Customer who placed order |
| total | DECIMAL(12,2)| NOT NULL | Total Order Value |
| status | VARCHAR(50) | DEFAULT 'Pending' | Order Status |

## 3.4 Use Case Diagrams

**Mermaid UML Code:**
```mermaid
usecaseDiagram
    actor "Customer" as C
    actor "Administrator" as A

    package "Jewellery Shop System" {
        usecase "Register/Login" as UC1
        usecase "Browse Catalog" as UC2
        usecase "Search Products" as UC3
        usecase "Manage Cart" as UC4
        usecase "Checkout & Pay" as UC5
        usecase "View Order History" as UC6
        
        usecase "Manage Products" as UC7
        usecase "Manage Categories" as UC8
        usecase "Update Order Status" as UC9
        usecase "View Dashboard" as UC10
    }

    C --> UC1
    C --> UC2
    C --> UC3
    C --> UC4
    C --> UC5
    C --> UC6

    A --> UC1
    A --> UC7
    A --> UC8
    A --> UC9
    A --> UC10
```

## 3.5 Class Diagram

**Mermaid UML Code:**
```mermaid
classDiagram
    class User {
        +int id
        +string name
        +string email
        +login()
        +register()
        +updateProfile()
    }

    class Product {
        +int id
        +string name
        +decimal price
        +int stock
        +getDetails()
        +updateStock()
    }

    class Order {
        +int id
        +date date
        +decimal total
        +string status
        +placeOrder()
        +cancelOrder()
    }

    class Cart {
        +addItem()
        +removeItem()
        +calculateTotal()
    }

    class Admin {
        +addProduct()
        +removeProduct()
        +updateOrderStatus()
    }

    User <|-- Admin : inherits
    User "1" --> "*" Order : places
    User "1" --> "1" Cart : has
    Order "1" --> "*" Product : contains
    Cart "1" --> "*" Product : contains
```

## 3.6 Activity Diagram (Checkout Process)

**Mermaid UML Code:**
```mermaid
activityDiagram
    start
    :User logs in;
    :Browse Catalog;
    :Select Product;
    if (Stock Available?) then (yes)
        :Add to Cart;
        :Proceed to Checkout;
        :Enter Shipping Details;
        :Confirm Payment;
        :System Generates Order;
        :Update Stock;
        stop
    else (no)
        :Show "Out of Stock";
        stop
    endif
```

## 3.7 Deployment Diagram

**Mermaid UML Code:**
```mermaid
graph TD
    ClientNode[Client PC/Mobile Browser] -- HTTP/HTTPS --> WebServerNode
    
    subgraph "Server Environment (XAMPP)"
        WebServerNode[Apache Web Server]
        PHPNode[PHP Engine]
        DBNode[MySQL Database]
        
        WebServerNode --> PHPNode
        PHPNode --> DBNode
    end
```

## 3.8 Module Hierarchy Diagram

**Mermaid UML Code:**
```mermaid
graph TD
    Main[Jewellery Shop System]
    
    Main --> Public[Public Module]
    Main --> User[User Module]
    Main --> Admin[Admin Module]
    
    Public --> Home
    Public --> Catalog
    Public --> Contact
    
    User --> Auth[Login/Register]
    User --> Cart
    User --> Checkout
    User --> Profile
    
    Admin --> Dashboard
    Admin --> Inv[Inventory Mgmt]
    Admin --> Orders[Order Mgmt]
    Admin --> Users[User Mgmt]
```

## 3.9 Sample Input & Output Screens

**(Note: In a printed report, screenshots would be inserted here. Descriptions provided below.)**

1.  **Login Screen:** Glassmorphism card asking for Email and Password.
2.  **Home Page:** Hero banner with animated gold glitter background and trending products grid.
3.  **Product Catalog:** Grid of jewellery items with "Add to Cart" buttons and sidebar filters.
4.  **Cart Page:** List of selected items with quantity adjusters and price breakdown.
5.  **Admin Dashboard:** Overview cards showing Total Orders, Total Revenue, and Recent Activities.

---

# Chapter 4: Coding

## 4.1 Algorithms

**Algorithm for User Login:**
1.  Start.
2.  Accept Email and Password from user.
3.  Sanitize input.
4.  Query database for user with matching Email.
5.  If user found:
    a. Verify Password hash using `password_verify()`.
    b. If valid, create Session and redirect to Dashboard.
    c. If invalid, show error "Incorrect Password".
6.  If user not found, show error "User does not exist".
7.  Stop.

**Algorithm for Adding to Cart:**
1.  Start.
2.  Check if User is logged in.
3.  If not logged in, redirect to Login page.
4.  Receive Product ID and Quantity.
5.  Check database for existing cart item for this User + Product.
6.  If exists, update Quantity.
7.  If not exists, INSERT new row into `cart` table.
8.  Return success message to UI.
9.  Stop.

## 4.2 Code Snippets

**Database Connection (`config/db.php`):**
```php
<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$db   = 'jso_shop';

$mysqli = new mysqli($host, $user, $pass, $db);

if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}
?>
```

**Product Search Logic (`catalog.php`):**
```php
$search = $_GET['search'] ?? '';
$sql = "SELECT * FROM products WHERE name LIKE ?";
$stmt = $mysqli->prepare($sql);
$searchTerm = "%" . $search . "%";
$stmt->bind_param("s", $searchTerm);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    echo "<div class='product-card'>";
    echo "<h3>" . htmlspecialchars($row['name']) . "</h3>";
    echo "<p>Price: $" . $row['price'] . "</p>";
    echo "</div>";
}
```

---

# Chapter 5: Limitations of Proposed System

1.  **Offline Dependency:** The system requires an active internet connection to function; it does not have offline capabilities.
2.  **Payment Integration:** Currently uses a simulated payment gateway for demonstration; real-world banking API integration is needed for production.
3.  **Scalability:** While efficient for small-medium businesses, the current single-server architecture may require load balancing for millions of concurrent users.

---

# Chapter 6: Proposed Enhancements

1.  **AI Recommendations:** Implement machine learning to suggest products based on user browsing history.
2.  **Mobile App:** Develop a native Android/iOS application using React Native linked to the same backend.
3.  **AR Try-On:** Integrate Augmented Reality to allow users to "try on" jewellery virtually using their camera.
4.  **Multi-Language Support:** Add localization for different regions.

---

# Chapter 7: Conclusion

The **Jewellery Shop Management System** successfully achieves its primary objectives of modernizing the jewellery retail experience. It provides a secure, user-friendly platform for customers to shop and a powerful tool for administrators to manage business operations. By automating inventory and order tracking, the system significantly reduces manual effort and increases efficiency. The project is built on a solid foundation (LAMP stack) that is reliable and open to future enhancements.

---

# Chapter 8: Bibliography

1.  **Books:**
    - "PHP and MySQL Web Development" by Luke Welling & Laura Thomson.
    - "Head First HTML and CSS" by Elisabeth Robson & Eric Freeman.
2.  **Websites:**
    - PHP Documentation: https://www.php.net/docs.php
    - MySQL Reference Manual: https://dev.mysql.com/doc/
    - W3Schools (Web Dev Tutorials): https://www.w3schools.com/
3.  **Tools:**
    - Visual Studio Code (Editor)
    - XAMPP (Local Server)
    - Mermaid.js (Diagramming)
