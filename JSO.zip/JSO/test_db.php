<?php
require 'config/db.php';

$tables = ['users', 'products', 'orders', 'order_items', 'cart', 'delivery_status', 'coupons', 'offers', 'returns', 'password_resets'];

echo "Checking database tables:\n";
foreach($tables as $t) {
    $result = $mysqli->query("SHOW TABLES LIKE '$t'");
    echo $t . ': ' . ($result->num_rows > 0 ? 'EXISTS' : 'MISSING') . "\n";
}
?>
