<?php
session_start();
require 'config/db.php';
require 'includes/functions.php';

require_login();

$body_class = 'diamond-shine-bg';

$user_id = $_SESSION['user_id'];
$order_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Get order
$stmt = $mysqli->prepare("SELECT * FROM orders WHERE id=? AND user_id=?");
$stmt->bind_param('ii', $order_id, $user_id);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$order) {
  header('Location: ' . base_url('/my_orders.php'));
  exit;
}

// Get order items
$stmt = $mysqli->prepare("SELECT oi.*, p.name, p.price FROM order_items oi JOIN products p ON oi.product_id=p.id WHERE oi.order_id=?");
$stmt->bind_param('i', $order_id);
$stmt->execute();
$items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Get delivery status history (all updates)
$stmt = $mysqli->prepare("SELECT * FROM delivery_status WHERE order_id=? ORDER BY update_time ASC");
$stmt->bind_param('i', $order_id);
$stmt->execute();
$delivery_history = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Get latest status
$latest_status = !empty($delivery_history) ? end($delivery_history)['status'] : $order['status'];

// Normalize delivery history statuses for quick checks
$history_statuses = array_map(function($row){
    return strtolower($row['status'] ?? '');
}, $delivery_history);
$current_status = strtolower($order['status'] ?? '');

$reached = function(string $status) use ($history_statuses, $current_status){
    $s = strtolower($status);
    if ($current_status === $s) return true;
    return in_array($s, $history_statuses, true);
};

// Return eligibility (within 7 days after delivered/completed)
$return_available = false;
$return_days_left = null;
$delivered_at = null;
foreach (array_reverse($delivery_history) as $entry) {
    $st = strtolower($entry['status'] ?? '');
    if ($st === 'delivered' || $st === 'completed') {
        $delivered_at = $entry['update_time'];
        break;
    }
}
if ($delivered_at) {
    $deliveryDate = new DateTime($delivered_at);
    $today = new DateTime();
    $daysSince = $today->diff($deliveryDate)->days;
    $return_available = $daysSince <= 7;
    $return_days_left = max(0, 7 - $daysSince);
}

require 'includes/header.php';
?>

<style>
.order-container {
  max-width: 900px;
  margin: 40px auto;
  padding: 20px;
}

.order-header {
  background: white;
  padding: 20px;
  border-radius: 8px;
  margin-bottom: 20px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.08);
}

.order-id-section {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 15px;
  padding-bottom: 15px;
  border-bottom: 1px solid #eee;
}

.order-id {
  font-size: 18px;
  font-weight: 700;
  color: #333;
}

.order-date {
  color: #666;
  font-size: 14px;
}

.status-badge {
  padding: 6px 14px;
  border-radius: 20px;
  font-weight: 600;
  font-size: 13px;
  text-transform: uppercase;
}

.status-pending {
  background: #fff3cd;
  color: #856404;
}

.status-confirmed {
  background: #cfe2ff;
  color: #084298;
}

.status-shipped {
  background: #d1ecf1;
  color: #0c5460;
}

.status-delivered {
  background: #d4edda;
  color: #155724;
}

.status-cancelled {
  background: #f8d7da;
  color: #721c24;
}

.tracking-timeline {
  margin-bottom: 30px;
}

.timeline-item {
  display: flex;
  margin-bottom: 20px;
  padding-bottom: 20px;
  border-bottom: 1px solid #eee;
}

.timeline-item:last-child {
  border-bottom: none;
}

.timeline-dot {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: #f5f5f5;
  border: 3px solid #ddd;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  margin-right: 20px;
  font-weight: 700;
  color: #999;
}

.timeline-item.completed .timeline-dot {
  background: #4caf50;
  border-color: #4caf50;
  color: white;
}

.timeline-item.active .timeline-dot {
  background: #cda34f;
  border-color: #cda34f;
  color: white;
  box-shadow: 0 0 0 6px rgba(205,163,79,0.1);
}

.timeline-content {
  flex: 1;
}

.timeline-title {
  font-weight: 600;
  color: #333;
  margin-bottom: 4px;
}

.timeline-info {
  color: #999;
  font-size: 13px;
}

.items-section {
  background: white;
  padding: 20px;
  border-radius: 8px;
  margin-bottom: 20px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.08);
}

.items-title {
  font-size: 18px;
  font-weight: 700;
  color: #333;
  margin-bottom: 15px;
}

.item-card {
  display: flex;
  gap: 15px;
  padding: 15px;
  border: 1px solid #eee;
  border-radius: 6px;
  margin-bottom: 10px;
}

.item-card:last-child {
  margin-bottom: 0;
}

.item-image {
  width: 80px;
  height: 80px;
  background: #f5f5f5;
  border-radius: 6px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #999;
}

.item-details {
  flex: 1;
}

.item-name {
  font-weight: 600;
  color: #333;
  margin-bottom: 4px;
}

.item-qty {
  font-size: 13px;
  color: #666;
}

.item-price {
  font-size: 16px;
  font-weight: 700;
  color: #cda34f;
}

.totals-section {
  background: white;
  padding: 20px;
  border-radius: 8px;
  margin-bottom: 20px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.08);
}

.total-row {
  display: flex;
  justify-content: space-between;
  padding: 10px 0;
  border-bottom: 1px solid #eee;
}

.total-row.final {
  border-bottom: none;
  padding-top: 15px;
  padding-bottom: 0;
  font-weight: 700;
  color: #333;
  font-size: 16px;
}

.address-section {
  background: white;
  padding: 20px;
  border-radius: 8px;
  margin-bottom: 20px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.08);
}

.address-title {
  font-weight: 700;
  color: #333;
  margin-bottom: 10px;
}

.address-text {
  color: #666;
  font-size: 14px;
  line-height: 1.6;
}

.action-section {
  background: white;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.08);
  display: flex;
  gap: 10px;
  justify-content: center;
}

button {
  padding: 12px 24px;
  border: none;
  border-radius: 6px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s;
  font-size: 14px;
}

.btn-primary {
  background: linear-gradient(180deg, #cda34f, #b0852b);
  color: white;
}

.btn-primary:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 18px rgba(205,163,79,0.3);
}

.btn-danger {
  background: #f44336;
  color: white;
}

.btn-danger:hover {
  background: #d32f2f;
}

.btn-secondary {
  background: #757575;
  color: white;
}

.btn-secondary:hover {
  background: #616161;
}

.btn-disabled {
  background: #ccc;
  color: #666;
  cursor: not-allowed;
}

@media (max-width: 768px) {
  .item-card {
    flex-direction: column;
  }

  .action-section {
    flex-direction: column;
  }

  button {
    width: 100%;
  }
}
</style>

<div class="order-container">
  <div class="order-header">
    <div class="order-id-section">
      <div>
        <div class="order-id">Order #<?php echo e($order['id']); ?></div>
        <div class="order-date"><?php $created = $order['created_at'] ?? ($order['order_date'] ?? null); echo $created ? date('M d, Y h:i A', strtotime($created)) : ''; ?></div>
      </div>
      <div class="status-badge status-<?php echo strtolower($order['status']); ?>">
        <?php echo ucfirst($order['status']); ?>
      </div>
    </div>
  </div>

  <!-- TRACKING TIMELINE -->
  <div class="order-header">
    <h2 style="margin: 0 0 20px 0; font-size: 18px; font-weight: 700; color: #333;">📍 Order Tracking</h2>
    <div class="tracking-timeline">
      <?php
        $processingDone = $reached('processing') || $reached('packing') || $reached('shipped') || $reached('delivered') || $reached('completed');
        $packingDone    = $reached('packing')   || $reached('shipped') || $reached('delivered') || $reached('completed');
        $shippedDone    = $reached('shipped')   || $reached('delivered') || $reached('completed');
        $deliveredDone  = $reached('delivered') || $reached('completed');
      ?>
      <div class="timeline-item <?php echo ($order['status'] !== 'pending') ? 'completed' : 'active'; ?>">
        <div class="timeline-dot">✓</div>
        <div class="timeline-content">
          <div class="timeline-title">Order Confirmed</div>
          <div class="timeline-info"><?php $created2 = $order['order_date'] ?? null; echo $created2 ? date('M d, Y h:i A', strtotime($created2)) : ''; ?></div>
        </div>
      </div>

      <div class="timeline-item <?php echo $processingDone ? 'completed' : 'active'; ?>">
        <div class="timeline-dot">📦</div>
        <div class="timeline-content">
          <div class="timeline-title">Processing</div>
          <div class="timeline-info">Order being prepared for shipment<br><?php $dtime = !empty($delivery_history) ? $delivery_history[0]['update_time'] : null; echo $dtime ? date('M d, Y h:i A', strtotime($dtime)) : 'In progress'; ?></div>
        </div>
      </div>

      <div class="timeline-item <?php echo $packingDone ? 'completed' : ($processingDone ? 'active' : ''); ?>">
        <div class="timeline-dot">🚚</div>
        <div class="timeline-content">
          <div class="timeline-title">Packing</div>
          <div class="timeline-info"><?php 
$shippedEntry = null;
foreach($delivery_history as $entry) {
    if($entry['status'] === 'Shipped') { $shippedEntry = $entry; break; }
}
$packingEntry = null;
foreach($delivery_history as $entry) {
    if($entry['status'] === 'Packing') { $packingEntry = $entry; break; }
}
$packTime = $packingEntry ? $packingEntry['update_time'] : null;
echo 'Items packed carefully<br>';
echo $packTime ? date('M d, Y h:i A', strtotime($packTime)) : 'Pending'; 
?></div>
        </div>
      </div>

      <div class="timeline-item <?php echo $deliveredDone ? 'completed' : ($shippedDone ? 'active' : ''); ?>">
        <div class="timeline-dot">✓</div>
        <div class="timeline-content">
          <div class="timeline-title">Delivered</div>
          <div class="timeline-info"><?php 
$deliveredEntry = null;
foreach($delivery_history as $entry) {
    if($entry['status'] === 'Completed' || $entry['status'] === 'Delivered') { $deliveredEntry = $entry; break; }
}
$delTime = $deliveredEntry ? $deliveredEntry['update_time'] : null;
echo $delTime ? date('M d, Y h:i A', strtotime($delTime)) : 'Awaiting'; 
?></div>
        </div>
      </div>
    </div>
  </div>

  <!-- ORDER ITEMS -->
  <div class="items-section">
    <div class="items-title">Order Items (<?php echo count($items); ?>)</div>
    <?php foreach ($items as $item): ?>
      <div class="item-card">
        <div class="item-image">💍</div>
        <div class="item-details">
          <div class="item-name"><?php echo e($item['name']); ?></div>
          <div class="item-qty">Quantity: <?php echo $item['quantity']; ?> × ₹<?php echo number_format($item['price']); ?></div>
        </div>
        <div style="text-align: right;">
          <div class="item-price">₹<?php echo number_format($item['quantity'] * $item['price']); ?></div>
        </div>
      </div>
    <?php endforeach; ?>
  </div>

  <!-- TOTALS -->
  <?php
    // Derive amounts safely based on existing schema
    $items_subtotal = 0;
    foreach ($items as $it) {
      $items_subtotal += $it['price'] * $it['quantity'];
    }
    $subtotal = $order['subtotal'] ?? $items_subtotal;
    $discount = $order['discount'] ?? 0;
    $shipping = $order['shipping'] ?? 50; // default shipping same as checkout
    $total_amount = $order['total'] ?? ($subtotal - $discount + $shipping);
  ?>
  <div class="totals-section">
    <div class="total-row">
      <span>Subtotal</span>
      <span>₹<?php echo number_format($subtotal); ?></span>
    </div>
    <div class="total-row">
      <span>Discount</span>
      <span style="color: #4caf50;">-₹<?php echo number_format($discount); ?></span>
    </div>
    <div class="total-row">
      <span>Shipping</span>
      <span>₹<?php echo number_format($shipping); ?></span>
    </div>
    <div class="total-row final">
      <span>Total Amount</span>
      <span style="color: #cda34f;">₹<?php echo number_format($total_amount); ?></span>
    </div>
  </div>

  <!-- DELIVERY ADDRESS -->
  <div class="address-section">
    <div class="address-title">📮 Delivery Address</div>
    <div class="address-text">
      <?php
        // Use address + optional city/state/pincode if present
        $addr = $order['address'] ?? ($order['delivery_address'] ?? '');
        $pin  = $order['pincode'] ?? '';
        $city = $order['city'] ?? '';
        $state = $order['state'] ?? '';
        $full = trim($addr);
        if ($city)  $full .= "\n" . $city;
        if ($state) $full .= ($city ? ', ' : "\n") . $state;
        if ($pin)   $full .= " - " . $pin;
        echo nl2br(e($full));
      ?>
    </div>
  </div>

  <!-- RETURN & ACTIONS -->
  <div class="action-section" style="flex-wrap: wrap; gap: 12px;">
    <button class="btn-primary" onclick="location.href='<?php echo base_url('/my_orders.php'); ?>'">← Back to Orders</button>
    
    <?php if (in_array(strtolower($order['status']), ['delivered','completed'])): ?>
      <?php if ($return_available): ?>
        <button class="btn-secondary" onclick="location.href='<?php echo base_url('/return_product.php?id=' . $order_id); ?>'">↩️ Return Product</button>
        <div style="font-size:13px;color:#2e7d32">Return available · <?php echo $return_days_left; ?> day(s) left</div>
      <?php else: ?>
        <button class="btn-disabled" disabled>↩️ Return Product</button>
        <div style="font-size:13px;color:#b23b3b">Return window closed (7 days after delivery)</div>
      <?php endif; ?>
    <?php elseif (in_array(strtolower($order['status']), ['pending','confirmed'])): ?>
      <button class="btn-danger" onclick="if(confirm('Cancel this order?')) location.href='<?php echo base_url('/cancel_order.php?id=' . $order_id); ?>'">❌ Cancel Order</button>
    <?php endif; ?>
  </div>

</div>

<?php require 'includes/footer.php'; ?>
