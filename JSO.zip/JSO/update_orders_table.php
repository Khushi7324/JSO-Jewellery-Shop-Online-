<?php
require 'config/db.php';

$columns = [
    'transaction_id' => 'ALTER TABLE orders ADD COLUMN transaction_id VARCHAR(50) UNIQUE NULL',
    'bill_id' => 'ALTER TABLE orders ADD COLUMN bill_id VARCHAR(50) UNIQUE NULL',
    'tracking_id' => 'ALTER TABLE orders ADD COLUMN tracking_id VARCHAR(50) UNIQUE NULL'
];

foreach ($columns as $col => $sql) {
    $result = $mysqli->query("SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='orders' AND COLUMN_NAME='$col'");
    if ($result->num_rows == 0) {
        $mysqli->query($sql);
        echo "✅ Added column: $col\n";
    } else {
        echo "✓ Column exists: $col\n";
    }
}

echo "\nDatabase updated successfully!\n";
?>
