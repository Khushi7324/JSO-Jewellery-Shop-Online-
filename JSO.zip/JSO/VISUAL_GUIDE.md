# 🎨 Visual Guide: Email or Phone Login System

## 📊 Complete System Flow

```
╔═══════════════════════════════════════════════════════════════════╗
║                  JEWELLERY SHOP - USER AUTHENTICATION             ║
╚═══════════════════════════════════════════════════════════════════╝

┌─────────────────────────────────────────────────────────────────┐
│                   REGISTRATION FLOW (NEW)                       │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌──────────────────────────────────────────┐                  │
│  │  User Opens /register.php                │                  │
│  └──────────────────────────────────────────┘                  │
│                      ↓                                          │
│  ┌──────────────────────────────────────────┐                  │
│  │  Sees Registration Form:                 │                  │
│  │  ✓ Name (required)                       │                  │
│  │  ✓ Phone (required) ← NEW PRIMARY        │                  │
│  │  ✓ Email (OPTIONAL) ← CAN SKIP!          │                  │
│  │  ✓ Password (required)                   │                  │
│  │  ✓ Address (required)                    │                  │
│  └──────────────────────────────────────────┘                  │
│                      ↓                                          │
│  ┌──────────────────────────────────────────┐                  │
│  │ Path 1: Fill Email            │          │                  │
│  │ Email: john@example.com       │          │                  │
│  │ Phone: 9876543210            │          │                  │
│  └─────────────────────────────────┘          │                  │
│                      ↓                        │                  │
│  ┌──────────────────────────────────────────┐ │                  │
│  │ Path 2: Skip Email (OPTIONAL)  │ Check                      │
│  │ Email: [EMPTY]               │ Phone                        │
│  │ Phone: 9876543210            │ Unique?                      │
│  └─────────────────────────────────┘ │ ↓                       │
│                      ↓                │ ✓ Unique              │
│  ┌──────────────────────────────────────────┐                  │
│  │ Validate All Data:                       │                  │
│  │ • Name length (min 3)                    │                  │
│  │ • Email format (if provided)             │                  │
│  │ • Phone format (exactly 10 digits)       │                  │
│  │ • Password match                         │                  │
│  │ • Address length (min 10)                │                  │
│  └──────────────────────────────────────────┘                  │
│                      ↓                                          │
│  ┌──────────────────────────────────────────┐                  │
│  │ Hash Password (bcrypt)                   │                  │
│  │ Store in database:                       │                  │
│  │ • name: "John Doe"                       │                  │
│  │ • email: "john@example.com" (or NULL)    │                  │
│  │ • phone: "9876543210"                    │                  │
│  │ • password: "$2y$10$N9qo8uLO..." (hash)  │                  │
│  │ • address: "123 Main St"                 │                  │
│  └──────────────────────────────────────────┘                  │
│                      ↓                                          │
│  ┌──────────────────────────────────────────┐                  │
│  │ Create Session                           │                  │
│  │ $_SESSION['user_id'] = 1                 │                  │
│  └──────────────────────────────────────────┘                  │
│                      ↓                                          │
│  ┌──────────────────────────────────────────┐                  │
│  │ Success! ✅                              │                  │
│  │ Auto-redirects to Home Page              │                  │
│  │ User is Logged In                        │                  │
│  └──────────────────────────────────────────┘                  │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│                   LOGIN FLOW (UPDATED)                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌──────────────────────────────────────────┐                  │
│  │  User Opens /login.php                   │                  │
│  └──────────────────────────────────────────┘                  │
│                      ↓                                          │
│  ┌──────────────────────────────────────────┐                  │
│  │  Sees Login Form:                        │                  │
│  │  📧 Email or Phone (accepts BOTH!)       │                  │
│  │  🔒 Password                             │                  │
│  └──────────────────────────────────────────┘                  │
│                      ↓                                          │
│         ┌───────────────────────────────┐                      │
│         │                               │                      │
│  ┌──────────────────────┐   ┌──────────────────────┐           │
│  │ Option 1: Email      │   │ Option 2: Phone      │           │
│  │ Input: john@...com   │   │ Input: 9876543210    │           │
│  └──────────────────────┘   └──────────────────────┘           │
│         │                               │                      │
│         └───────────────────────────────┘                      │
│                      ↓                                          │
│  ┌──────────────────────────────────────────┐                  │
│  │ Detect Format:                           │                  │
│  │ • Is it email? (contains @)              │                  │
│  │ • Is it phone? (10 digits)               │                  │
│  │ • If neither: Error ❌                   │                  │
│  └──────────────────────────────────────────┘                  │
│                      ↓                                          │
│  ┌──────────────────────────────────────────┐                  │
│  │ Database Query (BOTH):                   │                  │
│  │ SELECT * FROM users                      │                  │
│  │ WHERE email = 'john@example.com'         │                  │
│  │ OR phone = '9876543210'                  │                  │
│  └──────────────────────────────────────────┘                  │
│                      ↓                                          │
│         ┌───────────────────────────────┐                      │
│         │ User Found?                   │                      │
│         └───────────────────────────────┘                      │
│              ↙              ↘                                  │
│         ✅ Yes             ❌ No                               │
│         │                  │                                  │
│  ┌──────────────────┐  ┌──────────────────────────────┐      │
│  │ Verify Password: │  │ Error: "No account found"    │      │
│  │ password_verify()│  │                              │      │
│  └──────────────────┘  └──────────────────────────────┘      │
│         ↓                                                     │
│    ┌─────────────────┐                                       │
│    │ Match?          │                                       │
│    └─────────────────┘                                       │
│      ↙        ↘                                              │
│  ✅ Yes        ❌ No                                          │
│   │            │                                            │
│   │     ┌──────────────────────────┐                        │
│   │     │ Error: "Invalid Password"│                        │
│   │     └──────────────────────────┘                        │
│   │                                                         │
│  ┌──────────────────────────────────────────┐              │
│  │ Create Session:                          │              │
│  │ $_SESSION['user_id'] = 1                 │              │
│  └──────────────────────────────────────────┘              │
│                 ↓                                           │
│  ┌──────────────────────────────────────────┐              │
│  │ Success! ✅                              │              │
│  │ Redirect to Home Page                    │              │
│  │ User is Logged In                        │              │
│  └──────────────────────────────────────────┘              │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## 🎯 Before vs After Comparison

### BEFORE (Email Required)
```
Registration:
┌─────────────────────────────────┐
│ Full Name      [________]        │
│ Email *        [user@ex.com]     │ ← MUST FILL
│ Phone          [9876543210]      │
│ Password       [••••••••]        │
│ Address        [..............] │
│ [REGISTER]                       │
└─────────────────────────────────┘

Login:
┌─────────────────────────────────┐
│ Email    [user@example.com]      │ ← ONLY WAY
│ Password [••••••••]              │
│ [LOGIN]                          │
└─────────────────────────────────┘

Problem: ❌ No email? Can't register!
         ❌ Forgot email? Can't login!
```

### AFTER (Phone Required, Email Optional)
```
Registration:
┌─────────────────────────────────┐
│ Full Name      [________]        │
│ Phone *        [9876543210]      │ ← MUST FILL
│ Email          [optional]        │ ← Can SKIP!
│ Password       [••••••••]        │
│ Address        [..............] │
│ [REGISTER]                       │
└─────────────────────────────────┘

Login:
┌─────────────────────────────────┐
│ Email or Phone [9876543210]      │ ← TWO OPTIONS:
│                [user@ex.com]     │   • Phone ✅
│ Password       [••••••••]        │   • Email ✅
│ [LOGIN]                          │
└─────────────────────────────────┘

Solution: ✅ No email? Can register with phone!
          ✅ Forgot email? Login with phone!
```

---

## 👥 User Journeys

### Journey 1: Privacy-Conscious User

```
User: "I don't want to share email"

BEFORE:
User → Opens Registration
     → Sees email field (required)
     → ❌ BLOCKED - Can't proceed
     → Leaves website

AFTER:
User → Opens Registration
     → Sees email field (optional)
     → ✅ Skips email
     → Fills name, phone, password, address
     → Registers successfully
     → Later opens login page
     → Enters phone: 9876543210
     → Enters password
     → ✅ LOGGED IN!
```

### Journey 2: Forgetful User

```
User: "I registered but forgot my email address"

BEFORE:
User → Wants to login
     → Opens login page
     → Only email field available
     → Can't remember email
     → ❌ CAN'T LOGIN
     → Stuck!

AFTER:
User → Wants to login
     → Opens login page
     → Sees "Email or Phone" field
     → Remembers phone: 9876543210
     → Enters phone: 9876543210
     → Enters password
     → ✅ LOGGED IN!
```

### Journey 3: Both Options User

```
User: Provided both email and phone

FIRST LOGIN:
→ Enters: user@example.com
→ ✅ Logged in!

SECOND LOGIN:
→ Enters: 9876543210
→ ✅ Also logged in!

CHOICE: Use whichever they remember!
```

---

## 🗃️ Database Structure

### USERS TABLE - BEFORE

```
id   name    email         phone      password        role   created_at
──────────────────────────────────────────────────────────────────────
1    John    john@ex.com   9876...    $2y$10$N9qo8    user   2025-12-06
2    Jane    jane@ex.com   NULL       $2y$10$Kd8e2    user   2025-12-06
3    Admin   admin@ex.com  9999...    $2y$10$L4m9p    admin  2025-12-06

Constraints:
• email UNIQUE NOT NULL (required, no duplicates)
• phone VARCHAR(20) (optional)
```

### USERS TABLE - AFTER

```
id   name    email      phone         password        role   created_at
──────────────────────────────────────────────────────────────────────
1    John    john@ex.   9876543210    $2y$10$N9qo8    user   2025-12-06
2    Jane    NULL       9999888877    $2y$10$Kd8e2    user   2025-12-06 ← No email!
3    Admin   admin@ex.  9123456789    $2y$10$L4m9p    admin  2025-12-06

Constraints:
• email VARCHAR(150) (optional, can be NULL)
• phone VARCHAR(20) UNIQUE NOT NULL (required, no duplicates)
```

---

## 🔑 Login Query

### BEFORE (Email Only)

```sql
SELECT id, password FROM users WHERE email = ?

Input: "john@example.com"

Matches if:
• Email column = "john@example.com" ✓

Fails if:
• User enters phone number (9876543210) ✗
• Email column is NULL ✗
```

### AFTER (Email OR Phone)

```sql
SELECT id, password FROM users 
WHERE email = ? OR phone = ?

Input 1: "john@example.com" OR "john@example.com"
Input 2: "9876543210" OR "9876543210"

Matches if:
• Email column = "john@example.com" ✓
• OR phone column = "9876543210" ✓
• OR both! ✓

Result:
✓ Email login works
✓ Phone login works
✓ Both methods accepted
```

---

## ✅ Validation Rules

### Registration Validation

```
Step 1: Check Name
├─ Is not empty? ✓
├─ Length ≥ 3 chars? ✓
└─ Reject if fails → Error: "Name min 3 chars"

Step 2: Check Phone (NEW REQUIREMENT)
├─ Is not empty? ✓
├─ Exactly 10 digits? ✓
├─ No duplicates? ✓
└─ Reject if fails → Error: "Phone invalid or duplicate"

Step 3: Check Email (NOW OPTIONAL)
├─ Is provided (not empty)?
│  └─ If YES: Is valid format? ✓
│     └─ If NO: Error "Email format invalid"
│  └─ If NO: OK to skip ✓
└─ If provided: No duplicates? ✓

Step 4: Check Password
├─ Length ≥ 6 chars? ✓
├─ Matches confirm password? ✓
└─ Hash with bcrypt ✓

Step 5: Check Address
├─ Is not empty? ✓
├─ Length ≥ 10 chars? ✓
└─ Store in DB ✓

Step 6: Insert User
└─ All checks passed? → Store in database ✓
```

### Login Validation

```
Step 1: Receive Login Field
└─ Could be email or phone

Step 2: Detect Format
├─ Contains @? → Email format ✓
├─ Exactly 10 digits? → Phone format ✓
└─ Neither? → Error: "Enter valid email or phone"

Step 3: Query Database
└─ WHERE email = ? OR phone = ? ✓

Step 4: Found User?
├─ YES → Continue to password check
└─ NO → Error: "No account found"

Step 5: Verify Password
├─ password_verify(input, stored_hash)?
├─ YES → Create session ✓
└─ NO → Error: "Invalid password"

Step 6: Success
└─ Set $_SESSION['user_id'] = user_id
└─ Redirect to home page ✓
```

---

## 🎨 Visual Comparison

### Registration Form Layout

**BEFORE:**
```
┌─ REGISTRATION ─────────────┐
│ Full Name:                  │
│ [____________________]      │
│                             │
│ Email: *                    │
│ [____________________]      │ ← Required
│                             │
│ Phone:                      │
│ [____________________]      │
│                             │
│ Password:                   │
│ [____________________]      │
│                             │
│ Address:                    │
│ [____________________]      │
│                             │
│ [REGISTER]                  │
└─────────────────────────────┘
```

**AFTER:**
```
┌─ REGISTRATION ─────────────┐
│ Full Name:                  │
│ [____________________]      │
│                             │
│ Phone: *                    │
│ [____________________]      │ ← Required (New)
│                             │
│ Email:                      │
│ [____________________]      │ ← Optional (Was required)
│                             │
│ Password:                   │
│ [____________________]      │
│                             │
│ Address:                    │
│ [____________________]      │
│                             │
│ [REGISTER]                  │
└─────────────────────────────┘
```

---

## 🔄 State Transitions

### User States (Registration to Login)

```
BEFORE Registration:
┌─────────────────────┐
│ Not Registered      │
└─────────────────────┘
        ↓
Fill Registration Form:
• Must have: Name, Email, Password, Address
• Phone optional
        ↓
Check Validations:
• Email format valid?
• Email not duplicate?
        ↓
AFTER Registration:
┌─────────────────────┐
│ Registered          │
│ (with email)        │
└─────────────────────┘
        ↓
Login Page:
• Email field only
• Must enter email
        ↓
Success:
┌─────────────────────┐
│ Logged In           │
└─────────────────────┘

AFTER Registration:
┌──────────────────────────┐
│ Registered               │
│ Path A: (with email)     │
│ Path B: (no email!)      │ ← NEW!
└──────────────────────────┘
        ↓
Login Page:
• Email or Phone field
• Can enter either
        ↓
Success:
┌─────────────────────┐
│ Logged In           │
└─────────────────────┘
```

---

## 📱 Code Example

### Registration (Phone First)

```php
// In register.php
$phone = trim($_POST['phone']); // Required
$email = trim($_POST['email']); // Optional

// Validate phone (required)
if(!preg_match('/^\d{10}$/', $phone)) {
    $errors[] = "Phone must be 10 digits";
}

// Validate email (if provided)
if($email && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = "Email format invalid";
}

// Check phone uniqueness
SELECT COUNT(*) FROM users WHERE phone = ?;
// Must be 0 (no duplicates)

// Insert
INSERT INTO users(name, phone, email, password) 
VALUES(...);
```

### Login (Email or Phone)

```php
// In login.php
$login = trim($_POST['login']); // Could be email or phone

// Detect format
$is_email = filter_var($login, FILTER_VALIDATE_EMAIL);
$is_phone = preg_match('/^\d{10}$/', $login);

if(!$is_email && !$is_phone) {
    $errors[] = "Enter valid email or phone";
}

// Query both fields
SELECT id, password FROM users 
WHERE email = ? OR phone = ?;

// Use same $login value for both
$stmt->bind_param('ss', $login, $login);
```

---

## 📊 Statistics

| Metric | Before | After |
|--------|--------|-------|
| Required Fields | 5 (Name, Email, Phone, Password, Address) | 5 (Name, Phone, Password, Address + optional Email) |
| Optional Fields | 0 | 1 (Email) |
| Login Methods | 1 (Email only) | 2 (Email or Phone) ✅ |
| Unique Identifiers | Email | Phone ✅ |
| Privacy Score | 2/5 | 5/5 ✅ |
| Flexibility Score | 1/5 | 5/5 ✅ |

---

## ✨ Key Benefits

| Feature | Before | After |
|---------|--------|-------|
| **Can register without email?** | ❌ No | ✅ Yes |
| **Can login without email?** | ❌ No | ✅ Yes (use phone) |
| **Email required?** | ✅ Always | ❌ Optional |
| **Phone required?** | ❌ No | ✅ Yes |
| **Phone login?** | ❌ Not supported | ✅ Supported |
| **Privacy friendly?** | ❌ No | ✅ Yes |
| **User friendly?** | ⚠️ Medium | ✅ High |

---

**Version:** 1.0 Visual Guide  
**Created:** December 2025  
**Status:** Complete ✅

🎨 **Now you can see exactly how the new system works!**
