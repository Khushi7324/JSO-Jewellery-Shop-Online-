<?php
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/functions.php';

header('Content-Type: application/json; charset=utf-8');

$product_id = isset($_GET['product_id']) ? (int)$_GET['product_id'] : 0;
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$perPage = isset($_GET['per_page']) ? max(1, (int)$_GET['per_page']) : 10;
$offset = ($page - 1) * $perPage;

if (!$product_id) {
    echo json_encode(['success' => false, 'error' => 'Missing product_id']);
    exit;
}

$total = 0;
$stmtCount = $mysqli->prepare("SELECT COUNT(*) FROM reviews WHERE product_id = ?");
if ($stmtCount) {
    $stmtCount->bind_param('i', $product_id);
    $stmtCount->execute();
    $stmtCount->bind_result($total);
    $stmtCount->fetch();
    $stmtCount->close();
}

$sql = "SELECT r.rating, r.comment, r.created_at, u.name as user_name FROM reviews r LEFT JOIN users u ON r.user_id=u.id WHERE r.product_id=? ORDER BY r.created_at DESC LIMIT $perPage OFFSET $offset";
$stmt = $mysqli->prepare($sql);
$reviews = [];
if ($stmt) {
    $stmt->bind_param('i', $product_id);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($res) {
        while ($row = $res->fetch_assoc()) {
            $reviews[] = [
                'rating' => $row['rating'] === null ? null : (float)$row['rating'],
                'comment' => $row['comment'],
                'user_name' => $row['user_name'] ?: 'Anonymous',
                'created_at' => $row['created_at']
            ];
        }
    }
    $stmt->close();
}

$totalPages = $total > 0 ? (int)ceil($total / $perPage) : 1;
$hasMore = $page < $totalPages;

echo json_encode([
    'success' => true,
    'reviews' => $reviews,
    'page' => $page,
    'per_page' => $perPage,
    'total' => $total,
    'total_pages' => $totalPages,
    'has_more' => $hasMore
]);
exit;

?>
