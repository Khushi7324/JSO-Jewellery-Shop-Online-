<?php
session_start();
require 'config/db.php';
require 'includes/functions.php';

require_login();

$uid = $_SESSION['user_id'];
$body_class = 'diamond-shine-bg';

if (!isset($_SESSION['current_order_id'])) {
  header('Location: ' . base_url('/cart.php'));
  exit;
}

$order_id = $_SESSION['current_order_id'];
$order_total = $_SESSION['order_total'];

// Fetch order details
$stmt = $mysqli->prepare("SELECT * FROM orders WHERE id=? AND user_id=?");
$stmt->bind_param('ii', $order_id, $uid);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();
$stmt->close();

  if (!$order) {
  header('Location: ' . base_url('/cart.php'));
  exit;
}

$error = '';
$transaction_id = '';
$bill_id = '';
$tracking_id = '';

// Handle payment submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $card_number = trim($_POST['card_number'] ?? '');
    $cvv = trim($_POST['cvv'] ?? '');
    $expiry = trim($_POST['expiry'] ?? '');

    if (!$card_number || !$cvv || !$expiry) {
        $error = 'Please enter all payment details';
    } else if (strlen($card_number) < 13) {
        $error = 'Invalid card number';
    } else if (strlen($cvv) < 3) {
        $error = 'Invalid CVV';
    } else {
        // Generate unique IDs
        $transaction_id = 'TXN-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -5));
        $bill_id = 'BILL-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -5));
        $tracking_id = 'TRACK-' . strtoupper(substr(uniqid(), -7));

        // Update order with payment details
        $stmt = $mysqli->prepare("UPDATE orders SET transaction_id=?, bill_id=?, tracking_id=?, payment_status='completed', status='processing' WHERE id=?");
        $stmt->bind_param('sssi', $transaction_id, $bill_id, $tracking_id, $order_id);
        
        if ($stmt->execute()) {
            $stmt->close();

            // Add delivery status record (align with delivery_status schema)
            $stmt = $mysqli->prepare("INSERT INTO delivery_status(order_id, status, update_time) VALUES(?, 'payment_confirmed', NOW())");
            $stmt->bind_param('i', $order_id);
            $stmt->execute();
            $stmt->close();

            // Store payment details in session for confirmation
            $_SESSION['payment_success'] = true;
            $_SESSION['transaction_id'] = $transaction_id;
            $_SESSION['bill_id'] = $bill_id;
            $_SESSION['tracking_id'] = $tracking_id;

            unset($_SESSION['current_order_id']);
            unset($_SESSION['order_total']);
            unset($_SESSION['applied_coupon']);

            header('Location: ' . base_url('/payment_success.php?order_id=' . $order_id));
            exit;
        } else {
            $error = 'Payment processing failed. Please try again.';
        }
    }
}

require 'includes/header.php';
?>

<style>
.payment-container {
  max-width: 800px;
  margin: 40px auto;
  padding: 20px;
}

.payment-header {
  text-align: center;
  margin-bottom: 40px;
}

.payment-title {
  font-size: 28px;
  font-weight: 700;
  color: #333;
  margin-bottom: 10px;
}

.payment-subtitle {
  color: #666;
  font-size: 14px;
}

.payment-content {
  display: grid;
  grid-template-columns: 1fr 350px;
  gap: 30px;
}

.payment-form {
  background: white;
  border-radius: 8px;
  padding: 30px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.08);
}

.form-section {
  margin-bottom: 30px;
}

.form-section-title {
  font-size: 16px;
  font-weight: 700;
  color: #333;
  margin-bottom: 20px;
  padding-bottom: 10px;
  border-bottom: 2px solid #f0f0f0;
}

.form-group {
  display: flex;
  flex-direction: column;
  margin-bottom: 20px;
}

.form-group label {
  font-weight: 600;
  color: #333;
  margin-bottom: 8px;
  font-size: 14px;
}

.form-group input {
  padding: 12px;
  border: 1px solid #ddd;
  border-radius: 6px;
  font-size: 14px;
  font-family: inherit;
  transition: all 0.2s;
}

.form-group input:focus {
  outline: none;
  border-color: #cda34f;
  box-shadow: 0 0 0 3px rgba(205,163,79,0.1);
}

.form-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 20px;
}

.security-info {
  background: #e3f2fd;
  padding: 12px;
  border-radius: 6px;
  font-size: 12px;
  color: #1565c0;
  margin-top: 20px;
  border-left: 4px solid #1565c0;
}

.error-msg {
  padding: 12px;
  background: #f8d7da;
  color: #721c24;
  border-radius: 6px;
  margin-bottom: 20px;
  border-left: 4px solid #f44336;
}

.pay-btn {
  width: 100%;
  padding: 16px;
  background: linear-gradient(180deg, #cda34f, #b0852b);
  color: white;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-weight: 700;
  font-size: 16px;
  transition: all 0.2s;
  margin-top: 10px;
}

.pay-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 18px rgba(205,163,79,0.3);
}

.order-summary {
  background: white;
  border-radius: 8px;
  padding: 20px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.08);
  position: sticky;
  top: 100px;
}

.summary-title {
  font-weight: 700;
  color: #333;
  margin-bottom: 20px;
  font-size: 16px;
}

.order-info {
  margin-bottom: 20px;
  padding-bottom: 20px;
  border-bottom: 1px solid #eee;
}

.info-row {
  display: flex;
  justify-content: space-between;
  margin-bottom: 8px;
  font-size: 14px;
}

.info-label {
  color: #666;
}

.info-value {
  color: #333;
  font-weight: 600;
}

.summary-row {
  display: flex;
  justify-content: space-between;
  margin-bottom: 10px;
  padding-bottom: 10px;
  border-bottom: 1px solid #eee;
  color: #666;
  font-size: 14px;
}

.summary-row.total {
  border-bottom: none;
  margin-top: 15px;
  font-weight: 700;
  font-size: 16px;
  color: #333;
}

.summary-row.total .amount {
  color: #cda34f;
  font-size: 20px;
}

.payment-methods-badge {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 8px;
  margin-top: 15px;
}

.badge {
  padding: 8px;
  background: #f5f5f5;
  border-radius: 4px;
  font-size: 12px;
  text-align: center;
  color: #666;
}

@media (max-width: 768px) {
  .payment-content {
    grid-template-columns: 1fr;
  }
  
  .order-summary {
    position: static;
  }
  
  .form-row {
    grid-template-columns: 1fr;
  }
}
</style>

<div class="payment-container">
  <div class="payment-header">
    <div class="payment-title">💳 Secure Payment</div>
    <div class="payment-subtitle">Order #<?php echo $order_id; ?> | Total: ₹<?php echo number_format($order_total); ?></div>
  </div>

  <div class="payment-content">
    <!-- PAYMENT FORM -->
    <form method="POST" class="payment-form">
      <?php if ($error): ?>
        <div class="error-msg"><?php echo e($error); ?></div>
      <?php endif; ?>

      <div class="form-section">
        <div class="form-section-title">💳 Card Details</div>
        
        <div class="form-group">
          <label for="card_number">Card Number</label>
          <input type="text" id="card_number" name="card_number" placeholder="1234 5678 9012 3456" maxlength="19" required>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label for="expiry">Expiry Date (MM/YY)</label>
            <input type="text" id="expiry" name="expiry" placeholder="12/25" maxlength="5" required>
          </div>
          <div class="form-group">
            <label for="cvv">CVV</label>
            <input type="text" id="cvv" name="cvv" placeholder="123" maxlength="4" required>
          </div>
        </div>
      </div>

      <div class="security-info">
        🔒 Your payment information is secure and encrypted. We never store complete card details.
      </div>

      <button type="submit" class="pay-btn">Pay ₹<?php echo number_format($order_total); ?></button>
    </form>

    <!-- ORDER SUMMARY -->
    <div class="order-summary">
      <div class="summary-title">Payment Summary</div>
      
      <div class="order-info">
        <div class="info-row">
          <span class="info-label">Order ID</span>
          <span class="info-value">#<?php echo $order_id; ?></span>
        </div>
        <div class="info-row">
          <span class="info-label">Payment Method</span>
          <span class="info-value"><?php $pm = $order['payment_mode'] ?? ($order['payment_method'] ?? ''); echo $pm ? ucfirst($pm) : 'N/A'; ?></span>
        </div>
        <div class="info-row">
          <span class="info-label">Address</span>
          <span class="info-value" style="text-align: right; max-width: 150px; word-break: break-word;">
            <?php $addr = $order['address'] ?? ($order['shipping_address'] ?? ''); echo $addr ? substr($addr, 0, 30) . '...' : 'N/A'; ?>
          </span>
        </div>
      </div>

      <div class="summary-row">
        <span>Amount</span>
        <span>₹<?php echo number_format($order_total); ?></span>
      </div>

      <div class="summary-row total">
        <span>Total Amount Due</span>
        <span class="amount">₹<?php echo number_format($order_total); ?></span>
      </div>

      <div class="payment-methods-badge">
        <div class="badge">💳 Cards</div>
        <div class="badge">📱 UPI</div>
        <div class="badge">🏦 NetBanking</div>
        <div class="badge">💰 Wallet</div>
      </div>
    </div>
  </div>
</div>

<script>
// Auto-format card number
document.getElementById('card_number').addEventListener('input', function(e) {
  e.target.value = e.target.value.replace(/\s/g, '').replace(/(\d{4})/g, '$1 ').trim();
});

// Auto-format expiry
document.getElementById('expiry').addEventListener('input', function(e) {
  e.target.value = e.target.value.replace(/\D/g, '').replace(/(\d{2})(\d{1,})/, '$1/$2').substring(0, 5);
});

// CVV only numbers
document.getElementById('cvv').addEventListener('input', function(e) {
  e.target.value = e.target.value.replace(/\D/g, '').substring(0, 4);
});
</script>

<?php require 'includes/footer.php'; ?>
