<?php
require 'config/db.php';

$result = $mysqli->query("SELECT COUNT(*) as cnt FROM products");
$row = $result->fetch_assoc();
$count = $row['cnt'];

echo "========================================\n";
echo "   JEWELRY SHOP - WEBSITE STATUS\n";
echo "========================================\n\n";

echo "✅ DATABASE STATUS:\n";
echo "   Total Products: " . $count . "\n";

if ($count > 0) {
    echo "\n✅ WEBSITE READY!\n";
    echo "   Homepage: http://localhost/JSO/\n";
    echo "   Catalog:  http://localhost/JSO/catalog.php\n";
    echo "\n📌 TEST PAGINATION:\n";
    echo "   Page 1: http://localhost/JSO/catalog.php?page=1\n";
    echo "   Page 2: http://localhost/JSO/catalog.php?page=2\n";
    echo "\n📌 TEST SEARCH:\n";
    echo "   Search: http://localhost/JSO/catalog.php?q=ring\n";
    echo "\n📌 TEST FILTERS:\n";
    echo "   Category: http://localhost/JSO/catalog.php?cat=1\n";
    echo "   Price Range: http://localhost/JSO/catalog.php?price_min=1000&price_max=5000\n";
} else {
    echo "\n⚠️  NO PRODUCTS FOUND!\n";
    echo "   Please run database setup first.\n";
}

echo "\n========================================\n";
?>
