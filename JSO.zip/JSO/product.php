<?php
$body_class = 'diamond-shine-bg';
require 'includes/header.php';
$id = isset($_GET['id'])?intval($_GET['id']):0;
$stmt = $mysqli->prepare("SELECT p.*, c.name as category FROM products p LEFT JOIN categories c ON p.category_id=c.id WHERE p.id=?");
$stmt->bind_param('i',$id);
$stmt->execute();
$res = $stmt->get_result();
$product = $res->fetch_assoc();
$stmt->close();
if(!$product){ echo '<p>Product not found</p>'; require 'includes/footer.php'; exit; }

// Build gallery images: prefer product_images entries, fallback to placeholders derived from main image
$mainImage = $product['image'];
$anglesOrder = [
  ['key' => 'front', 'label' => 'Front'],
  ['key' => 'side', 'label' => 'Side View'],
  ['key' => 'back', 'label' => 'Back'],
  ['key' => 'top', 'label' => 'Top View'],
  ['key' => 'detail', 'label' => 'Detail'],
];
$imagesByAngle = [];
// Attempt to load product_images but don't let a missing table crash the page
try {
  $stmtPI = $mysqli->prepare("SELECT angle, image_url FROM product_images WHERE product_id = ?");
  if ($stmtPI) {
    $stmtPI->bind_param('i', $product['id']);
    $stmtPI->execute();
    $resPI = $stmtPI->get_result();
    if ($resPI) {
      while ($rowPI = $resPI->fetch_assoc()) {
        $imagesByAngle[$rowPI['angle']] = $rowPI['image_url'];
      }
    }
    $stmtPI->close();
  }
} catch (mysqli_sql_exception $e) {
  // Log and continue with fallback placeholder images
  error_log('product_images query failed: ' . $e->getMessage());
}

// Construct ordered list for gallery
$angleImages = [];
foreach ($anglesOrder as $a) {
  $key = $a['key'];
  $label = $a['label'];
  $url = $imagesByAngle[$key] ?? null;
  if (!$url) {
    // fallback: derive from main image for placeholders
    switch ($key) {
      case 'front':  $url = $mainImage; break;
      case 'side':   $url = str_replace('placeholder', 'placeholder-side', $mainImage); break;
      case 'back':   $url = str_replace('placeholder', 'placeholder-back', $mainImage); break;
      case 'top':    $url = str_replace('placeholder', 'placeholder-top', $mainImage); break;
      case 'detail': $url = str_replace('placeholder', 'placeholder-detail', $mainImage); break;
    }
  }
  $angleImages[] = ['url' => $url, 'angle' => $label];
}
?>

<style>
.product-detail-hero {
  background: linear-gradient(135deg, #fff9f2 0%, #ffffff 100%);
  padding: 40px 20px;
  border-radius: 16px;
  margin-bottom: 40px;
  box-shadow: 0 8px 32px rgba(205, 163, 79, 0.08);
}

.product-gallery-container {
  display: grid;
  grid-template-columns: 1fr 350px;
  gap: 30px;
  margin-bottom: 40px;
}

.main-gallery {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.main-image-wrapper {
  position: relative;
  background: #fff;
  border-radius: 12px;
  overflow: hidden;
  aspect-ratio: 1;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
  display: flex;
  align-items: center;
  justify-content: center;
}

.main-image-wrapper img {
  width: 100%;
  height: 100%;
  object-fit: contain;
  padding: 20px;
  transition: transform 0.3s ease;
}

.main-image-wrapper:hover img {
  transform: scale(1.05);
}

.angle-badge {
  position: absolute;
  top: 12px;
  right: 12px;
  background: linear-gradient(180deg, #cda34f, #b0852b);
  color: white;
  padding: 8px 16px;
  border-radius: 24px;
  font-size: 12px;
  font-weight: 600;
  box-shadow: 0 4px 12px rgba(205, 163, 79, 0.3);
}

.thumbnail-gallery {
  display: grid;
  grid-template-columns: repeat(5, 1fr);
  gap: 10px;
}

.thumbnail {
  position: relative;
  aspect-ratio: 1;
  border-radius: 10px;
  border: 2px solid #eee;
  cursor: pointer;
  overflow: hidden;
  background: #f9f9f9;
  transition: all 0.3s ease;
  display: flex;
  align-items: center;
  justify-content: center;
}

.thumbnail img {
  width: 100%;
  height: 100%;
  object-fit: contain;
  padding: 8px;
}

.thumbnail:hover {
  border-color: #cda34f;
  box-shadow: 0 6px 16px rgba(205, 163, 79, 0.2);
  transform: translateY(-4px);
}

.thumbnail.active {
  border-color: #cda34f;
  background: linear-gradient(135deg, rgba(205, 163, 79, 0.1), rgba(205, 163, 79, 0.05));
  box-shadow: 0 8px 20px rgba(205, 163, 79, 0.25);
}

.thumbnail-label {
  position: absolute;
  bottom: 4px;
  left: 4px;
  background: rgba(0, 0, 0, 0.6);
  color: white;
  padding: 3px 8px;
  border-radius: 4px;
  font-size: 10px;
  font-weight: 600;
}

.product-info-sidebar {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.info-card {
  background: white;
  padding: 20px;
  border-radius: 12px;
  border: 1px solid #eee;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.04);
}

.product-title {
  font-size: 28px;
  font-weight: 800;
  color: #222;
  margin: 0 0 12px 0;
  letter-spacing: -0.5px;
}

.product-category {
  color: #cda34f;
  font-weight: 600;
  font-size: 13px;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  margin-bottom: 12px;
}

.price-tag {
  font-size: 32px;
  font-weight: 900;
  color: #c0392b;
  margin: 12px 0;
  letter-spacing: -1px;
}

.specs-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 12px;
  margin: 16px 0;
  padding: 16px 0;
  border-top: 1px solid #eee;
  border-bottom: 1px solid #eee;
}

.spec-item {
  display: flex;
  flex-direction: column;
}

.spec-label {
  font-size: 12px;
  color: #999;
  font-weight: 600;
  text-transform: uppercase;
  margin-bottom: 4px;
}

.spec-value {
  font-size: 16px;
  color: #222;
  font-weight: 700;
}

.stock-indicator {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 10px 16px;
  background: #f0f0f0;
  border-radius: 8px;
  font-weight: 600;
  margin: 12px 0;
  font-size: 14px;
}

.stock-dot {
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background: #27ae60;
}

.stock-dot.low {
  background: #f39c12;
}

.stock-dot.out {
  background: #e74c3c;
}

.qty-selector {
  display: flex;
  align-items: center;
  gap: 12px;
  margin: 16px 0;
  background: #f9f9f9;
  padding: 12px;
  border-radius: 8px;
  width: fit-content;
}

.qty-btn {
  width: 32px;
  height: 32px;
  border: 1px solid #ddd;
  background: white;
  border-radius: 6px;
  cursor: pointer;
  font-weight: 600;
  transition: all 0.2s ease;
  color: #333;
}

.qty-btn:hover {
  background: #cda34f;
  color: white;
  border-color: #cda34f;
}

.qty-input {
  width: 50px;
  text-align: center;
  padding: 8px;
  border: 1px solid #ddd;
  border-radius: 6px;
  font-weight: 600;
}

.add-to-cart-btn {
  width: 100%;
  padding: 16px;
  background: linear-gradient(180deg, #cda34f, #b0852b);
  color: white;
  border: none;
  border-radius: 10px;
  font-size: 16px;
  font-weight: 700;
  cursor: pointer;
  transition: all 0.3s ease;
  box-shadow: 0 6px 20px rgba(205, 163, 79, 0.2);
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.add-to-cart-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 10px 30px rgba(205, 163, 79, 0.3);
  background: linear-gradient(180deg, #b0852b, #9a6e23);
}

.add-to-cart-btn:active {
  transform: translateY(0);
}

.wishlist-btn {
  width: 100%;
  padding: 12px;
  background: white;
  color: #cda34f;
  border: 2px solid #cda34f;
  border-radius: 10px;
  font-weight: 700;
  cursor: pointer;
  transition: all 0.3s ease;
  text-transform: uppercase;
  font-size: 13px;
  letter-spacing: 0.5px;
}

.wishlist-btn:hover {
  background: #cda34f;
  color: white;
}

.description-section {
  background: white;
  padding: 24px;
  border-radius: 12px;
  border: 1px solid #eee;
  line-height: 1.8;
  color: #555;
  margin: 30px 0;
}

.description-section h3 {
  color: #222;
  font-size: 18px;
  margin-top: 0;
  margin-bottom: 12px;
  font-weight: 700;
}

.features-list {
  list-style: none;
  padding: 0;
  margin: 16px 0;
}

.features-list li {
  padding: 10px 0;
  padding-left: 24px;
  position: relative;
  color: #555;
}

.features-list li:before {
  content: "✓";
  position: absolute;
  left: 0;
  color: #cda34f;
  font-weight: 800;
  font-size: 16px;
}

@media(max-width: 900px) {
  .product-gallery-container {
    grid-template-columns: 1fr;
  }
  
  .thumbnail-gallery {
    grid-template-columns: repeat(4, 1fr);
  }
  
  .product-title {
    font-size: 24px;
  }
}

@media(max-width: 600px) {
  .product-gallery-container {
    gap: 20px;
  }
  
  .main-image-wrapper {
    aspect-ratio: 0.8;
  }
  
  .thumbnail-gallery {
    grid-template-columns: repeat(3, 1fr);
    gap: 8px;
  }
  
  .specs-grid {
    grid-template-columns: 1fr;
  }
  
  .product-title {
    font-size: 20px;
  }
  
  .price-tag {
    font-size: 26px;
  }
}
</style>

<div class="container">
  <div class="product-detail-hero">
    
    <!-- Gallery Section -->
    <div class="product-gallery-container">
      <!-- Main Gallery -->
      <div class="main-gallery">
        <div class="main-image-wrapper" id="mainImageWrapper">
          <span class="angle-badge" id="angleBadge">Front</span>
          <img id="mainImage" src="<?=e(resolve_asset_url($mainImage))?>" alt="Product Image">
        </div>
        
        <!-- Thumbnail Gallery -->
        <div class="thumbnail-gallery" id="thumbnailGallery">
          <?php foreach($angleImages as $idx => $img): ?>
            <div class="thumbnail <?=$idx === 0 ? 'active' : ''?>" onclick="changeImage(this, '<?=e($img['url'])?>', '<?=e($img['angle'])?>')">
              <span class="thumbnail-label"><?=e($img['angle'])?></span>
              <img src="<?=e(resolve_asset_url($img['url']))?>" alt="<?=e($img['angle'])?>">
            </div>
          <?php endforeach; ?>
        </div>
      </div>

      <!-- Product Info Sidebar -->
      <div class="product-info-sidebar">
        
        <!-- Title & Price Card -->
        <div class="info-card">
          <div class="product-category"><?=e($product['category'])?></div>
          <h1 class="product-title"><?=e($product['name'])?></h1>
          <div class="price-tag">₹<?=number_format($product['price'], 2)?></div>

          <!-- Specs Grid -->
          <div class="specs-grid">
            <div class="spec-item">
              <div class="spec-label">Weight</div>
              <div class="spec-value"><?=e($product['weight'])?> g</div>
            </div>
            <div class="spec-item">
              <div class="spec-label">Category</div>
              <div class="spec-value"><?=e($product['category'])?></div>
            </div>
          </div>

          <!-- Stock Status -->
          <div class="stock-indicator">
            <div class="stock-dot <?=$product['stock'] > 5 ? '' : ($product['stock'] > 0 ? 'low' : 'out')?>"></div>
            <span>
              <?php 
                if($product['stock'] > 5) echo "In Stock (" . $product['stock'] . " left)";
                elseif($product['stock'] > 0) echo "Low Stock (" . $product['stock'] . " left)";
                else echo "Out of Stock";
              ?>
            </span>
          </div>
        </div>

        <!-- Quantity & Cart Card -->
        <div class="info-card">
          <label style="font-weight: 700; color: #222; display: block; margin-bottom: 12px;">Quantity</label>
          
          <div class="qty-selector">
            <button class="qty-btn" onclick="decreaseQty()">−</button>
            <input type="number" id="qty" class="qty-input" value="1" min="1" max="<?=$product['stock']?>" onchange="updateQty()">
            <button class="qty-btn" onclick="increaseQty()">+</button>
          </div>

          <a class="add-to-cart-btn" id="cartBtn" href="<?php echo base_url('/cart.php?action=add&id=' . $product['id'] . '&qty=1'); ?>" onclick="updateCartUrl(event)">
            🛒 Add to Cart
          </a>
          
          <button class="wishlist-btn" onclick="alert('Added to Wishlist! 💚')">❤️ Add to Wishlist</button>
        </div>

        <!-- Trust Badges -->
        <div class="info-card" style="background: linear-gradient(135deg, #fff9f2, #fffaf6); text-align: center; border: 1px solid rgba(205, 163, 79, 0.2);">
          <div style="font-size: 12px; color: #999; margin-bottom: 12px;">
            ✓ 100% Authentic<br>
            ✓ 7-Day Returns<br>
            ✓ Secure Payment
          </div>
        </div>
      </div>
    </div>

    <!-- Description Section -->
    <div class="description-section">
      <h3>✨ Product Details</h3>
      <p><?=nl2br(e($product['description']))?></p>
      
      <h3 style="margin-top: 24px;">💎 Features & Benefits</h3>
      <ul class="features-list">
        <li>Premium Quality Material</li>
        <li>Expertly Crafted Design</li>
        <li>Certified Authenticity</li>
        <li>Perfect for Any Occasion</li>
        <li>Lifetime Support & Care</li>
      </ul>

      <h3 style="margin-top: 24px;">📦 Shipping & Returns</h3>
      <p>
        Free shipping on all orders! Returns accepted within 7 days of delivery. 
        Every product comes with a certificate of authenticity and premium packaging.
      </p>
      
      <h3 style="margin-top: 24px;">⭐ Leave a Review</h3>
      <p>If you purchased this product, please share your rating and a short review.</p>

      <?php
      // Aggregate rating summary for this product
      $avgRating = 0.0;
      $ratingCount = 0;
      if (isset($mysqli) && $product['id']) {
          $stmtAgg = $mysqli->prepare("SELECT AVG(rating) AS avg_rating, COUNT(*) AS cnt FROM reviews WHERE product_id=? AND rating IS NOT NULL");
          if ($stmtAgg) {
              $stmtAgg->bind_param('i', $product['id']);
              $stmtAgg->execute();
              $resAgg = $stmtAgg->get_result();
              if ($resAgg) {
                  $rowA = $resAgg->fetch_assoc();
                  if ($rowA && $rowA['avg_rating'] !== null) {
                      $avgRating = (float)$rowA['avg_rating'];
                      $ratingCount = (int)$rowA['cnt'];
                  }
              }
              $stmtAgg->close();
          }
      }
      ?>

      <div style="margin-bottom:12px">
        <?php if ($ratingCount <= 0): ?>
          <div class="info-box">No ratings yet. Be the first to rate this product.</div>
        <?php else: ?>
          <div style="display:flex;align-items:center;gap:12px">
            <div style="font-size:20px;font-weight:800;color:#c0392b"><?= number_format($avgRating, 1) ?></div>
            <div>
              <?php
                // Render 5 stars with half-star support using a left->right gradient for halves
                $gradId = 'starGrad' . (int)$product['id'];
              ?>
              <svg style="height:0;width:0;position:absolute;left:-9999px;" aria-hidden="true">
                <defs>
                  <linearGradient id="<?= $gradId ?>" x1="0%" x2="100%" y1="0%" y2="0%">
                    <stop offset="50%" stop-color="#cda34f" />
                    <stop offset="50%" stop-color="#ddd" />
                  </linearGradient>
                </defs>
              </svg>
              <?php
                for ($i = 1; $i <= 5; $i++) {
                  if ($avgRating >= $i) {
                    // full star
                    echo '<svg width="18" height="18" viewBox="0 0 24 24" aria-hidden="true" style="vertical-align:middle;margin-right:2px"><path fill="#cda34f" d="M12 .587l3.668 7.431L23.6 9.75l-5.8 5.656L19.335 24 12 19.897 4.665 24l1.535-8.594L.4 9.75l7.932-1.732z"/></svg>';
                  } elseif ($avgRating >= ($i - 0.5)) {
                    // half star using gradient
                    echo '<svg width="18" height="18" viewBox="0 0 24 24" aria-hidden="true" style="vertical-align:middle;margin-right:2px"><path fill="url(#' . $gradId . ')" d="M12 .587l3.668 7.431L23.6 9.75l-5.8 5.656L19.335 24 12 19.897 4.665 24l1.535-8.594L.4 9.75l7.932-1.732z"/></svg>';
                  } else {
                    // empty star
                    echo '<svg width="18" height="18" viewBox="0 0 24 24" aria-hidden="true" style="vertical-align:middle;margin-right:2px"><path fill="#ddd" d="M12 .587l3.668 7.431L23.6 9.75l-5.8 5.656L19.335 24 12 19.897 4.665 24l1.535-8.594L.4 9.75l7.932-1.732z"/></svg>';
                  }
                }
              ?>
            </div>
            <div style="color:#666;font-size:13px"><?= $ratingCount ?> rating<?= $ratingCount > 1 ? 's' : '' ?></div>
          </div>
        <?php endif; ?>
      </div>

      <div id="feedbackResult" style="margin-bottom:12px"></div>

      <form id="feedbackForm" method="post">
          <?php echo csrf_input(); ?>
        <input type="hidden" name="product_id" value="<?= e($product['id']) ?>">
        <div style="display:flex;gap:12px;flex-wrap:wrap">
          <label style="flex:0 0 200px">
            Rating
            <select name="rating" required>
              <option value="">--</option>
              <option value="5">5 — Excellent</option>
              <option value="4.5">4.5 — Very Good</option>
              <option value="4">4 — Very Good</option>
              <option value="3.5">3.5 — Good</option>
              <option value="3">3 — Good</option>
              <option value="2.5">2.5 — Fair</option>
              <option value="2">2 — Fair</option>
              <option value="1.5">1.5 — Poor</option>
              <option value="1">1 — Poor</option>
            </select>
          </label>

          <label style="flex:1 1 300px">
            Review
            <textarea name="comment" rows="3" placeholder="Write your review (optional)" style="width:100%"></textarea>
          </label>
        </div>

        <div style="margin-top:10px;display:flex;gap:8px">
          <button type="submit" class="add-to-cart-btn" style="width:auto;padding:10px 16px">Submit Review</button>
        </div>
      </form>
        <?php
        // Fetch paginated reviews for this product
        $reviews = [];
        $review_page = 1; // initial page served server-side
        $perPage = 10; // initial page size (and AJAX page size)
        $offset = ($review_page - 1) * $perPage;
        $totalReviews = 0;
        if (isset($mysqli) && $product['id']) {
          // Count total
          $stmtCount = $mysqli->prepare("SELECT COUNT(*) FROM reviews WHERE product_id=?");
          if ($stmtCount) {
            $stmtCount->bind_param('i', $product['id']);
            $stmtCount->execute();
            $stmtCount->bind_result($totalReviews);
            $stmtCount->fetch();
            $stmtCount->close();
          }

          $totalPages = max(1, (int)ceil($totalReviews / $perPage));

          // Fetch page of reviews (safe because $perPage and $offset are integers controlled server-side)
          $sql = "SELECT r.rating, r.comment, r.created_at, u.name as user_name FROM reviews r LEFT JOIN users u ON r.user_id=u.id WHERE r.product_id=? ORDER BY r.created_at DESC LIMIT $perPage OFFSET $offset";
          $stmt = $mysqli->prepare($sql);
          if ($stmt) {
            $stmt->bind_param('i', $product['id']);
            $stmt->execute();
            $res = $stmt->get_result();
            if ($res) {
              $reviews = $res->fetch_all(MYSQLI_ASSOC);
            }
            $stmt->close();
          }
        }
        ?>

        <div id="reviewsList" style="margin-top:18px">
        <h4 style="margin-bottom:8px">Recent Reviews</h4>
        <?php if (empty($reviews)): ?>
          <div class="info-box">Be the first to review this product.</div>
        <?php else: ?>
          <?php foreach ($reviews as $r): ?>
            <div class="info-card" style="margin-bottom:10px;padding:12px;">
              <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px">
                <div style="font-weight:700;color:#222"><?= e($r['user_name'] ?: 'Anonymous') ?></div>
                <div style="color:#999;font-size:13px"><?= date('j M Y', strtotime($r['created_at'])) ?></div>
              </div>
              <div style="margin-bottom:8px">
                <?php
                  $rating = is_null($r['rating']) ? 0.0 : (float)$r['rating'];
                  // ensure gradient id exists (defined above for average rating)
                  if (empty($gradId)) $gradId = 'starGrad' . (int)$product['id'];
                  for ($s=1;$s<=5;$s++){
                    if ($rating >= $s) {
                      // full star
                      echo '<svg width="16" height="16" viewBox="0 0 24 24" aria-hidden="true" style="vertical-align:middle;margin-right:2px"><path fill="#cda34f" d="M12 .587l3.668 7.431L23.6 9.75l-5.8 5.656L19.335 24 12 19.897 4.665 24l1.535-8.594L.4 9.75l7.932-1.732z"/></svg>';
                    } elseif ($rating >= ($s - 0.5)) {
                      // half star using gradient
                      echo '<svg width="16" height="16" viewBox="0 0 24 24" aria-hidden="true" style="vertical-align:middle;margin-right:2px"><path fill="url(#' . $gradId . ')" d="M12 .587l3.668 7.431L23.6 9.75l-5.8 5.656L19.335 24 12 19.897 4.665 24l1.535-8.594L.4 9.75l7.932-1.732z"/></svg>';
                    } else {
                      // empty star
                      echo '<svg width="16" height="16" viewBox="0 0 24 24" aria-hidden="true" style="vertical-align:middle;margin-right:2px"><path fill="#ddd" d="M12 .587l3.668 7.431L23.6 9.75l-5.8 5.656L19.335 24 12 19.897 4.665 24l1.535-8.594L.4 9.75l7.932-1.732z"/></svg>';
                    }
                  }
                ?>
              </div>
              <?php if (trim($r['comment']) !== ''): ?>
                <div style="color:#444;line-height:1.5"><?= nl2br(e($r['comment'])) ?></div>
              <?php else: ?>
                <div style="color:#777;font-size:13px">(No comment)</div>
              <?php endif; ?>
            </div>
          <?php endforeach; ?>
        <?php endif; ?>
        <?php if (!empty($totalReviews) && $totalReviews > $perPage): ?>
          <div id="reviewControls" style="margin-top:12px;text-align:left;display:flex;align-items:center;gap:10px">
            <div id="reviewCounter" style="color:#666;font-size:13px">Showing <?= count($reviews) ?> of <?= (int)$totalReviews ?> reviews</div>
            <div id="loadMoreSpinner" style="display:none;color:#666;font-size:13px">Loading…</div>
          </div>
          <div id="reviewsSentinel" style="height:1px"></div>
        <?php endif; ?>
      </div>

      <script>
        // Feedback form submit via AJAX to submit_feedback.php
        ;(function(){
          const form = document.getElementById('feedbackForm');
          if(!form) return;
          const resultBox = document.getElementById('feedbackResult');

          form.addEventListener('submit', async function(ev){
            ev.preventDefault();
            if(!window.APP_BASE) window.APP_BASE = '';
            const url = (window.APP_BASE || '') + 'submit_feedback.php';
            const btn = form.querySelector('button[type="submit"]');
            const originalText = btn ? btn.textContent : null;
            if(btn) { btn.disabled = true; btn.textContent = 'Submitting...'; }

            try{
              const fd = new FormData(form);
              const resp = await fetch(url, {
                method: 'POST',
                credentials: 'same-origin',
                body: fd
              });
              const data = await resp.json().catch(()=>({ success:false, error: 'Invalid JSON response' }));
              if(!resp.ok){
                resultBox.innerHTML = '<div class="error">' + (data.error || ('HTTP ' + resp.status)) + '</div>';
              } else if(data.success){
                resultBox.innerHTML = '<div class="success">✅ Review submitted. Thank you!</div>';
                form.reset();
                // Reload after a short delay so the new review appears in the list
                setTimeout(function(){ location.reload(); }, 900);
              } else {
                resultBox.innerHTML = '<div class="error">' + (data.error || 'Failed to submit review') + '</div>';
              }
            }catch(err){
              resultBox.innerHTML = '<div class="error">Network error: '+String(err)+'</div>';
            }finally{
              if(btn){ btn.disabled = false; if(originalText) btn.textContent = originalText; }
            }
          });
        })();
        </script>
      <script>
      // Infinite scroll for reviews
      (function(){
        // Infinite scroll implementation
        const spinner = document.getElementById('loadMoreSpinner');
        const reviewsContainer = document.getElementById('reviewsList');
        const sentinel = document.getElementById('reviewsSentinel');
        const counterEl = document.getElementById('reviewCounter');
        const productId = <?= (int)$product['id'] ?>;
        const perPage = <?= (int)$perPage ?>;
        let nextPage = 2;
        let loading = false;
        let loadedCount = <?= count($reviews) ?>;
        const totalReviewsJS = <?= (int)$totalReviews ?>;
        const gradId = '<?= isset($gradId) ? $gradId : ('starGrad' . (int)$product['id']) ?>';

        function renderStars(rating, small){
          small = !!small;
          const w = small ? 16 : 18;
          let out = '';
          for(let s=1;s<=5;s++){
            if(rating >= s){
              out += `<svg width="${w}" height="${w}" viewBox="0 0 24 24" aria-hidden="true" style="vertical-align:middle;margin-right:2px"><path fill="#cda34f" d="M12 .587l3.668 7.431L23.6 9.75l-5.8 5.656L19.335 24 12 19.897 4.665 24l1.535-8.594L.4 9.75l7.932-1.732z"/></svg>`;
            } else if (rating >= (s - 0.5)){
              out += `<svg width="${w}" height="${w}" viewBox="0 0 24 24" aria-hidden="true" style="vertical-align:middle;margin-right:2px"><path fill="url(#${gradId})" d="M12 .587l3.668 7.431L23.6 9.75l-5.8 5.656L19.335 24 12 19.897 4.665 24l1.535-8.594L.4 9.75l7.932-1.732z"/></svg>`;
            } else {
              out += `<svg width="${w}" height="${w}" viewBox="0 0 24 24" aria-hidden="true" style="vertical-align:middle;margin-right:2px"><path fill="#ddd" d="M12 .587l3.668 7.431L23.6 9.75l-5.8 5.656L19.335 24 12 19.897 4.665 24l1.535-8.594L.4 9.75l7.932-1.732z"/></svg>`;
            }
          }
          return out;
        }

        async function loadPage(page){
          if(loading) return;
          loading = true; spinner.style.display = '';
          try{
            const resp = await fetch((window.APP_BASE || '') + 'reviews_ajax.php?product_id=' + productId + '&page=' + page + '&per_page=' + perPage, { credentials: 'same-origin' });
            const data = await resp.json();
            if(!data.success){
              console.error('reviews load error', data);
              return;
            }
            // append reviews
            data.reviews.forEach(r => {
              const div = document.createElement('div');
              div.className = 'info-card';
              div.style = 'margin-bottom:10px;padding:12px;';
              const date = new Date(r.created_at);
              const dateStr = date.toLocaleDateString();
              const user = document.createElement('div');
              user.style = 'display:flex;align-items:center;justify-content:space-between;margin-bottom:6px';
              user.innerHTML = '<div style="font-weight:700;color:#222">' + (r.user_name || 'Anonymous') + '</div>' + '<div style="color:#999;font-size:13px">' + dateStr + '</div>';
              const stars = document.createElement('div');
              stars.style.marginBottom = '8px';
              stars.innerHTML = renderStars(r.rating || 0.0, true);
              const comment = document.createElement('div');
              if(r.comment && r.comment.trim() !== ''){
                // escape HTML
                const txt = document.createElement('div');
                txt.textContent = r.comment;
                comment.innerHTML = '<div style="color:#444;line-height:1.5">' + txt.innerHTML.replace(/\n/g,'<br/>') + '</div>';
              } else {
                comment.innerHTML = '<div style="color:#777;font-size:13px">(No comment)</div>';
              }
              div.appendChild(user);
              div.appendChild(stars);
              div.appendChild(comment);
              // insert before sentinel
              const sentinelEl = document.getElementById('reviewsSentinel');
              reviewsContainer.insertBefore(div, sentinelEl);
              loadedCount++;
            });

            // update counter
            if(counterEl) counterEl.textContent = 'Showing ' + loadedCount + ' of ' + totalReviewsJS + ' reviews';

            if(!data.has_more){
              // no more: disconnect observer and hide spinner
              if(observer) observer.disconnect();
              spinner.style.display = 'none';
            } else {
              nextPage = page + 1;
            }
          }catch(err){
            console.error(err);
          }finally{
            loading = false; spinner.style.display = 'none';
          }
        }

        // IntersectionObserver to auto-load when sentinel visible
        let observer = null;
        if(window.IntersectionObserver){
          observer = new IntersectionObserver(function(entries){
            entries.forEach(en => {
              if(en.isIntersecting && !loading){
                loadPage(nextPage);
              }
            });
          }, { root: null, rootMargin: '200px', threshold: 0.1 });
          const sentinelEl = document.getElementById('reviewsSentinel');
          if(sentinelEl) observer.observe(sentinelEl);
        } else {
          // fallback: use scroll event
          window.addEventListener('scroll', function(){
            if(loading) return;
            const rect = document.body.getBoundingClientRect();
            if(rect.bottom - window.innerHeight < 600){
              loadPage(nextPage);
            }
          });
        }
      })();
      </script>
    </div>

  </div>
</div>

<script>
function changeImage(element, url, angle) {
  // Update main image
  document.getElementById('mainImage').src = url;
  document.getElementById('angleBadge').textContent = angle;
  
  // Update active thumbnail
  document.querySelectorAll('.thumbnail').forEach(el => el.classList.remove('active'));
  element.classList.add('active');
}

function increaseQty() {
  const input = document.getElementById('qty');
  const max = parseInt(input.max);
  if(parseInt(input.value) < max) {
    input.value = parseInt(input.value) + 1;
    updateQty();
  }
}

function decreaseQty() {
  const input = document.getElementById('qty');
  if(parseInt(input.value) > 1) {
    input.value = parseInt(input.value) - 1;
    updateQty();
  }
}

function updateQty() {
  const qty = document.getElementById('qty').value;
  updateCartUrl();
}

function updateCartUrl(e) {
  if(e) e.preventDefault();
  const qty = document.getElementById('qty').value;
  const baseUrl = '<?php echo base_url('/cart.php?action=add&id=' . $product['id'] . '&qty='); ?>';
  document.getElementById('cartBtn').href = baseUrl + qty;
  
  // If called from button click, navigate
  if(e) {
    window.location.href = baseUrl + qty;
  }
}
</script>

<?php require 'includes/footer.php';?>
