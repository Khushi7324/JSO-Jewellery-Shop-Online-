<?php
session_start();
require 'config/db.php';

$setup_completed = false;
$error = '';
$success = '';
$setup_key = 'JSO_ADMIN_SETUP_2024';

// Check if setup is already completed
$stmt = $mysqli->prepare("SELECT COUNT(*) as cnt FROM users WHERE is_admin=1");
$stmt->execute();
$result = $stmt->get_result()->fetch_assoc();
$stmt->close();
$admin_exists = $result['cnt'] > 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $provided_key = $_POST['setup_key'] ?? '';
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $confirm_password = trim($_POST['confirm_password'] ?? '');

    // Verify setup key
    if ($provided_key !== $setup_key) {
        $error = 'Invalid setup key. Cannot create admin account without proper authorization.';
    } elseif ($admin_exists) {
        $error = 'Admin account already exists. Contact existing admin for additional accounts.';
    } elseif (empty($email) || empty($password)) {
        $error = 'Please fill all fields';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters';
    } elseif ($password !== $confirm_password) {
        $error = 'Passwords do not match';
    } else {
        // Create admin account
        $hashed = password_hash($password, PASSWORD_BCRYPT);
        $name = 'Admin';
        $phone = '0000000000';
        $is_admin = 1;

        $stmt = $mysqli->prepare("INSERT INTO users (name, phone, email, password, is_admin) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param('ssssi', $name, $phone, $email, $hashed, $is_admin);
        
        if ($stmt->execute()) {
            $success = '✅ Admin account created successfully! Redirecting to admin login...';
              $setup_completed = true;
              header('Refresh: 3; url=' . base_url('/admin/login.php'));
        } else {
            $error = 'Error creating account: ' . $stmt->error;
        }
        $stmt->close();
    }
}

?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Admin Setup - Jewelry Shop</title>
  <style>
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen', 'Ubuntu', 'Cantarell', sans-serif;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      margin: 0;
      padding: 20px;
    }

    .setup-card {
      background: white;
      padding: 40px;
      border-radius: 10px;
      box-shadow: 0 10px 40px rgba(0,0,0,0.2);
      max-width: 400px;
      width: 100%;
    }

    .setup-title {
      text-align: center;
      font-size: 28px;
      font-weight: 900;
      color: #333;
      margin-bottom: 10px;
    }

    .setup-subtitle {
      text-align: center;
      color: #666;
      margin-bottom: 30px;
      font-size: 14px;
    }

    .warning {
      background: #fff3cd;
      border: 1px solid #ffc107;
      color: #856404;
      padding: 12px;
      border-radius: 6px;
      margin-bottom: 20px;
      font-size: 13px;
      line-height: 1.6;
    }

    .error {
      background: #f8d7da;
      border: 1px solid #f5c6cb;
      color: #721c24;
      padding: 12px;
      border-radius: 6px;
      margin-bottom: 20px;
      font-size: 13px;
    }

    .success {
      background: #d4edda;
      border: 1px solid #c3e6cb;
      color: #155724;
      padding: 12px;
      border-radius: 6px;
      margin-bottom: 20px;
      font-size: 13px;
    }

    .info {
      background: #e2e3e5;
      border: 1px solid #d3d3d3;
      color: #383d41;
      padding: 12px;
      border-radius: 6px;
      margin-bottom: 20px;
      font-size: 13px;
      font-family: 'Courier New', monospace;
    }

    .form-group {
      margin-bottom: 20px;
    }

    label {
      display: block;
      margin-bottom: 8px;
      color: #333;
      font-weight: 600;
      font-size: 14px;
    }

    input {
      width: 100%;
      padding: 12px;
      border: 1px solid #ddd;
      border-radius: 6px;
      font-size: 14px;
      box-sizing: border-box;
      transition: all 0.2s;
    }

    input:focus {
      outline: none;
      border-color: #667eea;
      box-shadow: 0 0 0 3px rgba(102,126,234,0.1);
    }

    button {
      width: 100%;
      padding: 12px;
      background: linear-gradient(180deg, #667eea, #764ba2);
      color: white;
      border: none;
      border-radius: 6px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.2s;
      font-size: 14px;
      margin-top: 10px;
    }

    button:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 20px rgba(102,126,234,0.4);
    }

    .setup-status {
      text-align: center;
      padding: 20px;
      background: #f5f5f5;
      border-radius: 6px;
      margin-bottom: 20px;
    }

    .status-icon {
      font-size: 48px;
      margin-bottom: 10px;
    }

    .status-text {
      color: #666;
      font-size: 14px;
    }
  </style>
</head>
<body>
  <div class="setup-card">
    <div class="setup-title">🔐 Admin Setup</div>
    <p class="setup-subtitle">Initialize Administrator Account</p>

    <?php if ($admin_exists && !$setup_completed): ?>
      <div class="setup-status">
        <div class="status-icon">✅</div>
        <div class="status-text">
          Admin account already exists<br>
          <a href="<?php echo base_url('/admin/login.php'); ?>" style="color: #667eea; font-weight: 600; text-decoration: none;">Go to Admin Login →</a>
        </div>
      </div>
    <?php endif; ?>

    <?php if (!$admin_exists): ?>
      <div class="warning">
        ⚠️ This is a one-time setup. Make sure you have the correct setup key before proceeding. Once admin is created, subsequent admins must be registered through the admin panel by existing admin users only.
      </div>

      <?php if ($error): ?>
        <div class="error">❌ <?php echo htmlspecialchars($error); ?></div>
      <?php endif; ?>

      <?php if ($success): ?>
        <div class="success">✅ <?php echo $success; ?></div>
      <?php else: ?>
        <form method="POST">
          <div class="form-group">
            <label for="setup_key">Setup Key *</label>
            <input type="password" id="setup_key" name="setup_key" placeholder="Enter setup key" required>
          </div>

          <div class="form-group">
            <label for="email">Admin Email *</label>
            <input type="email" id="email" name="email" placeholder="admin@example.com" required>
          </div>

          <div class="form-group">
            <label for="password">Password *</label>
            <input type="password" id="password" name="password" placeholder="Minimum 6 characters" required>
          </div>

          <div class="form-group">
            <label for="confirm_password">Confirm Password *</label>
            <input type="password" id="confirm_password" name="confirm_password" placeholder="Re-enter password" required>
          </div>

          <button type="submit">Create Admin Account</button>
        </form>
      <?php endif; ?>
    <?php else: ?>
      <div class="setup-status">
        <div class="status-icon">🔒</div>
        <div class="status-text">
          Admin account already initialized<br>
          Setup is complete
        </div>
      </div>
      <button onclick="location.href='<?php echo base_url('/admin/login.php'); ?>'" style="background: linear-gradient(180deg, #667eea, #764ba2);">Go to Admin Login</button>
    <?php endif; ?>

  </div>
</body>
</html>