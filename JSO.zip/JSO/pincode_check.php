<?php
require 'config/db.php';
$p = isset($_GET['p'])?trim($_GET['p']):'';
$express = false;
if ($p!==''){
    $express = in_array(substr($p,0,1), ['5','6']);
}
header('Content-Type: application/json');
echo json_encode(['express'=>$express]);
?>