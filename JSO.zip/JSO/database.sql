-- Database: jso_shop

CREATE DATABASE IF NOT EXISTS jso_shop DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE jso_shop;

-- users (with optional email, phone is unique login credential)
CREATE TABLE IF NOT EXISTS users(
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  email VARCHAR(150),
  phone VARCHAR(20) UNIQUE NOT NULL,
  dob DATE,
  address TEXT,
  password VARCHAR(255) NOT NULL,
  role ENUM('user','admin') DEFAULT 'user',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- categories
CREATE TABLE IF NOT EXISTS categories(
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL
);

-- products
CREATE TABLE IF NOT EXISTS products(
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(200) NOT NULL,
  description TEXT,
  price DECIMAL(10,2) NOT NULL,
  weight DECIMAL(10,3) DEFAULT 0,
  category_id INT,
  stock INT DEFAULT 0,
  image VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
);

-- cart
CREATE TABLE IF NOT EXISTS cart(
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  product_id INT NOT NULL,
  quantity INT DEFAULT 1,
  added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

-- orders
CREATE TABLE IF NOT EXISTS orders(
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  total DECIMAL(12,2) NOT NULL,
  payment_mode VARCHAR(50),
  pincode VARCHAR(10),
  address TEXT,
  status VARCHAR(50) DEFAULT 'Pending',
  payment_status VARCHAR(50) DEFAULT 'Pending',
  order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- order_items
CREATE TABLE IF NOT EXISTS order_items(
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  product_id INT,
  quantity INT NOT NULL,
  price DECIMAL(10,2) NOT NULL,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL
);

-- delivery_status
CREATE TABLE IF NOT EXISTS delivery_status(
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  status VARCHAR(50) NOT NULL,
  update_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
);

-- sample categories
INSERT INTO categories(name) VALUES
("Gold"),("Diamond"),("Platinum"),("Gemstone"),("Silver");

-- sample products
INSERT INTO products(name,description,price,weight,category_id,stock,image) VALUES
("Classic Gold Ring","Elegant 22K gold ring","299.00",3.25,1,10,"https://via.placeholder.com/400x300?text=Gold+Ring"),
("Diamond Pendant","Brilliant cut diamond pendant","1599.00",2.10,2,5,"https://via.placeholder.com/400x300?text=Diamond+Pendant"),
("Platinum Band","Sleek platinum wedding band","899.00",4.50,3,7,"https://via.placeholder.com/400x300?text=Platinum+Band"),
("Emerald Necklace","Green emerald gemstone necklace","499.00",5.00,4,3,"https://via.placeholder.com/400x300?text=Emerald+Necklace");

-- Note: No admin user inserted here. Run `setup_admin.php` to create an admin account with hashed password.