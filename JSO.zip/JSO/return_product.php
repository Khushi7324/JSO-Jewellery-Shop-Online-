<?php
session_start();
require 'config/db.php';
require 'includes/functions.php';

require_login();

$user_id = $_SESSION['user_id'];
$order_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$csrf_token = ensure_csrf_token();

// Fetch order and ensure ownership
$stmt = $mysqli->prepare("SELECT * FROM orders WHERE id=? AND user_id=?");
$stmt->bind_param('ii', $order_id, $user_id);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Check if order exists and is delivered/completed
if (!$order || !in_array(strtolower($order['status']), ['delivered', 'completed'], true)) {
    die('Invalid order or not eligible for return.');
}

// Check if within 7-day return window
$stmt = $mysqli->prepare("SELECT update_time FROM delivery_status WHERE order_id=? AND (status='Completed' OR status='Delivered') ORDER BY update_time DESC LIMIT 1");
$stmt->bind_param('i', $order_id);
$stmt->execute();
$deliveredEntry = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$deliveredEntry) {
    die('Delivery date not found');
}

$deliveryDate = new DateTime($deliveredEntry['update_time']);
$today = new DateTime();
$daysSinceDelivery = $today->diff($deliveryDate)->days;

if ($daysSinceDelivery > 7) {
    die('Return window expired. Returns are only accepted within 7 days of delivery.');
}

// Fetch items with product name/price
$stmt = $mysqli->prepare("SELECT oi.*, p.name, p.price FROM order_items oi JOIN products p ON p.id = oi.product_id WHERE oi.order_id=?");
$stmt->bind_param('i', $order_id);
$stmt->execute();
$items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        $error = 'Security check failed. Please retry.';
    } else {
        $items_to_return = $_POST['items'] ?? [];
        $return_reason = trim($_POST['reason'] ?? '');
        $return_notes = trim($_POST['notes'] ?? '');

        if (empty($items_to_return)) {
            $error = 'Please select at least one item to return';
        } elseif (empty($return_reason)) {
            $error = 'Please select a return reason';
        } else {
            $return_total = 0;
            foreach ($items as $item) {
                if (in_array($item['id'], $items_to_return)) {
                    $return_total += $item['price'] * $item['quantity'];
                }
            }

            $stmt = $mysqli->prepare("INSERT INTO returns (order_id, user_id, items_json, reason, notes, return_total, status, created_at) VALUES (?, ?, ?, ?, ?, ?, 'pending', NOW())");
            $items_json = json_encode($items_to_return);
            $stmt->bind_param('iisssd', $order_id, $user_id, $items_json, $return_reason, $return_notes, $return_total);
            
            if ($stmt->execute()) {
                $success = 'Return request submitted successfully! You will receive a return label via email.';
            } else {
                $error = 'Error processing return. Please try again.';
            }
            $stmt->close();
        }
    }
}

$body_class = 'gold-glitter-bg';
require 'includes/header.php';
?>

<style>
.return-container {
  max-width: 600px;
  margin: 40px auto;
  padding: 30px;
  background: white;
  border-radius: 10px;
  box-shadow: 0 4px 20px rgba(0,0,0,0.1);
  border-left: 4px solid #ff9800;
}

.return-title {
  color: #333;
  font-size: 24px;
  font-weight: 700;
  margin-bottom: 10px;
}

.return-subtitle {
  color: #666;
  font-size: 14px;
  margin-bottom: 20px;
}

.info-box {
  background: #fff3e0;
  border: 1px solid #ffe0b2;
  border-radius: 6px;
  padding: 12px;
  margin-bottom: 20px;
  font-size: 13px;
  color: #e65100;
}

.items-section {
  margin-bottom: 25px;
}

.items-title {
  font-weight: 700;
  color: #333;
  margin-bottom: 12px;
}

.item-checkbox {
  display: flex;
  align-items: center;
  padding: 10px;
  border: 1px solid #eee;
  border-radius: 6px;
  margin-bottom: 8px;
  cursor: pointer;
  transition: all 0.2s;
}

.item-checkbox:hover {
  background: #f5f5f5;
}

.item-checkbox input[type="checkbox"] {
  width: 18px;
  height: 18px;
  margin-right: 12px;
  cursor: pointer;
  accent-color: #ff9800;
}

.item-label {
  flex: 1;
  cursor: pointer;
}

.item-name {
  font-weight: 600;
  color: #333;
  margin-bottom: 2px;
}

.item-qty {
  font-size: 13px;
  color: #666;
}

.item-price {
  font-weight: 700;
  color: #ff9800;
}

.form-group {
  margin-bottom: 20px;
}

.form-group label {
  display: block;
  margin-bottom: 8px;
  color: #333;
  font-weight: 600;
  font-size: 14px;
}

.form-group select,
.form-group textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ddd;
  border-radius: 6px;
  font-size: 14px;
  font-family: inherit;
  box-sizing: border-box;
}

.form-group select:focus,
.form-group textarea:focus {
  outline: none;
  border-color: #ff9800;
  box-shadow: 0 0 0 3px rgba(255,152,0,0.1);
}

.form-group textarea {
  resize: vertical;
  min-height: 80px;
}

.error {
  color: #d32f2f;
  font-size: 13px;
  margin-bottom: 15px;
  padding: 10px;
  background: #ffebee;
  border-radius: 6px;
  border-left: 3px solid #d32f2f;
}

.success {
  color: #388e3c;
  font-size: 13px;
  margin-bottom: 15px;
  padding: 10px;
  background: #e8f5e9;
  border-radius: 6px;
  border-left: 3px solid #388e3c;
}

.buttons {
  display: flex;
  gap: 10px;
}

button {
  flex: 1;
  padding: 12px;
  border: none;
  border-radius: 6px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s;
  font-size: 14px;
}

.btn-submit {
  background: #ff9800;
  color: white;
}

.btn-submit:hover {
  background: #e65100;
  transform: translateY(-2px);
}

.btn-back {
  background: #f5f5f5;
  color: #333;
  border: 1px solid #ddd;
}

.btn-back:hover {
  background: #efefef;
}
</style>

<div class="return-container">
  <h1 class="return-title">↩️ Return Product</h1>
  <p class="return-subtitle">Order #<?php echo e($order['id']); ?> - Initiate return</p>

  <div class="info-box">
    ℹ️ Returns are accepted within 7 days of delivery. Please select items you want to return and provide a reason.
  </div>

  <?php if ($error): ?>
    <div class="error">❌ <?php echo e($error); ?></div>
  <?php endif; ?>

  <?php if ($success): ?>
    <div class="success">✅ <?php echo e($success); ?></div>
  <?php endif; ?>

  <form method="POST">
    <input type="hidden" name="csrf_token" value="<?php echo e($csrf_token); ?>">
    <div class="items-section">
      <div class="items-title">Select Items to Return</div>
      <?php foreach ($items as $item): ?>
        <label class="item-checkbox">
          <input type="checkbox" name="items[]" value="<?php echo $item['id']; ?>">
          <div class="item-label">
            <div class="item-name"><?php echo e($item['name']); ?></div>
            <div class="item-qty">Quantity: <?php echo $item['quantity']; ?> × ₹<?php echo number_format($item['price']); ?></div>
          </div>
          <div class="item-price">₹<?php echo number_format($item['quantity'] * $item['price']); ?></div>
        </label>
      <?php endforeach; ?>
    </div>

    <div class="form-group">
      <label for="reason">Return Reason *</label>
      <select id="reason" name="reason" required>
        <option value="">-- Select a reason --</option>
        <option value="defective">Product is defective/damaged</option>
        <option value="not_as_described">Not as described</option>
        <option value="wrong_item">Received wrong item</option>
        <option value="not_satisfied">Not satisfied with quality</option>
        <option value="size_issue">Size/fit issue</option>
        <option value="other">Other reason</option>
      </select>
    </div>

    <div class="form-group">
      <label for="notes">Additional Notes (Optional)</label>
      <textarea id="notes" name="notes" placeholder="Describe the issue in detail..."></textarea>
    </div>

    <div class="buttons">
      <button type="button" class="btn-back" onclick="history.back()">← Go Back</button>
      <button type="submit" class="btn-submit">Submit Return Request</button>
    </div>
  </form>
</div>

<?php require 'includes/footer.php'; ?>
