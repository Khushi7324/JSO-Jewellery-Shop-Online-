<?php
// tools/test_update_product_ajax_more_edgecases.php
// Additional edge-case tests for update-product-ajax.php

$base = 'http://localhost/JSO';
$cookieFile = sys_get_temp_dir() . '/jso_test_admin_ajax_more_cookies.txt';
@unlink($cookieFile);

function curl_get($url, &$info=null, $cookieFile=null){
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 15);
    if($cookieFile){ curl_setopt($ch, CURLOPT_COOKIEJAR, $cookieFile); curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieFile); }
    $body = curl_exec($ch);
    $info = curl_getinfo($ch);
    $err = curl_error($ch);
    curl_close($ch);
    if($err) throw new Exception('cURL GET error: '.$err);
    return $body;
}
function curl_post($url, $postFields, &$info=null, $cookieFile=null, $headers = []){
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 15);
    if($cookieFile){ curl_setopt($ch, CURLOPT_COOKIEJAR, $cookieFile); curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieFile); }
    curl_setopt($ch, CURLOPT_POST, true);
    if (!empty($headers)) curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postFields);
    $body = curl_exec($ch);
    $info = curl_getinfo($ch);
    $err = curl_error($ch);
    curl_close($ch);
    if($err) throw new Exception('cURL POST error: '.$err);
    return $body;
}

try {
    echo "Starting extended AJAX edge-case tests...\n";
    require_once __DIR__ . '/../config/db.php';

    // Create a product for tests
    $name = 'AJAX_EDGE_' . time();
    $stmt = $mysqli->prepare("INSERT INTO products (name, description, price, weight, category_id, stock, image, created_at) VALUES (?, '', 10.0, 1.0, 1, 1, 'uploads/placeholder.svg', NOW())");
    if(!$stmt) throw new Exception('DB prepare failed: '.$mysqli->error);
    $stmt->bind_param('s', $name);
    if(!$stmt->execute()) throw new Exception('DB insert failed: '.$stmt->error);
    $id = $mysqli->insert_id;
    $stmt->close();
    echo "Created product $id for tests\n";

    // Login admin and get CSRF
    $loginPage = curl_get($base . '/admin/login.php', $info, $cookieFile);
    $loginResp = curl_post($base . '/admin/login.php', ['email'=>'admin@example.com','password'=>'admin123'], $info, $cookieFile);
    $pl = curl_get($base . '/admin/products-list.php', $info, $cookieFile);
    if(!preg_match('/name="csrf_token" value="([0-9a-f]+)"/i', $pl, $m)) throw new Exception('CSRF token not found on admin page');
    $csrf = $m[1];
    echo "CSRF: $csrf\n";

    $do = function($payload) use ($base, $cookieFile, $csrf){
        $payload['csrf_token'] = $csrf;
        $resp = curl_post($base . '/admin/update-product-ajax.php', $payload, $info, $cookieFile);
        $http = $info['http_code'] ?? 0;
        $json = json_decode($resp, true);
        return [$http, $json, $resp];
    };

    // Test 1: Non-existent id
    echo "Test 1: Non-existent id...\n";
    list($http, $json, $raw) = $do(['id' => 9999999, 'price' => '1000']);
    if ($http !== 200 || !$json || empty($json['success'])) throw new Exception('Test 1 failed: got HTTP ' . $http . ' body=' . substr($raw,0,200));
    echo "Test 1 passed (endpoint returns success, no DB row expected).\n";

    // Test 2: Price with commas '1,234.56' -> 1234.56
    echo "Test 2: Comma-formatted price...\n";
    list($http, $json, $raw) = $do(['id' => $id, 'price' => '1,234.56']);
    if ($http !== 200 || !$json || empty($json['success'])) throw new Exception('Test 2 api failed');
    // Check DB
    $stmt = $mysqli->prepare('SELECT price FROM products WHERE id=?'); $stmt->bind_param('i',$id); $stmt->execute(); $stmt->bind_result($p); $stmt->fetch(); $stmt->close();
    if (abs((float)$p - 1234.56) > 0.001) throw new Exception('Test 2 DB value mismatch: ' . $p);
    echo "Test 2 passed, DB price = $p\n";

    // Test 3: Non-numeric price 'abc' -> 0.0
    echo "Test 3: Non-numeric price...\n";
    list($http, $json, $raw) = $do(['id' => $id, 'price' => 'abc']);
    if ($http !== 200 || !$json || empty($json['success'])) throw new Exception('Test 3 api failed');
    $stmt = $mysqli->prepare('SELECT price FROM products WHERE id=?'); $stmt->bind_param('i',$id); $stmt->execute(); $stmt->bind_result($p2); $stmt->fetch(); $stmt->close();
    if (abs((float)$p2 - 0.0) > 0.0001) throw new Exception('Test 3 DB value mismatch: ' . $p2);
    echo "Test 3 passed, DB price = $p2\n";

    // Test 4: Negative stock
    echo "Test 4: Negative stock...\n";
    list($http, $json, $raw) = $do(['id' => $id, 'stock' => '-10']);
    if ($http !== 200 || !$json || empty($json['success'])) throw new Exception('Test 4 api failed');
    $stmt = $mysqli->prepare('SELECT stock FROM products WHERE id=?'); $stmt->bind_param('i',$id); $stmt->execute(); $stmt->bind_result($s); $stmt->fetch(); $stmt->close();
    if ((int)$s !== -10) throw new Exception('Test 4 DB value mismatch: ' . $s);
    echo "Test 4 passed, DB stock = $s\n";

    // Test 5: Very large price (DB DECIMAL(10,2) may cap large values)
    echo "Test 5: Very large price...\n";
    $big = '1000000000000';
    list($http, $json, $raw) = $do(['id' => $id, 'price' => $big]);
    if ($http !== 200 || !$json || empty($json['success'])) throw new Exception('Test 5 api failed');
    $stmt = $mysqli->prepare('SELECT price FROM products WHERE id=?'); $stmt->bind_param('i',$id); $stmt->execute(); $stmt->bind_result($p3); $stmt->fetch(); $stmt->close();
    $p3f = (float)$p3;
    // Accept if DB stored a numeric value; if it capped to max allowed (e.g., 99999999.99), that's acceptable
    if (!is_numeric($p3) || $p3f < 0) throw new Exception('Test 5 DB value invalid: ' . $p3);
    if (abs($p3f - (float)$big) > 0.1) {
        // likely capped by DECIMAL(10,2) to max 99999999.99 — warn but pass
        if ($p3f <= 99999999.99) {
            echo "Test 5 passed with DB cap, DB price = $p3\n";
        } else {
            throw new Exception('Test 5 DB value unexpected: ' . $p3);
        }
    } else {
        echo "Test 5 passed, DB price = $p3\n";
    }

    // Test 6: SQL injection-like input
    echo "Test 6: SQL injection-like price input...\n";
    list($http, $json, $raw) = $do(['id' => $id, 'price' => "0; DROP TABLE products;"]);
    if ($http !== 200 || !$json || empty($json['success'])) throw new Exception('Test 6 api failed');
    // ensure table still exists
    $res = $mysqli->query('SHOW TABLES LIKE "products"');
    if (!$res || $res->num_rows === 0) throw new Exception('Test 6 failed: products table missing');
    echo "Test 6 passed (no injection).\n";

    // Test 7: Raw JSON POST (should fail CSRF and return 403)
    echo "Test 7: Raw JSON POST...\n";
    $jsonBody = json_encode(['id'=>$id, 'price'=>'55']);
    $resp = curl_post($base . '/admin/update-product-ajax.php', $jsonBody, $info, $cookieFile, ['Content-Type: application/json']);
    $http = $info['http_code'] ?? 0;
    if ($http !== 403) throw new Exception('Test 7 expected 403, got ' . $http . ' body=' . substr($resp,0,200));
    echo "Test 7 passed (raw JSON rejected due to missing CSRF).\n";

    // Cleanup
    $stmt = $mysqli->prepare('DELETE FROM products WHERE id = ?'); if ($stmt) { $stmt->bind_param('i',$id); $stmt->execute(); $stmt->close(); }

    echo "All extended edge-case tests passed.\n";
    exit(0);

} catch (Exception $e) {
    echo "TEST FAILURE: " . $e->getMessage() . "\n";
    if (isset($id) && isset($mysqli)) { $stmt = $mysqli->prepare('DELETE FROM products WHERE id=?'); if ($stmt) { $stmt->bind_param('i',$id); $stmt->execute(); $stmt->close(); } }
    exit(2);
}
