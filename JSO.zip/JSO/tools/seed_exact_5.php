<?php
// tools/seed_exact_5.php
// Ensures exactly 5 products exist per category.
// - Removes excess products (keeping oldest).
// - Adds missing products.

if (php_sapi_name() !== 'cli') {
    echo "This script must be run from command line." . PHP_EOL;
    exit(1);
}

require_once __DIR__ . '/../config/db.php';

// Fetch categories
$cats = [];
$res = $mysqli->query("SELECT id, name FROM categories");
if ($res) {
    while($r = $res->fetch_assoc()) $cats[] = $r;
}

if (empty($cats)) {
    echo "No categories found.\n";
    exit(1);
}

echo "Ensuring exactly 5 products per category...\n";

$targetCount = 5;

foreach ($cats as $cat) {
    $catId = intval($cat['id']);
    $catName = $cat['name'];

    // Get existing products for this category, ordered by ID (oldest first)
    $stmt = $mysqli->prepare("SELECT id FROM products WHERE category_id = ? ORDER BY id ASC");
    $stmt->bind_param('i', $catId);
    $stmt->execute();
    $res = $stmt->get_result();
    $existingIds = [];
    while ($row = $res->fetch_assoc()) {
        $existingIds[] = $row['id'];
    }
    $stmt->close();

    $currentCount = count($existingIds);
    echo "Category '$catName' (ID: $catId): Found $currentCount products. ";

    if ($currentCount > $targetCount) {
        // Delete excess
        $idsToDelete = array_slice($existingIds, $targetCount);
        if (!empty($idsToDelete)) {
            $idStr = implode(',', $idsToDelete);
            $mysqli->query("DELETE FROM products WHERE id IN ($idStr)");
            echo "Deleted " . count($idsToDelete) . " excess products.\n";
        }
    } elseif ($currentCount < $targetCount) {
        // Add missing
        $needed = $targetCount - $currentCount;
        echo "Adding $needed new products...\n";
        
        $insertSql = "INSERT INTO products (name, description, price, weight, category_id, stock, image, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())";
        $stmtInsert = $mysqli->prepare($insertSql);

        for ($i = 1; $i <= $needed; $i++) {
            // Generate distinct name based on total existing + i
            $itemNum = $currentCount + $i; 
            $name = "$catName Premium Item #$itemNum";
            $description = "High-quality $catName jewelry item. Perfect for any occasion. Series #$itemNum.";
            
            // Price logic
            switch (strtolower($catName)) {
                case 'gold': $price = rand(20000, 200000) / 100.0; break;
                case 'diamond': $price = rand(50000, 500000) / 100.0; break;
                case 'platinum': $price = rand(30000, 300000) / 100.0; break;
                case 'gemstone': $price = rand(15000, 150000) / 100.0; break;
                case 'silver': $price = rand(1000, 50000) / 100.0; break;
                default: $price = rand(1000, 200000) / 100.0;
            }
            
            $weight = rand(50, 500) / 100.0;
            $stock = rand(5, 50);
            $image = "https://via.placeholder.com/400x300?text=" . urlencode($catName . "+" . $itemNum);

            $stmtInsert->bind_param('ssdiiss', $name, $description, $price, $weight, $catId, $stock, $image);
            $stmtInsert->execute();
        }
        $stmtInsert->close();
        echo "Added $needed products.\n";
    } else {
        echo "Count is perfect.\n";
    }
}

// Recalculate gallery images for all products to ensure new ones have images
// We can reuse logic from seed_product_images.php or just call it.
// Let's just call the shell script for that to be clean.
echo "Syncing gallery images...\n";

// We'll do a quick inline sync for newly added items or all items
$angles = ['front','side','back','top','detail'];
$res = $mysqli->query("SELECT id, image FROM products");
$stmtImg = $mysqli->prepare("INSERT IGNORE INTO product_images (product_id, angle, image_url) VALUES (?, ?, ?)");
if ($res) {
    while ($row = $res->fetch_assoc()) {
        $pid = $row['id'];
        $img = $row['image'];
        foreach ($angles as $a) {
            $url = $img;
            if (strpos($img, 'placeholder') !== false) {
                 if ($a === 'side')   $url = str_replace('placeholder', 'placeholder-side', $img);
                 if ($a === 'back')   $url = str_replace('placeholder', 'placeholder-back', $img);
                 if ($a === 'top')    $url = str_replace('placeholder', 'placeholder-top', $img);
                 if ($a === 'detail') $url = str_replace('placeholder', 'placeholder-detail', $img);
            }
            $stmtImg->bind_param('iss', $pid, $a, $url);
            $stmtImg->execute();
        }
    }
}
$stmtImg->close();

echo "Done. All categories now have exactly 5 products.\n";
?>
