<?php
require __DIR__ . '/../config/db.php';

function columnExists($mysqli, $table, $column){
    $table = $mysqli->real_escape_string($table);
    $column = $mysqli->real_escape_string($column);
    $sql = "SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME='{$table}' AND COLUMN_NAME='{$column}' LIMIT 1";
    $res = $mysqli->query($sql);
    return $res && $res->num_rows > 0;
}

echo "Checking orders table primary key...\n";
if (!columnExists($mysqli, 'orders', 'id')) {
    echo "Adding 'id' primary key to orders...\n";
    $ok = $mysqli->query("ALTER TABLE orders ADD COLUMN id INT AUTO_INCREMENT PRIMARY KEY FIRST");
    if ($ok) {
        echo "✅ Added 'id' primary key to orders\n";
    } else {
        echo "❌ Error adding 'id' to orders: " . $mysqli->error . "\n";
        exit(1);
    }
} else {
    echo "✓ 'id' column already exists on orders\n";
}

// Ensure essential indexes exist for performance
$mysqli->query("CREATE INDEX IF NOT EXISTS idx_orders_user ON orders(user_id)");
$mysqli->query("CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status)");
$mysqli->query("CREATE INDEX IF NOT EXISTS idx_orders_payment_status ON orders(payment_status)");

echo "Done.\n";
?>
