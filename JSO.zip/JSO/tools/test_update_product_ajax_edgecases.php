<?php
// tools/test_update_product_ajax_edgecases.php
// Tests update-product-ajax.php edge cases: missing ID, invalid CSRF, unauthorized (no admin session), and GET method.

$base = 'http://localhost/JSO';
$adminCookie = sys_get_temp_dir() . '/jso_test_admin_cookies_ajax.txt';
$anonCookie = sys_get_temp_dir() . '/jso_test_anon_cookies_ajax.txt';
@unlink($adminCookie); @unlink($anonCookie);

function curl_get($url, &$info=null, $cookieFile=null){
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 15);
    if($cookieFile){ curl_setopt($ch, CURLOPT_COOKIEJAR, $cookieFile); curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieFile); }
    $body = curl_exec($ch);
    $info = curl_getinfo($ch);
    $err = curl_error($ch);
    curl_close($ch);
    if($err) throw new Exception('cURL GET error: '.$err);
    return $body;
}
function curl_post($url, $postFields, &$info=null, $cookieFile=null){
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 15);
    if($cookieFile){ curl_setopt($ch, CURLOPT_COOKIEJAR, $cookieFile); curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieFile); }
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postFields);
    $body = curl_exec($ch);
    $info = curl_getinfo($ch);
    $err = curl_error($ch);
    curl_close($ch);
    if($err) throw new Exception('cURL POST error: '.$err);
    return $body;
}

try {
    echo "Starting AJAX edge-case tests...\n";

    // Create a minimal product directly in DB for id
    require_once __DIR__ . '/../config/db.php';
    $name = 'AJAX_TEST_' . time();
    $stmt = $mysqli->prepare("INSERT INTO products (name, description, price, weight, category_id, stock, image, created_at) VALUES (?, '', 10.0, 1.0, 1, 1, 'uploads/placeholder.svg', NOW())");
    if(!$stmt) throw new Exception('DB prepare failed: '.$mysqli->error);
    $stmt->bind_param('s', $name);
    if(!$stmt->execute()) throw new Exception('DB insert failed: '.$stmt->error);
    $productId = $mysqli->insert_id;
    $stmt->close();
    echo "Created product id: $productId\n";

    // 1) Login as admin and obtain CSRF token
    echo "Logging in as admin...\n";
    $loginPage = curl_get($base . '/admin/login.php', $info, $adminCookie);
    $loginResp = curl_post($base . '/admin/login.php', ['email'=>'admin@example.com','password'=>'admin123'], $info, $adminCookie);
    if($info['http_code'] >= 400) throw new Exception('Admin login failed: HTTP '.$info['http_code']);
    // fetch CSRF from products-list or any admin page that includes token
    $pl = curl_get($base . '/admin/products-list.php', $info, $adminCookie);
    if(!preg_match('/name="csrf_token" value="([0-9a-f]+)"/i', $pl, $m)) throw new Exception('CSRF token not found on admin page');
    $csrf = $m[1];
    echo "Admin CSRF token: $csrf\n";

    // Test A: Missing ID -> expect HTTP 400 with message 'Missing product id'
    echo "Test A: Missing ID...\n";
    $resp = curl_post($base . '/admin/update-product-ajax.php', ['csrf_token'=>$csrf], $info, $adminCookie);
    $http = $info['http_code'] ?? 0;
    $json = json_decode($resp, true);
    if($http !== 400 || !$json || (stripos($json['message'] ?? '', 'Missing product id') === false)) {
        throw new Exception("Test A failed: got HTTP $http body=".substr($resp,0,200));
    }
    echo "Test A passed.\n";

    // Test B: Invalid CSRF -> expect 403 'Invalid CSRF token'
    echo "Test B: Invalid CSRF...\n";
    $resp = curl_post($base . '/admin/update-product-ajax.php', ['csrf_token'=>'invalidtoken','id'=>$productId,'price'=>'99.9'], $info, $adminCookie);
    $http = $info['http_code'] ?? 0;
    $json = json_decode($resp, true);
    if($http !== 403 || !$json || (stripos($json['message'] ?? '', 'Invalid CSRF token') === false)) {
        throw new Exception("Test B failed: got HTTP $http body=".substr($resp,0,200));
    }
    echo "Test B passed.\n";

    // Test C: Unauthorized (no admin cookie) -> expect 403 and code 'unauthorized'
    echo "Test C: Unauthorized (no admin session)...\n";
    $resp = curl_post($base . '/admin/update-product-ajax.php', ['csrf_token'=>$csrf,'id'=>$productId,'price'=>'77.0'], $info, $anonCookie);
    $http = $info['http_code'] ?? 0;
    $json = json_decode($resp, true);
    if($http !== 403 || !$json || ($json['code'] ?? '') !== 'unauthorized') {
        throw new Exception("Test C failed: got HTTP $http body=".substr($resp,0,200));
    }
    echo "Test C passed.\n";

    // Test D: GET method -> expect 405
    echo "Test D: GET method not allowed...\n";
    $resp = curl_get($base . '/admin/update-product-ajax.php', $info, $adminCookie);
    $http = $info['http_code'] ?? 0;
    if($http !== 405 || stripos($resp, 'Method Not Allowed') === false) {
        throw new Exception("Test D failed: got HTTP $http body=".substr($resp,0,200));
    }
    echo "Test D passed.\n";

    // Cleanup: remove product
    $stmt = $mysqli->prepare("DELETE FROM products WHERE id = ?");
    if ($stmt) { $stmt->bind_param('i', $productId); $stmt->execute(); $stmt->close(); }

    echo "All update-product-ajax edge-case tests passed.\n";
    exit(0);

} catch (Exception $e) {
    echo "TEST FAILURE: " . $e->getMessage() . "\n";
    // try to cleanup if product created
    if (isset($productId) && isset($mysqli)) {
        $stmt = $mysqli->prepare("DELETE FROM products WHERE id = ?");
        if ($stmt) { $stmt->bind_param('i', $productId); $stmt->execute(); $stmt->close(); }
    }
    exit(2);
}
?>