<?php
// CLI helper: call reviews_ajax.php page 2
parse_str('product_id=1&page=2&per_page=10', $_GET);
chdir(__DIR__ . '/..');
include __DIR__ . '/../reviews_ajax.php';
