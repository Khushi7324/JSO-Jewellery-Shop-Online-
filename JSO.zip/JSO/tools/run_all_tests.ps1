param(
    [switch]$RunScanner
)

# Locate PHP executable: prefer XAMPP PHP if present, otherwise look in PATH
$phpCandidates = @("C:\\xampp\\php\\php.exe", "php")
$phpPath = $null
foreach ($c in $phpCandidates) {
    try {
        $cmd = Get-Command $c -ErrorAction Stop
        if ($cmd) { $phpPath = $cmd.Path; break }
    } catch { }
}

if (-not $phpPath) {
    Write-Host "ERROR: PHP executable not found. Please install PHP or ensure C:\xampp\php\php.exe is present or php is in PATH." -ForegroundColor Red
    exit 2
}

$tests = @(
    'tools/test_admin_coupons.php',
    'tools/test_admin_products.php',
    'tools/test_update_product_ajax_edgecases.php',
    'tools/test_update_product_ajax_more_edgecases.php'
)

$results = @()
$failCount = 0
foreach ($t in $tests) {
    $path = Join-Path (Get-Location) $t
    Write-Host "Running test: $t" -ForegroundColor Cyan
    $out = & "$phpPath" "$path" 2>&1
    $rc = $LASTEXITCODE
    if ($out) { Write-Host $out }
    if ($rc -ne 0) {
        Write-Host "-> FAILED (exit code $rc)" -ForegroundColor Red
        $failCount++
        $status = 'FAILED'
    } else {
        Write-Host "-> OK" -ForegroundColor Green
        $status = 'OK'
    }
    $results += [PSCustomObject]@{ Test = $t; ExitCode = $rc; Status = $status }
    Start-Sleep -Milliseconds 300
}

if ($RunScanner) {
    Write-Host "Running full site scanner (tools/full_site_check.ps1)" -ForegroundColor Cyan
    & powershell -NoProfile -ExecutionPolicy Bypass -File "tools/full_site_check.ps1"
}

Write-Host "`nSummary:" -ForegroundColor Yellow
$results | Format-Table -AutoSize
Write-Host "Failures: $failCount" -ForegroundColor Yellow

exit $failCount
