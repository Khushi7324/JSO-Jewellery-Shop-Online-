<?php
// Seeder: tools/seed_products.php
// Usage (CLI): C:\xampp\php\php.exe tools\seed_products.php [count_per_category]

if (php_sapi_name() !== 'cli') {
    echo "This script must be run from command line." . PHP_EOL;
    exit(1);
}

$perCategory = isset($argv[1]) && is_numeric($argv[1]) ? intval($argv[1]) : 1000;
require_once __DIR__ . '/../config/db.php';

// Fetch categories
$cats = [];
$res = $mysqli->query("SELECT id, name FROM categories");
while($r = $res->fetch_assoc()) $cats[] = $r;

if (empty($cats)) {
    echo "No categories found in database. Add categories first.\n";
    exit(1);
}

echo "Seeding $perCategory products per category into " . count($cats) . " categories...\n";
$start = microtime(true);

$insertSql = "INSERT INTO products (name, description, price, weight, category_id, stock, image, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())";
$stmt = $mysqli->prepare($insertSql);
if (!$stmt) {
    echo "Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error . "\n";
    exit(1);
}

$mysqli->begin_transaction();
$inserted = 0;
try {
    foreach ($cats as $cat) {
        $catId = intval($cat['id']);
        $catName = $cat['name'];
        for ($i = 1; $i <= $perCategory; $i++) {
            // Create predictable unique name
            $name = "$catName Sample Item #$i";
            $description = "Beautiful $catName jewelry - sample item number $i. Ideal for testing and display.";
            // Price range by category to make variety
            switch (strtolower($catName)) {
                case 'gold':
                    $price = rand(20000, 200000) / 100.0; // 200.00 - 2000.00
                    break;
                case 'diamond':
                    $price = rand(50000, 500000) / 100.0; // 500.00 - 5000.00
                    break;
                case 'platinum':
                    $price = rand(30000, 300000) / 100.0;
                    break;
                case 'gemstone':
                    $price = rand(15000, 150000) / 100.0;
                    break;
                case 'silver':
                    $price = rand(1000, 50000) / 100.0;
                    break;
                default:
                    $price = rand(1000, 200000) / 100.0;
            }
            $weight = rand(50, 500) / 100.0; // 0.5 - 5.0 grams
            $stock = rand(0, 100);
            // placeholder image with small text
            $image = "https://via.placeholder.com/400x300?text=" . urlencode($catName . "+" . $i);

            $stmt->bind_param('ssdiiss', $name, $description, $price, $weight, $catId, $stock, $image);
            if (!$stmt->execute()) {
                // If duplicate or other error, skip but continue
                echo "Failed to insert (category $catId): " . $stmt->error . "\n";
            } else {
                $inserted++;
            }

            // Small flush every 500 inserts to avoid memory/time spikes
            if ($inserted % 500 === 0) {
                // optional: output progress
                echo "Inserted: $inserted rows...\n";
            }
        }
    }
    $mysqli->commit();
} catch (Exception $e) {
    $mysqli->rollback();
    echo "Exception: " . $e->getMessage() . "\n";
    exit(1);
}

$time = round(microtime(true) - $start, 2);
echo "Seeding complete. Total inserted: $inserted rows in $time seconds.\n";

// Report total rows now
$res2 = $mysqli->query("SELECT COUNT(*) as cnt FROM products");
$total = $res2->fetch_assoc()['cnt'];
echo "Total products in DB now: $total\n";

$stmt->close();
$mysqli->close();

?>