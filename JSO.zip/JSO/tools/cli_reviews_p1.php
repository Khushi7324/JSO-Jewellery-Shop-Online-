<?php
// CLI helper: call reviews_ajax.php page 1
parse_str('product_id=1&page=1&per_page=10', $_GET);
chdir(__DIR__ . '/..');
include __DIR__ . '/../reviews_ajax.php';
