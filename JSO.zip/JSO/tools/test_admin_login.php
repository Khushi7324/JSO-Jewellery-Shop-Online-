<?php
require_once __DIR__ . '/../config/db.php';

$expected = [
    'identifier' => 'admin@example.com',
    'password' => 'admin123'
];

$stmt = $mysqli->prepare("SELECT id, password, role, email, phone, name FROM users WHERE email=? OR phone=? OR name=? LIMIT 1");
$stmt->bind_param('sss', $expected['identifier'], $expected['identifier'], $expected['identifier']);
$stmt->execute();
$stmt->bind_result($id, $hash, $role, $email, $phone, $name);
if($stmt->fetch()){
    $ok = password_verify($expected['password'], $hash);
    echo json_encode(["found"=>true, "id"=>$id, "role"=>$role, "email"=>$email, "phone"=>$phone, "name"=>$name, "password_ok"=>$ok]);
} else {
    echo json_encode(["found"=>false]);
}
$stmt->close();
?>