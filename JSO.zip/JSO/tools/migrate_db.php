<?php
require 'config/db.php';

echo "Creating missing tables...\n\n";

// Returns table
$returns_sql = "CREATE TABLE IF NOT EXISTS returns (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  user_id INT NOT NULL,
  items_json JSON,
  reason VARCHAR(100),
  notes TEXT,
  return_total DECIMAL(10,2),
  status ENUM('pending', 'approved', 'shipped', 'received', 'refunded', 'rejected') DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (order_id) REFERENCES orders(id),
  FOREIGN KEY (user_id) REFERENCES users(id),
  INDEX idx_user_id (user_id),
  INDEX idx_order_id (order_id)
);";

// Coupons table
$coupons_sql = "CREATE TABLE IF NOT EXISTS coupons (
  id INT AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(50) UNIQUE NOT NULL,
  description TEXT,
  discount_type ENUM('percentage', 'fixed') DEFAULT 'percentage',
  discount_value DECIMAL(10,2),
  min_purchase DECIMAL(10,2) DEFAULT 0,
  max_uses INT DEFAULT -1,
  used_count INT DEFAULT 0,
  valid_from DATETIME,
  valid_till DATETIME,
  is_active BOOLEAN DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_code (code),
  INDEX idx_active (is_active)
);";

// Offers table
$offers_sql = "CREATE TABLE IF NOT EXISTS offers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255),
  description TEXT,
  offer_type ENUM('category', 'product', 'general') DEFAULT 'general',
  category_id INT,
  product_id INT,
  discount_type ENUM('percentage', 'fixed') DEFAULT 'percentage',
  discount_value DECIMAL(10,2),
  min_purchase DECIMAL(10,2) DEFAULT 0,
  valid_from DATETIME,
  valid_till DATETIME,
  is_active BOOLEAN DEFAULT 1,
  image_url VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (category_id) REFERENCES categories(id),
  FOREIGN KEY (product_id) REFERENCES products(id),
  INDEX idx_active (is_active),
  INDEX idx_type (offer_type)
);";

// Reviews & Ratings table
$reviews_sql = "CREATE TABLE IF NOT EXISTS reviews (
  id INT AUTO_INCREMENT PRIMARY KEY,
  product_id INT NOT NULL,
  user_id INT NOT NULL,
  rating DECIMAL(2,1) NULL,
  title VARCHAR(255),
  comment TEXT,
  verified_purchase BOOLEAN DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (product_id) REFERENCES products(id),
  FOREIGN KEY (user_id) REFERENCES users(id),
  INDEX idx_product_id (product_id),
  INDEX idx_user_id (user_id),
  INDEX idx_rating (rating)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

// Product images (multi-angle) table
$product_images_sql = "CREATE TABLE IF NOT EXISTS product_images (
  id INT AUTO_INCREMENT PRIMARY KEY,
  product_id INT NOT NULL,
  angle ENUM('front','side','back','top','detail') NOT NULL,
  image_url VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_product_angle (product_id, angle),
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

// Execute all SQL statements
$tables = [
    'Returns' => $returns_sql,
    'Coupons' => $coupons_sql,
    'Offers' => $offers_sql,
    'Reviews' => $reviews_sql,
    'ProductImages' => $product_images_sql
];

foreach ($tables as $name => $sql) {
    if ($mysqli->query($sql)) {
        echo "✅ $name table created/updated successfully\n";
    } else {
        echo "❌ Error with $name table: " . $mysqli->error . "\n";
    }
}

// Ensure reviews.rating is DECIMAL(2,1)
$alter_reviews = "ALTER TABLE reviews MODIFY COLUMN rating DECIMAL(2,1) NULL";
if ($mysqli->query($alter_reviews)) {
    echo "✅ Reviews.rating aligned to DECIMAL(2,1)\n";
} else {
    echo "❌ Error aligning reviews.rating: " . $mysqli->error . "\n";
}

// Alter users table to add reset token fields
$alter_users = "ALTER TABLE users ADD COLUMN IF NOT EXISTS reset_token VARCHAR(255), 
                ADD COLUMN IF NOT EXISTS reset_expiry DATETIME,
                ADD COLUMN IF NOT EXISTS is_admin BOOLEAN DEFAULT 0;";

if ($mysqli->query($alter_users)) {
    echo "✅ Users table updated with reset token fields\n";
} else {
    echo "❌ Error updating users table: " . $mysqli->error . "\n";
}

// Add missing columns to orders table
$alter_orders = "ALTER TABLE orders ADD COLUMN IF NOT EXISTS cancel_reason VARCHAR(100),
                 ADD COLUMN IF NOT EXISTS cancel_notes TEXT,
                 ADD COLUMN IF NOT EXISTS cancelled_at DATETIME;";

if ($mysqli->query($alter_orders)) {
    echo "✅ Orders table updated with cancellation fields\n";
} else {
    echo "❌ Error updating orders table: " . $mysqli->error . "\n";
}

echo "\n✅ Database migration completed!\n";
?>
