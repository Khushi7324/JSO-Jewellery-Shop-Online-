<?php
// tools/test_admin_coupons.php
// Simple authenticated test for admin coupon management using cURL and session cookies.

$base = 'http://localhost/JSO';
$cookieFile = sys_get_temp_dir() . '/jso_test_admin_cookies.txt';
@unlink($cookieFile);

function curl_get($url, &$info=null, $cookieFile=null){
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 15);
    if($cookieFile){ curl_setopt($ch, CURLOPT_COOKIEJAR, $cookieFile); curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieFile); }
    $body = curl_exec($ch);
    $info = curl_getinfo($ch);
    $err = curl_error($ch);
    curl_close($ch);
    if($err) throw new Exception('cURL GET error: '.$err);
    return $body;
}

function curl_post($url, $postFields, &$info=null, $cookieFile=null){
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 15);
    if($cookieFile){ curl_setopt($ch, CURLOPT_COOKIEJAR, $cookieFile); curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieFile); }
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postFields);
    $body = curl_exec($ch);
    $info = curl_getinfo($ch);
    $err = curl_error($ch);
    curl_close($ch);
    if($err) throw new Exception('cURL POST error: '.$err);
    return $body;
}

try {
    echo "Test: Ensure coupons table exists...\n";
    $r = curl_get($base.'/create_coupon_tables.php', $i, $cookieFile);
    echo "Create tables response: " . ($i['http_code'] ?? 0) . "\n";

    // 1) Login as admin
    echo "Logging in as admin...\n";
    $loginPage = curl_get($base.'/admin/login.php', $info, $cookieFile);
    // Submit login: default admin credentials from init_admin
    $loginResp = curl_post($base.'/admin/login.php', ['email'=>'admin@example.com','password'=>'admin123'], $info, $cookieFile);
    if($info['http_code'] >= 400) throw new Exception('Login request failed: HTTP '.$info['http_code']);
    echo "Login request finished (HTTP {$info['http_code']}).\n";

    // 2) Fetch coupons page and extract CSRF token
    echo "Fetching coupons page...\n";
    $page = curl_get($base.'/admin/coupons.php', $info, $cookieFile);
    if(strpos($page, 'Coupons') === false) throw new Exception('Coupons page not accessible after login');
    if(!preg_match('/name="csrf_token" value="([0-9a-f]+)"/i', $page, $m)) {
        throw new Exception('CSRF token not found on coupons page');
    }
    $csrf = $m[1];
    echo "CSRF token: $csrf\n";

    // 3) Add coupon
    $code = 'TEST' . time();
    echo "Adding coupon $code...\n";
    $post = [
        'action' => 'add',
        'csrf_token' => $csrf,
        'code' => $code,
        'discount_type' => 'fixed',
        'discount_value' => '50',
        'min_purchase' => '0',
        'max_uses' => '-1',
        'is_active' => '1',
        'valid_from' => date('Y-m-d\TH:i'),
        'valid_till' => date('Y-m-d\TH:i', strtotime('+1 day'))
    ];
    $addResp = curl_post($base.'/admin/coupons.php', $post, $info, $cookieFile);
    echo "Add request HTTP: {$info['http_code']}\n";

    // 4) Confirm coupon exists and get its ID
    $page = curl_get($base.'/admin/coupons.php', $info, $cookieFile);
    if(strpos($page, $code) === false) throw new Exception('Added coupon not found on list');
    echo "Coupon appears in list.\n";
    // parse ID from table row
    if(!preg_match('/<td>(\d+)<\/td>\s*<td>'.preg_quote($code,'/').'/i', $page, $mm)){
        // Alternate parse: find row by code and capture first <td>
        if(preg_match('/<tr>\s*<td>(\d+)<\/td>\s*<td>\s*'.preg_quote($code,'/').'/i', $page, $mm)){
            $cid = $mm[1];
        } else {
            // try generic: find the row containing code and then previous ID
            $parts = explode($code, $page);
            $left = substr($parts[0], -500);
            if(preg_match('/<td>(\d+)<\/td>/', $left, $m2)) $cid = $m2[1];
            else throw new Exception('Could not extract coupon ID');
        }
    } else {
        $cid = $mm[1];
    }
    echo "Coupon ID: $cid\n";

    // 5) Edit coupon: update code to append _UPD
    echo "Editing coupon $cid...\n";
    $editPage = curl_get($base.'/admin/coupons.php?action=edit&id='.$cid, $info, $cookieFile);
    if(!preg_match('/name="csrf_token" value="([0-9a-f]+)"/i', $editPage, $m2)) throw new Exception('CSRF token not found on edit page');
    $csrf2 = $m2[1];
    $newCode = $code . '_UPD';
    $postUpd = [
        'action' => 'update',
        'csrf_token' => $csrf2,
        'id' => $cid,
        'code' => $newCode,
        'discount_type' => 'fixed',
        'discount_value' => '60',
        'min_purchase' => '0',
        'max_uses' => '-1',
        'is_active' => '1',
        'valid_from' => date('Y-m-d\TH:i'),
        'valid_till' => date('Y-m-d\TH:i', strtotime('+2 day'))
    ];
    $updResp = curl_post($base.'/admin/coupons.php', $postUpd, $info, $cookieFile);
    echo "Update request HTTP: {$info['http_code']}\n";

    $page = curl_get($base.'/admin/coupons.php', $info, $cookieFile);
    if(strpos($page, $newCode) === false) throw new Exception('Updated coupon code not visible');
    echo "Coupon updated successfully to $newCode.\n";

    // 6) Toggle active/inactive
    echo "Toggling coupon active state...\n";
    if(!preg_match('/<tr[\s\S]*?<td>\s*'.preg_quote($cid,'/').'\s*<\/td>[\s\S]*?<button class="btn" type="submit">(Activate|Deactivate)<\/button>/i', $page, $m3)){
        // fallback: just use POST with csrf token fetched earlier
    }
    // ensure CSRF token present
    if(!preg_match('/name="csrf_token" value="([0-9a-f]+)"/i', $page, $m3t)) throw new Exception('CSRF token not found for toggle');
    $csrf3 = $m3t[1];
    $postToggle = ['action'=>'toggle','csrf_token'=>$csrf3,'id'=>$cid];
    $togResp = curl_post($base.'/admin/coupons.php', $postToggle, $info, $cookieFile);
    echo "Toggle request HTTP: {$info['http_code']}\n";

    // 7) Delete coupon
    echo "Deleting coupon $cid...\n";
    // Get fresh CSRF
    $page = curl_get($base.'/admin/coupons.php', $info, $cookieFile);
    if(!preg_match('/name="csrf_token" value="([0-9a-f]+)"/i', $page, $m4)) throw new Exception('CSRF token not found for delete');
    $csrf4 = $m4[1];
    $postDel = ['action'=>'delete','csrf_token'=>$csrf4,'id'=>$cid];
    $delResp = curl_post($base.'/admin/coupons.php', $postDel, $info, $cookieFile);
    echo "Delete request HTTP: {$info['http_code']}\n";

    // Confirm deletion
    $page = curl_get($base.'/admin/coupons.php', $info, $cookieFile);
    if(strpos($page, $newCode) !== false) throw new Exception('Coupon still present after delete');
    echo "Coupon deleted successfully.\n";

    echo "All coupon tests passed.\n";
    exit(0);

} catch (Exception $e) {
    echo "TEST FAILURE: " . $e->getMessage() . "\n";
    exit(2);
}

?>