-- Migration: change reviews.rating to DECIMAL(2,1) to support half-step ratings
-- Run this against your MySQL/MariaDB database. Backup your DB before running.

-- Use your DB name if needed, e.g. USE jso_shop;

ALTER TABLE `reviews`
  MODIFY COLUMN `rating` DECIMAL(2,1) NULL;

-- Verify:
-- SHOW COLUMNS FROM `reviews` LIKE 'rating';
-- SELECT AVG(rating) AS avg_rating, COUNT(*) AS cnt FROM reviews WHERE rating IS NOT NULL;