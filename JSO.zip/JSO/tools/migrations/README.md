Migration: alter_reviews_rating

This folder contains SQL migrations for the JSO project.

Migration: alter_feedback_rating.sql
- Purpose: Change `reviews.rating` column type to `DECIMAL(2,1)` so the DB can store half-step ratings (e.g., 4.5).
- File: `alter_feedback_rating.sql`

Instructions to run (Windows / XAMPP):
1. Backup your database first.
2. Open PowerShell in the project root or any terminal with access to `C:\xampp\mysql\bin\mysql.exe`.
3. Run:

```powershell
# Replace DB_NAME, DB_USER and provide password if needed
$DB_NAME = 'jso_shop'
$DB_USER = 'root'
# If you have a password, use -pYourPassword (no space) or omit to prompt
C:\xampp\mysql\bin\mysql.exe -u $DB_USER -p $DB_NAME < "C:\xampp\htdocs\JSO\tools\migrations\alter_feedback_rating.sql"
```

Alternative: Use phpMyAdmin or another DB client to run the SQL file.

Notes:
- The migration uses `MODIFY COLUMN` to change the column type and keeps the column nullable.
- If your `reviews.rating` column currently is INT, existing integer values remain valid. After migration you can store decimals like 4.5.
- Always test migrations on a staging/dev copy before applying to production.
