const { chromium } = require('playwright');
const { spawn } = require('child_process');
const http = require('http');
const path = require('path');

// Adjust these if your paths / port differ
const PHP_CLI = process.env.PHP_CLI || 'C:\\xampp\\php\\php.exe';
const DOCROOT = process.env.DOCROOT || 'C:\\xampp\\htdocs\\JSO';
const HOST = process.env.HOST || '127.0.0.1';
const PORT = process.env.PORT || 8001;
const URL = `http://${HOST}:${PORT}/product.php?id=1`;
const MAX_SCROLLS = 12; // safety
const WAIT_AFTER_SCROLL_MS = 1200;
const SERVER_START_TIMEOUT = 5000;

function waitForServer(url, timeout = 5000) {
  const start = Date.now();
  return new Promise((resolve, reject) => {
    (function ping() {
      http.get(url, res => {
        res.resume();
        resolve();
      }).on('error', err => {
        if (Date.now() - start > timeout) return reject(new Error('Timeout waiting for server'));
        setTimeout(ping, 200);
      });
    })();
  });
}

(async () => {
  console.log('Starting PHP dev server...');
  // Start PHP built-in server
  const php = spawn(PHP_CLI, ['-S', `${HOST}:${PORT}`, '-t', DOCROOT], {
    stdio: ['ignore', 'pipe', 'pipe']
  });

  php.stdout.on('data', d => process.stdout.write('[php] ' + d.toString()));
  php.stderr.on('data', d => process.stderr.write('[php] ' + d.toString()));

  try {
    await waitForServer(URL, SERVER_START_TIMEOUT);
    console.log('Server appears up at', URL);
  } catch (err) {
    console.error('Server did not start in time:', err.message);
    php.kill();
    process.exit(2);
  }

  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext();
  const page = await context.newPage();

  try {
    console.log('Loading product page...');
    await page.goto(URL, { waitUntil: 'domcontentloaded' });

    // initial review cards count
    let initial = await page.$$eval('#reviewsList .info-card', els => els.length);
    console.log('Initial reviews on page:', initial);

    // total reviews as published by server (product.php defines totalReviewsJS)
    const total = await page.evaluate(() => {
      return (typeof totalReviewsJS !== 'undefined') ? totalReviewsJS : null;
    });
    console.log('Total reviews (JS var):', total);

    let prev = initial;
    for (let i = 0; i < MAX_SCROLLS; i++) {
      console.log(`Scroll attempt ${i + 1}...`);
      // scroll to bottom
      await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
      // wait for possible network activity and DOM updates
      await page.waitForTimeout(WAIT_AFTER_SCROLL_MS);

      // measure reviews count
      const nowCount = await page.$$eval('#reviewsList .info-card', els => els.length);
      console.log('Reviews now:', nowCount);
      if (nowCount === prev) {
        console.log('No change after scroll; assuming no more pages.');
        break;
      }
      prev = nowCount;

      // small safety wait before next scroll
      await page.waitForTimeout(400);
    }

    console.log('Final reviews count:', prev);
    // Determine CI-friendly exit code
    let exitCode = 0;
    if (total !== null) {
      if (prev === total) {
        console.log('SUCCESS: Loaded all reviews via infinite scroll (count matches total).');
        exitCode = 0;
      } else if (prev < total) {
        console.error(`FAIL: loaded ${prev} of ${total} reviews. There may be more pages or a bug.`);
        exitCode = 3;
      } else {
        console.warn('WARNING: loaded more reviews than server-reported total (possible race or mismatch). Treating as success.');
        exitCode = 0;
      }
    } else {
      // total not available: ensure we loaded at least one review to consider success
      if (prev > 0) {
        console.log('SUCCESS: Loaded reviews (total not available). Final count:', prev);
        exitCode = 0;
      } else {
        console.error('FAIL: No reviews loaded and total not available.');
        exitCode = 4;
      }
    }
    // store exitCode to use in finally
    global.__TEST_EXIT_CODE = exitCode;

  } catch (err) {
    console.error('Test failed:', err);
    global.__TEST_EXIT_CODE = global.__TEST_EXIT_CODE || 2;
  } finally {
    try {
      await browser.close();
    } catch (e) {
      // ignore
    }
    console.log('Stopping PHP server...');
    try { php.kill(); } catch(e) {}
    const code = (typeof global.__TEST_EXIT_CODE !== 'undefined') ? global.__TEST_EXIT_CODE : 1;
    console.log('Exiting with code', code);
    process.exit(code);
  }
})();
