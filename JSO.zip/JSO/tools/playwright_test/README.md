# Playwright Infinite Scroll Test

This folder contains a headless Playwright test that exercises the product reviews infinite-scroll UI.

Files:
- `package.json` - Node manifest for the test
- `test.js` - Playwright test script (headless Chromium)

Requirements (local):
- Node.js >= 16
- npm
- PHP CLI (for local dev the script starts PHP built-in server)
- A running MySQL instance (or use the local XAMPP MySQL)

Local run (one-time setup + run):
```powershell
cd tools/playwright_test
npm install
npx playwright install chromium
# Set env vars if your DB is not default
$env:DB_HOST='127.0.0.1'
$env:DB_USER='root'
$env:DB_PASS=''
$env:DB_NAME='jso_shop'
npm test
```

CI notes (GitHub Actions):
- The workflow expects these repository secrets to be configured (or set as environment variables in your runner):
  - `CI_DB_USER` - database username (e.g. `root`)
  - `CI_DB_PASS` - database password (e.g. `root`)
  - `CI_DB_NAME` - database name (e.g. `jso_shop`)
- The workflow starts a MySQL service, runs the migration script, then runs the headless Playwright test.

If you prefer not to use repository secrets in GitHub, you can modify `.github/workflows/playwright-infinite-scroll.yml` to set plain values (not recommended for public repos).
