#!/usr/bin/env python3
"""
Simple link checker / crawler for the local site.
Usage:
  python tools/link_checker.py --start-url http://127.0.0.1:8000/ --output tools/link_check_report.txt

This script crawls pages under the same host, checks each discovered link's HTTP status,
and writes a report listing OK and broken links.
"""
import sys
import argparse
import time
from urllib.parse import urljoin, urlparse
from urllib.request import urlopen, Request
from urllib.error import URLError, HTTPError
from html.parser import HTMLParser


class LinkExtractor(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links = set()

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == 'a' and 'href' in attrs:
            self.links.add(attrs['href'])
        if tag == 'img' and 'src' in attrs:
            self.links.add(attrs['src'])
        if tag == 'script' and 'src' in attrs:
            self.links.add(attrs['src'])
        if tag == 'link' and 'href' in attrs:
            self.links.add(attrs['href'])


def fetch(url, timeout=10):
    req = Request(url, headers={'User-Agent': 'LinkChecker/1.0'})
    try:
        resp = urlopen(req, timeout=timeout)
        code = resp.getcode()
        content = resp.read()
        return code, content
    except HTTPError as he:
        return he.code, None
    except URLError as ue:
        return None, None
    except Exception:
        return None, None


def is_same_origin(url, origin):
    p1 = urlparse(url)
    p2 = urlparse(origin)
    return (p1.scheme in ('', p2.scheme)) and (p1.netloc in ('', p2.netloc))


def normalize_link(link, base):
    return urljoin(base, link)


def crawl(start_url, max_pages=200, delay=0.1):
    parsed = urlparse(start_url)
    origin = f"{parsed.scheme}://{parsed.netloc}"

    to_visit = [start_url]
    visited = set()
    discovered = set()
    checked = {}

    while to_visit and len(visited) < max_pages:
        url = to_visit.pop(0)
        if url in visited:
            continue
        visited.add(url)
        code, content = fetch(url)
        checked[url] = code
        if content:
            try:
                content = content.decode('utf-8', errors='replace')
            except Exception:
                content = content.decode('latin-1', errors='replace')
            extractor = LinkExtractor()
            extractor.feed(content)
            for raw in extractor.links:
                full = normalize_link(raw, url)
                parsed_full = urlparse(full)
                # Only same-origin links
                if parsed_full.scheme and parsed_full.netloc and parsed_full.netloc != parsed.netloc:
                    # external link; we still record but don't crawl
                    discovered.add(full)
                else:
                    discovered.add(full)
                    if full not in visited and full not in to_visit:
                        to_visit.append(full)
        time.sleep(delay)

    return visited, discovered, checked


def check_links(links, timeout=10):
    results = {}
    for link in sorted(links):
        code, _ = fetch(link, timeout=timeout)
        results[link] = code
    return results


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--start-url', default='http://127.0.0.1:8000/', help='Start URL to crawl')
    parser.add_argument('--max-pages', type=int, default=200, help='Max pages to crawl')
    parser.add_argument('--output', default='tools/link_check_report.txt', help='Output report file')
    args = parser.parse_args()

    start = args.start_url
    print(f"Crawling {start} (may take a little while)...")
    visited, discovered, checked = crawl(start, max_pages=args.max_pages)

    print(f"Crawled {len(visited)} pages; discovered {len(discovered)} unique links.")

    # Check discovered links (same-origin and external)
    # We'll attempt to check all discovered links
    link_results = {}
    for link in sorted(discovered):
        code, _ = fetch(link)
        link_results[link] = code

    ok = []
    broken = []
    unknown = []
    for link, code in link_results.items():
        if code is None:
            unknown.append(link)
        elif 200 <= code < 400:
            ok.append((link, code))
        else:
            broken.append((link, code))

    with open(args.output, 'w', encoding='utf-8') as f:
        f.write(f"Link check report for {start}\n")
        f.write(f"Crawled pages: {len(visited)}\n")
        f.write(f"Discovered links: {len(discovered)}\n\n")

        f.write("OK links:\n")
        for link, code in ok:
            f.write(f"{code}\t{link}\n")
        f.write("\nBroken links (status != 2xx/3xx):\n")
        for link, code in broken:
            f.write(f"{code}\t{link}\n")
        f.write("\nUnknown / connection errors:\n")
        for link in unknown:
            f.write(f"ERR\t{link}\n")

    print(f"Report written to {args.output}")


if __name__ == '__main__':
    main()
