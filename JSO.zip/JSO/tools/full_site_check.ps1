# Full site PHP endpoint checker
param(
    [string]$base = 'http://localhost/JSO'
)

$root = 'C:\xampp\htdocs\JSO'
$out = Join-Path $root 'tools\full_site_report.csv'
$debug = Join-Path $root 'tools\full_site_debug.txt'

Write-Output "Scanning PHP files under $root and testing HTTP endpoints against $base"

$files = Get-ChildItem -Path $root -Recurse -Include *.php -File | Where-Object { $_.FullName -notmatch '\\tools\\' -and $_.FullName -notmatch '\\admin\\backups\\' -and $_.FullName -notmatch '\\node_modules\\' -and $_.FullName -notmatch '\\includes\\' }

$header = 'StatusCode,TimeMs,URL,ContainsFatal,ContainsWarning,ContainsNotice,ErrorMessage'
$outTemp = $out + ".tmp.$PID.$([System.Guid]::NewGuid().ToString('N'))"
$debugTemp = $debug + ".tmp.$PID.$([System.Guid]::NewGuid().ToString('N'))"
Set-Content -Path $outTemp -Value $header -Encoding UTF8
Set-Content -Path $debugTemp -Value "Full site check started at $(Get-Date -Format o) against $base`n" -Encoding UTF8

# Map of endpoints -> allowed/expected status codes (these won't be treated as failures)
$expectedStatus = @{
    '/admin/update-product-ajax.php' = @(403,405);
    '/submit_feedback.php' = @(405);
}

foreach ($f in $files) {
    try {
        $rel = $f.FullName.Substring($root.Length)
        $rel = $rel.TrimStart('\','/')
        $rel = $rel -replace '\\','/'
        # Map to URL
        $url = $base.TrimEnd('/') + '/' + $rel
        # For index.php map to directory too
        if ($rel -match 'index.php$') { $urlsToCheck = @($url, "$base/" + ($rel -replace '/index.php$','')) } else { $urlsToCheck = @($url) }
        foreach ($u in $urlsToCheck) {
            $uClean = $u -replace '/+$',''
            # Ensure we have a valid absolute URL
            if ($uClean -notmatch '^https?://') { $uClean = $base.TrimEnd('/') + '/' + $uClean.TrimStart('/') }
            $start = Get-Date
            try {
                # Use HttpWebRequest for more predictable status + body handling
                $req = [System.Net.WebRequest]::Create($uClean)
                $req.Method = 'GET'
                $req.Timeout = 15000
                $resp = $req.GetResponse()
                $time = [math]::Round(((Get-Date) - $start).TotalMilliseconds,0)
                $stream = $resp.GetResponseStream()
                $reader = New-Object System.IO.StreamReader($stream)
                $body = $reader.ReadToEnd()
                # Try to get numeric status code where available
                try { $status = ($resp.StatusCode -as [int]).ToString() } catch { $status = '200' }
                # Determine if this response is an expected non-200 for this path
                $suppressDebug = $false
                try {
                    $uPath = ([System.Uri] $uClean).AbsolutePath
                    foreach ($k in $expectedStatus.Keys) {
                        if ($uPath -like "*${k}") {
                            $vals = $expectedStatus[$k]
                            if ($vals -contains ([int]$status)) { $suppressDebug = $true; break }
                        }
                    }
                } catch { }
                $containsFatal = ($body -match 'Fatal error')
                $containsWarning = ($body -match 'Warning:')
                $containsNotice = ($body -match 'Notice:')
                $escUrl = $uClean -replace '"','""'
                $line = $status + ',' + $time + ',' + '"' + $escUrl + '"' + ',' + (($containsFatal -as [int]) -as [string]) + ',' + (($containsWarning -as [int]) -as [string]) + ',' + (($containsNotice -as [int]) -as [string]) + ',""'
                Add-Content -Path $outTemp -Value $line -Encoding UTF8
                if (($containsFatal -or $containsWarning -or $containsNotice) -and -not $suppressDebug) {
                    Add-Content -Path $debugTemp -Value "ISSUE: $uClean => Fatal:$containsFatal Warn:$containsWarning Notice:$containsNotice`n" -Encoding UTF8
                }
            } catch [System.Net.WebException] {
                $time = ''
                $status = 'ERR'
                $resp = $_.Exception.Response
                if ($resp -ne $null) {
                    try { $status = ($resp.StatusCode -as [int]).ToString() } catch { $status = 'ERR' }
                    try {
                        $stream = $resp.GetResponseStream()
                        $reader = New-Object System.IO.StreamReader($stream)
                        $body = $reader.ReadToEnd()
                    } catch { $body = '' }
                }
                $err = $_.Exception.Message -replace '"','""'
                $escUrl = $uClean -replace '"','""'
                $escErr = $err -replace '"','""'
                $line = $status + ',' + $time + ',' + '"' + $escUrl + '"' + ',0,0,0,"' + $escErr + '"'
                Add-Content -Path $outTemp -Value $line -Encoding UTF8
                # Suppress debug for expected status codes
                $suppressDebug = $false
                try {
                    $uPath = ([System.Uri] $uClean).AbsolutePath
                    foreach ($k in $expectedStatus.Keys) {
                        if ($uPath -like "*${k}") {
                            $vals = $expectedStatus[$k]
                            if ($vals -contains ([int]$status)) { $suppressDebug = $true; break }
                        }
                    }
                } catch { }
                if (-not $suppressDebug) { Add-Content -Path $debugTemp -Value "ERROR: $uClean => $err`n" -Encoding UTF8 }
            } catch {
                $time = ''
                $status = 'ERR'
                $err = $_.Exception.Message -replace '"','""'
                $escUrl = $uClean -replace '"','""'
                $escErr = $err -replace '"','""'
                $line = $status + ',' + $time + ',' + '"' + $escUrl + '"' + ',0,0,0,"' + $escErr + '"'
                Add-Content -Path $outTemp -Value $line -Encoding UTF8
                Add-Content -Path $debugTemp -Value "ERROR: $uClean => $err`n" -Encoding UTF8
            }
        }
    } catch {
        Add-Content -Path $debugTemp -Value "SKIP: $($f.FullName) => $($_.Exception.Message)`n" -Encoding UTF8
    }
}

# Try to atomically move temp files to final location (retry if locked)
$maxRetries = 10
$delayMs = 250
for ($i = 0; $i -lt $maxRetries; $i++) {
    try {
        Move-Item -Path $outTemp -Destination $out -Force
        Move-Item -Path $debugTemp -Destination $debug -Force
        break
    } catch {
        Start-Sleep -Milliseconds $delayMs
        if ($i -eq $maxRetries - 1) { Write-Warning "Could not move temp report files to $out after $maxRetries retries." }
    }
}

Write-Output "Full site check complete. Report: $out, Debug: $debug"
