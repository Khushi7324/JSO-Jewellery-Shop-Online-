# PowerShell quick link-check for common site endpoints
$base = 'http://127.0.0.1:8000'
$paths = @(
    '/',
    '/index.php',
    '/catalog.php',
    '/product.php?id=1',
    '/cart.php',
    '/checkout.php',
    '/login.php',
    '/register.php',
    '/admin/login.php',
    '/admin/dashboard.php',
    '/my_orders.php',
    '/payment.php',
    '/payment_success.php',
    '/profile.php'
)
$out = 'c:\xampp\htdocs\JSO\tools\link_check_report_pw.csv'
# Use .NET file APIs to write headers reliably with UTF-8 encoding
$meta = "Link check report for $base`r`nChecked at: $(Get-Date -Format o)`r`n"
[System.IO.File]::WriteAllText($out, $meta, [System.Text.Encoding]::UTF8)
$csvHeader = "Status,TimeMs,FinalURL,HopList,URL`r`n"
[System.IO.File]::AppendAllText($out, $csvHeader, [System.Text.Encoding]::UTF8)

# Helper to escape CSV fields
function csvEscape($s) {
    if ($null -eq $s) { $s = '' }
    $s = [string]$s
    $s = $s -replace '"', '""'
    return '"' + $s + '"'
}

$results = @()
foreach ($p in $paths) {
    $url = $base + $p
    $status = 'ERR'
    $timeMs = ''
    $final = $url
    $hopList = ''

    try {
        # Prefer curl.exe for reliable hop tracking when available
        if (Get-Command curl.exe -ErrorAction SilentlyContinue) {
            $start = Get-Date
            # Collect all response headers from the redirect chain
            $headerOutput = & curl.exe -s -D - -o NUL -L --max-redirs 10 $url 2>&1
            $elapsed = (Get-Date) - $start
            $timeMs = [math]::Round($elapsed.TotalMilliseconds,0)

            # Get final effective URL and status code
            $finalOut = & curl.exe -s -o NUL -w "%{url_effective} %{http_code}" -L --max-redirs 10 $url
            $parts = $finalOut -split ' '
            if ($parts.Length -ge 2) { $final = $parts[0]; $status = [int]$parts[1] } else { $final = $parts[0]; $status = 'ERR' }

            # Parse hop list from header output (capture HTTP status lines and Location headers)
            $lines = $headerOutput -split "`n"
            $hops = @()
            $lastStatus = ''
            foreach ($line in $lines) {
                $t = $line.Trim()
                # Capture status lines like: HTTP/1.1 302 Found
                if ($t -match '^(?i)HTTP/\d+\.\d+\s+(\d{3})') {
                    $lastStatus = $matches[1]
                    continue
                }
                if ($t -match '^(?i)Location:\s*(.+)$') {
                    $rawHop = $matches[1].Trim()
                    # Normalize to absolute URL using System.Uri resolution against the checker base
                    try {
                        $absUri = [Uri]::new([Uri]$base, $rawHop)
                        $abs = $absUri.AbsoluteUri
                    } catch {
                        if ($rawHop -match '^(?i)https?://') {
                            $abs = $rawHop
                        } elseif ($rawHop.StartsWith('//')) {
                            try { $scheme = ([Uri]$base).Scheme } catch { $scheme = 'http' }
                            $abs = $scheme + ':' + $rawHop
                        } elseif ($rawHop.StartsWith('/')) {
                            $abs = $base + $rawHop
                        } else {
                            $abs = $base + '/' + $rawHop.TrimStart('/')
                        }
                    }
                    # Append status code for this hop if known
                    if ($lastStatus -ne '') { $hops += "$abs ($lastStatus)" } else { $hops += $abs }
                    # Reset lastStatus for next hop
                    $lastStatus = ''
                }
            }
            # If we didn't capture any Location headers, but final URL differs, include final with status
            if ($hops.Count -gt 0) {
                $hopList = ($hops -join ' -> ')
            } else {
                # include final URL and status
                $hopList = "$final ($status)"
            }
        } else {
            # Fallback to Invoke-WebRequest if curl isn't available
            $start = Get-Date
            $r = Invoke-WebRequest -Uri $url -Method Get -UseBasicParsing -TimeoutSec 15 -MaximumRedirection 5 -ErrorAction Stop
            $elapsed = (Get-Date) - $start
            $timeMs = [math]::Round($elapsed.TotalMilliseconds,0)
            $status = if ($null -ne $r.StatusCode) { [int]$r.StatusCode } else { 200 }
            $final = if ($null -ne $r.BaseResponse.ResponseUri) { $r.BaseResponse.ResponseUri.AbsoluteUri } else { $url }
            $hopList = $final
        }
    } catch {
        # On error, leave status as ERR and record no hops
        $status = 'ERR'
        $timeMs = ''
        $final = $url
        $hopList = ''
    }

    # Collect CSV line with escaped fields (use array join for reliable concatenation)
    # Build escaped CSV fields without calling helper to avoid environment-specific issues
    $escStatus = '"' + ($status -as [string] -replace '"', '""') + '"'
    $escTime = '"' + ($timeMs -as [string] -replace '"', '""') + '"'
    $escFinal = '"' + ($final -as [string] -replace '"', '""') + '"'
    $escHop = '"' + ($hopList -as [string] -replace '"', '""') + '"'
    $escUrl = '"' + ($url -as [string] -replace '"', '""') + '"'
    $csvLine = $escStatus + ',' + $escTime + ',' + $escFinal + ',' + $escHop + ',' + $escUrl
    $results += $csvLine
}

# Write all collected results (append to file)

# Debug: write raw collected lines to a debug file to inspect content if needed
$debugFile = 'c:\xampp\htdocs\JSO\tools\link_check_debug.txt'
[System.IO.File]::WriteAllLines($debugFile, $results, [System.Text.Encoding]::UTF8)

$results | Out-File -FilePath $out -Append -Encoding utf8

Write-Output "PowerShell quick check complete. Report: $out"
