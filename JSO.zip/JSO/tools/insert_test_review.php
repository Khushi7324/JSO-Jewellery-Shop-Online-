<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';

// Quick smoke test: insert a test review using add_feedback()
$test_user_id = 2; // adjust if needed (existing user id)
$test_product_id = 1; // existing product id
$test_rating = 4.5;
$test_comment = 'Automated smoke-test review (4.5)';

$res = add_feedback($test_user_id, $test_product_id, $test_rating, $test_comment);
if ($res === false) {
    echo "Insert failed\n";
    var_dump($GLOBALS['mysqli']->error);
    exit(1);
}

echo "Inserted review id: $res\n";
// show the inserted row
$stmt = $mysqli->prepare('SELECT id, product_id, user_id, rating, comment, created_at FROM reviews WHERE id=?');
$stmt->bind_param('i', $res);
$stmt->execute();
$row = $stmt->get_result()->fetch_assoc();
$stmt->close();
print_r($row);

?>