<?php
// CLI helper: render product.php with id=1
parse_str('id=1', $_GET);
chdir(__DIR__ . '/..');
include __DIR__ . '/../product.php';
