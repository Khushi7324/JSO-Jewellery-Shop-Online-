<?php
// tools/fetch_page.php
// Usage: php tools/fetch_page.php <url>
if (php_sapi_name() !== 'cli') {
    echo "Run from CLI only.\n";
    exit(1);
}
$url = isset($argv[1]) ? $argv[1] : 'http://localhost/JSO/catalog.php?page=418';
$opts = [
    'http' => [
        'method' => 'GET',
        'header' => "User-Agent: PHP-CLI-Fetcher/1.0\r\n",
        'timeout' => 15
    ]
];
$context = stream_context_create($opts);
$start = microtime(true);
$contents = @file_get_contents($url, false, $context);
$time = round(microtime(true) - $start, 2);
if ($contents === false) {
    // Try cURL fallback
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_USERAGENT, 'PHP-CLI-Fetcher/1.0');
        curl_setopt($ch, CURLOPT_TIMEOUT, 15);
        $contents = curl_exec($ch);
        $errno = curl_errno($ch);
        $err = curl_error($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($contents === false) {
            echo "CURL error ($errno): $err\n";
            exit(1);
        }
    } else {
        echo "Failed to fetch URL and no cURL available.\n";
        exit(1);
    }
}
// Try to determine HTTP code from $http_response_header if available
$http_code = 0;
if (isset($http_response_header) && is_array($http_response_header)) {
    foreach ($http_response_header as $hdr) {
        if (preg_match('#HTTP/\d+\.\d+\s+(\d+)#', $hdr, $m)) {
            $http_code = intval($m[1]);
            break;
        }
    }
}
if (empty($http_code) && function_exists('curl_version')) {
    // already set above if curl used
}
$length = strlen($contents);
$snippet = substr($contents, 0, 2048);
echo "URL: $url\n";
echo "HTTP Status: " . ($http_code ?: 'unknown') . "\n";
echo "Time: {$time}s" . "\n";
echo "Length: {$length} bytes\n\n";
echo "----- HTML Snippet (first 2KB) -----\n";
echo $snippet . "\n";
?>