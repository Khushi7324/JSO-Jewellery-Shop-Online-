<?php
require __DIR__ . '/../config/db.php';
$angles = ['front','side','back','top','detail'];
$res = $mysqli->query("SELECT id, image FROM products");
$stmt = $mysqli->prepare("INSERT INTO product_images (product_id, angle, image_url) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE image_url=VALUES(image_url)");
$products = 0;
$rows = 0;
if ($res && $stmt) {
    while ($row = $res->fetch_assoc()) {
        $pid = (int)$row['id'];
        $img = (string)$row['image'];
        foreach ($angles as $a) {
            $url = $img;
            if (strpos($img, 'placeholder') !== false) {
                if ($a === 'side')   $url = str_replace('placeholder', 'placeholder-side', $img);
                if ($a === 'back')   $url = str_replace('placeholder', 'placeholder-back', $img);
                if ($a === 'top')    $url = str_replace('placeholder', 'placeholder-top', $img);
                if ($a === 'detail') $url = str_replace('placeholder', 'placeholder-detail', $img);
            }
            $stmt->bind_param('iss', $pid, $a, $url);
            $stmt->execute();
            $rows++;
        }
        $products++;
    }
    $stmt->close();
}
echo "Seeded $rows rows for $products products\n";
?>
