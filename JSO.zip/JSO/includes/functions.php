<?php
function e($s){return htmlspecialchars($s);}

// Returns the application base path (e.g. '/JSO') and appends an optional path
function base_url($path = ''){
    $script = $_SERVER['SCRIPT_NAME'] ?? '/';
    $parts = explode('/', trim($script, '/'));
    $root = '';
    if(isset($parts[0]) && strpos($parts[0], '.') === false){
        // first segment is likely the application folder
        // If the app is being accessed under an /admin/... path at the webroot
        // (e.g., http://host/admin/login.php) we should not treat 'admin' as
        // the application root. In that case, leave $root empty so base URLs
        // resolve to site root. When installed in a subfolder (e.g., /JSO/...),
        // use that folder as the root.
        if ($parts[0] === 'admin') {
            $root = '';
        } else {
            $root = '/' . $parts[0];
        }
    }
    if($path === '' || $path === null) return $root === '' ? '/' : $root;
    // normalize
    $p = '/' . ltrim($path, '/');
    return rtrim($root, '/') . $p;
}

// Convenience wrapper for building route URLs (keeps code intention clear)
function route_url($path = ''){
    return base_url($path);
}

function cart_count(){
    global $mysqli;
    if(!isset($_SESSION['user_id'])) return 0;
    $uid = $_SESSION['user_id'];
    $stmt = $mysqli->prepare("SELECT SUM(quantity) FROM cart WHERE user_id=?");
    $stmt->bind_param('i',$uid);
    $stmt->execute();
    $stmt->bind_result($c);
    $stmt->fetch();
    $stmt->close();
    return $c ? $c : 0;
}

function is_express_available($pincode){
    // simple simulation: express available for pincodes starting with 5 or 6
    if (!$pincode) return false;
    return in_array(substr($pincode,0,1), ['5','6']);
}

// Auth helper functions
function isLoggedIn(){
    return isset($_SESSION['user_id']);
}

function isAdmin(){
    global $mysqli;
    // Strict: require dedicated admin session id only
    $uid = $_SESSION['admin_id'] ?? null;
    if(!$uid) return false;
    
    $stmt = $mysqli->prepare("SELECT role FROM users WHERE id=?");
    $stmt->bind_param('i', $uid);
    $stmt->execute();
    $stmt->bind_result($role);
    $result = $stmt->fetch();
    $stmt->close();
    
    return $result && $role === 'admin';
}

function require_login(){
    if(!isLoggedIn()){
        $target = base_url('/login.php');
        if (!headers_sent()) {
            header('Location: ' . $target); exit;
        }
        // Fallback if output already started
        echo "<script>window.location.href='".htmlspecialchars($target, ENT_QUOTES)."';</script>";
        exit;
    }
}

function require_admin(){
    if(!isAdmin()){
        // Non-admin users get 403 Forbidden with proper error page
        $target = base_url('/error403.php');
        if (!headers_sent()) {
            http_response_code(403);
            header('Location: ' . $target);
            exit;
        }
        // Fallback if output already started
        echo "<script>window.location.href='".htmlspecialchars($target, ENT_QUOTES)."';</script>";
        exit;
    }
}

// CSRF helper functions
function ensure_csrf_token(){
    if(session_status() !== PHP_SESSION_ACTIVE) session_start();
    if(empty($_SESSION['csrf_token'])){
        try{
            $_SESSION['csrf_token'] = bin2hex(random_bytes(16));
        }catch(Exception $e){
            $_SESSION['csrf_token'] = md5(uniqid('', true));
        }
    }
    return $_SESSION['csrf_token'];
}

function csrf_input(){
    $t = ensure_csrf_token();
    return '<input type="hidden" name="csrf_token" value="'.htmlspecialchars($t, ENT_QUOTES).'">';
}

// Resolve asset or image URLs: return absolute URL if provided, otherwise prefix with base_url
function resolve_asset_url($path){
    if(!$path) return base_url('/assets/images/product-placeholder.jpg');
    $p = trim($path);
    if (preg_match('#^https?://#i', $p)) return $p;
    return base_url('/' . ltrim($p, '/'));
}

function validate_csrf_token($token){
    if(session_status() !== PHP_SESSION_ACTIVE) session_start();
    if(empty($_SESSION['csrf_token'])) return false;
    return hash_equals($_SESSION['csrf_token'], (string)$token);
}

// Create a product return request.
// Returns insert id on success, or false on failure.
function create_return($order_id, $product_id, $user_id, $reason){
    global $mysqli;
    if(!$order_id || !$product_id || !$user_id) return false;
    $reason = substr((string)$reason, 0, 1000); // limit reason length
    $stmt = $mysqli->prepare("INSERT INTO returns (order_id, product_id, user_id, reason, status, created_at) VALUES (?, ?, ?, ?, 'pending', NOW())");
    if(!$stmt) return false;
    $stmt->bind_param('iiis', $order_id, $product_id, $user_id, $reason);
    $ok = $stmt->execute();
    if(!$ok){ $stmt->close(); return false; }
    $id = $mysqli->insert_id;
    $stmt->close();
    return $id;
}

// Submit feedback for a product.
// $rating expected 1-5 (coerced), $comment optional. Returns insert id on success, false on failure.
function add_feedback($user_id, $product_id, $rating = null, $comment = ''){
    global $mysqli;
    if(!$user_id || !$product_id) return false;
    // Allow half-step ratings (e.g., 4.5). Normalize to nearest 0.5 and clamp 0.5..5.0
    $rating = $rating === null ? null : (float)$rating;
    if($rating !== null){
        // Round to nearest 0.5
        $rating = round($rating * 2) / 2.0;
        if($rating < 0.5) $rating = 0.5;
        if($rating > 5.0) $rating = 5.0;
    }
    $comment = substr((string)$comment, 0, 2000);

    // If rating is provided, include it; otherwise insert NULL
    // Use the `reviews` table (product_id, user_id, rating, comment)
    if($rating === null){
        $stmt = $mysqli->prepare("INSERT INTO reviews (product_id, user_id, rating, comment, created_at) VALUES (?, ?, NULL, ?, NOW())");
        if(!$stmt) return false;
        $stmt->bind_param('iis', $product_id, $user_id, $comment);
    } else {
        $stmt = $mysqli->prepare("INSERT INTO reviews (product_id, user_id, rating, comment, created_at) VALUES (?, ?, ?, ?, NOW())");
        if(!$stmt) return false;
        // bind product_id (i), user_id (i), rating (d), comment (s)
        $stmt->bind_param('iids', $product_id, $user_id, $rating, $comment);
    }

    $ok = $stmt->execute();
    if(!$ok){ $stmt->close(); return false; }
    $id = $mysqli->insert_id;
    $stmt->close();
    return $id;
}
?>