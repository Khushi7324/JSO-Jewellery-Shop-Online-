<?php
if (session_status() == PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/functions.php';
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Jewellery Shop - Premium Ornaments</title>
  <link rel="stylesheet" href="<?php echo base_url('/assets/css/design-system.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('/assets/css/style.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('/assets/css/background.css'); ?>">
  <style>
    /* Flipcart-style header */
    /* Header styles now use design-system.css and style.css */
    .logo a::before {
      content: "💎";
      font-size: 1.75rem;
    }
  </style>
</head>
<body class="<?=isset($body_class)?e($body_class):''?>">
<header class="site-header fixed-header">
  <div class="container">
    <div class="logo"><a href="<?php echo base_url('/'); ?>">Jewellery Shop</a></div>
    <form class="search" action="<?php echo base_url('/catalog.php'); ?>" method="get">
      <input type="text" name="q" placeholder="Search for jewellery, rings, necklaces..." value="<?=isset($_GET['q'])?htmlspecialchars($_GET['q']):''?>">
      <button type="submit">🔍 Search</button>
    </form>
    <nav class="top-nav">
      <?php if(isLoggedIn()): ?>
        <!-- Logged-in user: Show account options and admin link only if admin -->
        <a href="<?php echo base_url('/profile.php'); ?>">👤 Account</a>
        <a href="<?php echo base_url('/my_orders.php'); ?>">📦 My Orders</a>
        <a href="<?php echo base_url('/cart.php'); ?>" id="cart-link">🛒 Cart (<span id="cart-count"><?php echo cart_count(); ?></span>)</a>
        <a href="<?php echo base_url('/logout.php'); ?>">🚪 Logout</a>
        <?php if(isAdmin()): ?>
          <a href="<?php echo base_url('/admin/dashboard.php'); ?>" style="background:rgba(255,255,255,0.25);border-radius:var(--radius-sm);padding:var(--spacing-xs) var(--spacing-md)">⚙️ Admin Panel</a>
        <?php endif; ?>
      <?php else: ?>
        <!-- Not logged in: Show only Login and Register -->
        <a href="<?php echo base_url('/login.php'); ?>">🔑 Login</a>
        <a href="<?php echo base_url('/register.php'); ?>">✍️ Register</a>
      <?php endif; ?>
    </nav>
  </div>
  <div class="container" style="padding:0 10px 10px 10px">
    <nav style="display:flex;gap:var(--spacing-md);flex-wrap:wrap">
      <a href="<?php echo base_url('/catalog.php'); ?>" class="link-light" style="font-weight:600;background:rgba(255,255,255,0.15);padding:var(--spacing-xs) var(--spacing-md);border-radius:var(--radius-sm)">All</a>
      <a href="<?php echo base_url('/catalog.php?cat=1'); ?>" class="link-light" style="font-weight:600;background:rgba(255,255,255,0.15);padding:var(--spacing-xs) var(--spacing-md);border-radius:var(--radius-sm)">Gold</a>
      <a href="<?php echo base_url('/catalog.php?cat=2'); ?>" class="link-light" style="font-weight:600;background:rgba(255,255,255,0.15);padding:var(--spacing-xs) var(--spacing-md);border-radius:var(--radius-sm)">Diamond</a>
      <a href="<?php echo base_url('/catalog.php?cat=3'); ?>" class="link-light" style="font-weight:600;background:rgba(255,255,255,0.15);padding:var(--spacing-xs) var(--spacing-md);border-radius:var(--radius-sm)">Platinum</a>
      <a href="<?php echo base_url('/catalog.php?cat=4'); ?>" class="link-light" style="font-weight:600;background:rgba(255,255,255,0.15);padding:var(--spacing-xs) var(--spacing-md);border-radius:var(--radius-sm)">Gemstone</a>
      <a href="<?php echo base_url('/catalog.php?cat=5'); ?>" class="link-light" style="font-weight:600;background:rgba(255,255,255,0.15);padding:var(--spacing-xs) var(--spacing-md);border-radius:var(--radius-sm)">Silver</a>
      <a href="<?php echo base_url('/offers.php'); ?>" class="link-light" style="font-weight:600;background:rgba(255,255,255,0.15);padding:var(--spacing-xs) var(--spacing-md);border-radius:var(--radius-sm)">Deals</a>
    </nav>
  </div>
</header>
<script>
  window.APP_BASE = '<?php echo rtrim(base_url('/'), "/"); ?>' + '/';
</script>
<main class="page-content">
