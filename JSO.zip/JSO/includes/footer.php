</main>
<footer class="site-footer">
  <style>
    .site-footer {
      background: linear-gradient(135deg, var(--color-bg-dark) 0%, var(--color-bg-dark-secondary) 100%);
      color: var(--color-text-muted);
      padding: var(--spacing-2xl) 0 var(--spacing-lg);
      margin-top: var(--spacing-3xl);
      border-top: 1px solid rgba(255, 255, 255, 0.1);
      font-family: var(--font-primary);
    }
    
    .footer-content {
      max-width: 1400px;
      margin: 0 auto;
      padding: 0 var(--spacing-md);
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: var(--spacing-2xl);
      margin-bottom: var(--spacing-xl);
    }
    
    .footer-section h4 {
      color: var(--color-text-light);
      font-family: var(--font-secondary);
      font-weight: 700;
      margin: 0 0 var(--spacing-md) 0;
      font-size: 1.125rem;
    }
    
    .footer-section ul {
      list-style: none;
      padding: 0;
      margin: 0;
    }
    
    .footer-section li {
      margin-bottom: var(--spacing-sm);
    }
    
    .footer-section a {
      color: var(--color-text-muted);
      text-decoration: none;
      transition: color var(--transition-base);
      font-size: 0.875rem;
      font-family: var(--font-primary);
    }
    
    .footer-section a:hover {
      color: var(--color-text-light);
      text-decoration: none;
    }
    
    .footer-bottom {
      text-align: center;
      padding-top: var(--spacing-lg);
      border-top: 1px solid rgba(255, 255, 255, 0.1);
      color: var(--color-text-muted);
      font-size: 0.8125rem;
      font-family: var(--font-primary);
    }
  </style>

  <div class="footer-content">
    <div class="footer-section">
      <h4>💎 About Us</h4>
      <ul>
        <li><a href="<?php echo base_url('/about.php#story'); ?>">Our Story</a></li>
        <li><a href="<?php echo base_url('/about.php#craftsmanship'); ?>">Craftsmanship</a></li>
        <li><a href="<?php echo base_url('/about.php#quality'); ?>">Quality Assurance</a></li>
        <li><a href="<?php echo base_url('/about.php#awards'); ?>">Awards</a></li>
      </ul>
    </div>
    
    <div class="footer-section">
      <h4>🛍️ Shop</h4>
      <ul>
        <li><a href="<?php echo base_url('/catalog.php'); ?>">All Products</a></li>
        <li><a href="<?php echo base_url('/catalog.php?sort=low'); ?>">Price Low to High</a></li>
        <li><a href="<?php echo base_url('/catalog.php?sort=new'); ?>">New Arrivals</a></li>
        <li><a href="<?php echo base_url('/catalog.php?sort=best'); ?>">Best Sellers</a></li>
      </ul>
    </div>
    
    <div class="footer-section">
      <h4>📞 Customer Support</h4>
      <ul>
        <li><a href="<?php echo base_url('/help.php#contact'); ?>">Contact Us</a></li>
        <li><a href="<?php echo base_url('/help.php#shipping'); ?>">Shipping Info</a></li>
        <li><a href="<?php echo base_url('/help.php#returns'); ?>">Returns</a></li>
        <li><a href="<?php echo base_url('/help.php#faq'); ?>">FAQ</a></li>
      </ul>
    </div>
    
    <div class="footer-section">
      <h4>📋 Policies</h4>
      <ul>
        <li><a href="<?php echo base_url('/policies.php#privacy'); ?>">Privacy Policy</a></li>
        <li><a href="<?php echo base_url('/policies.php#terms'); ?>">Terms & Conditions</a></li>
        <li><a href="<?php echo base_url('/policies.php#refund'); ?>">Refund Policy</a></li>
        <li><a href="<?php echo base_url('/policies.php#warranty'); ?>">Warranty</a></li>
      </ul>
    </div>
  </div>
  
  <div class="footer-bottom">
    <p>&copy; 2025 Premium Jewellery Shop - All Rights Reserved | Crafted with ❤️</p>
  </div>
</footer>
<script src="<?php echo base_url('/assets/js/main.js'); ?>"></script>
</body>
</html>