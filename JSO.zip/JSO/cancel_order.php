<?php
session_start();
require 'config/db.php';
require 'includes/functions.php';

require_login();

$user_id = $_SESSION['user_id'];
$order_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

$stmt = $mysqli->prepare("SELECT * FROM orders WHERE id=? AND user_id=?");
$stmt->bind_param('ii', $order_id, $user_id);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$order) {
    die('Order not found');
}

// Allow cancellation for pending states (case-insensitive), including pending_payment
$status_lc = strtolower($order['status'] ?? '');
if (!in_array($status_lc, ['pending', 'confirmed', 'pending_payment'])) {
    header('Location: ' . base_url('/track_order.php?id=' . $order_id));
    exit;
}

$reason = trim($_POST['reason'] ?? '');
$notes = trim($_POST['notes'] ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (empty($reason)) {
        $error = 'Please select a cancellation reason';
    } else {
        // Cancel order
        $stmt = $mysqli->prepare("UPDATE orders SET status='cancelled', cancelled_at=NOW(), cancel_reason=?, cancel_notes=? WHERE id=? AND user_id=?");
        $stmt->bind_param('ssii', $reason, $notes, $order_id, $user_id);
        $stmt->execute();
        $stmt->close();

        // Restore cart items (optional - uncomment if you want)
        // $stmt = $mysqli->prepare("INSERT INTO cart (user_id, product_id, quantity) 
        //   SELECT ?, product_id, quantity FROM order_items WHERE order_id=?
        //   ON DUPLICATE KEY UPDATE quantity = quantity + VALUES(quantity)");
        // $stmt->bind_param('ii', $user_id, $order_id);
        // $stmt->execute();

        header('Location: ' . base_url('/track_order.php?id=' . $order_id . '&cancelled=1'));
        exit;
    }
}

$body_class = 'gold-glitter-bg';
require 'includes/header.php';
?>

<style>
.cancel-container {
  max-width: 500px;
  margin: 40px auto;
  padding: 30px;
  background: white;
  border-radius: 10px;
  box-shadow: 0 4px 20px rgba(0,0,0,0.1);
  border-left: 4px solid #ff6b6b;
}

.cancel-title {
  color: #d32f2f;
  font-size: 24px;
  font-weight: 700;
  margin-bottom: 10px;
}

.cancel-subtitle {
  color: #666;
  font-size: 14px;
  margin-bottom: 20px;
}

.order-summary {
  background: #f5f5f5;
  padding: 15px;
  border-radius: 6px;
  margin-bottom: 20px;
}

.summary-row {
  display: flex;
  justify-content: space-between;
  margin-bottom: 8px;
  font-size: 14px;
}

.summary-row:last-child {
  margin-bottom: 0;
  font-weight: 700;
  color: #333;
  border-top: 1px solid #ddd;
  padding-top: 8px;
}

.form-group {
  margin-bottom: 20px;
}

.form-group label {
  display: block;
  margin-bottom: 8px;
  color: #333;
  font-weight: 600;
  font-size: 14px;
}

.form-group select,
.form-group textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ddd;
  border-radius: 6px;
  font-size: 14px;
  font-family: inherit;
  box-sizing: border-box;
}

.form-group select:focus,
.form-group textarea:focus {
  outline: none;
  border-color: #ff6b6b;
  box-shadow: 0 0 0 3px rgba(255,107,107,0.1);
}

.form-group textarea {
  resize: vertical;
  min-height: 80px;
}

.error {
  color: #d32f2f;
  font-size: 13px;
  margin-bottom: 15px;
  padding: 10px;
  background: #ffebee;
  border-radius: 6px;
  border-left: 3px solid #d32f2f;
}

.buttons {
  display: flex;
  gap: 10px;
}

button {
  flex: 1;
  padding: 12px;
  border: none;
  border-radius: 6px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s;
  font-size: 14px;
}

.btn-cancel {
  background: #ff6b6b;
  color: white;
}

.btn-cancel:hover {
  background: #d32f2f;
  transform: translateY(-2px);
}

.btn-back {
  background: #f5f5f5;
  color: #333;
  border: 1px solid #ddd;
}

.btn-back:hover {
  background: #efefef;
}
</style>

<div class="cancel-container">
  <h1 class="cancel-title">❌ Cancel Order</h1>
  <p class="cancel-subtitle">Order #<?php echo e($order['id']); ?> - <?php $created = $order['created_at'] ?? ($order['order_date'] ?? null); echo $created ? date('M d, Y', strtotime($created)) : ''; ?></p>

  <div class="order-summary">
    <?php $subtotal = $order['subtotal'] ?? ($order['total'] ?? ($order['total_amount'] ?? 0)); ?>
    <div class="summary-row">
      <span>Subtotal</span>
      <span>₹<?php echo number_format($subtotal); ?></span>
    </div>
    <?php $discount = $order['discount'] ?? 0; ?>
    <div class="summary-row">
      <span>Discount</span>
      <span>-₹<?php echo number_format($discount); ?></span>
    </div>
    <?php $shipping = $order['shipping'] ?? 0; ?>
    <div class="summary-row">
      <span>Shipping</span>
      <span>₹<?php echo number_format($shipping); ?></span>
    </div>
    <?php $total_amt = $order['total'] ?? ($order['total_amount'] ?? ($subtotal - $discount + $shipping)); ?>
    <div class="summary-row">
      <span>Total</span>
      <span>₹<?php echo number_format($total_amt); ?></span>
    </div>
  </div>

  <?php if (isset($error) && $error): ?>
    <div class="error">⚠️ <?php echo e($error); ?></div>
  <?php endif; ?>

  <form method="POST">
    <div class="form-group">
      <label for="reason">Reason for Cancellation *</label>
      <select id="reason" name="reason" required>
        <option value="">-- Select a reason --</option>
        <option value="changed_mind">Changed my mind</option>
        <option value="found_cheaper">Found cheaper elsewhere</option>
        <option value="unexpected_fees">Unexpected fees/charges</option>
        <option value="delayed_delivery">Delivery taking too long</option>
        <option value="order_error">Order placed by mistake</option>
        <option value="other">Other reason</option>
      </select>
    </div>

    <div class="form-group">
      <label for="notes">Additional Notes (Optional)</label>
      <textarea id="notes" name="notes" placeholder="Tell us more about your cancellation..."></textarea>
    </div>

    <div class="buttons">
      <button type="button" class="btn-back" onclick="history.back()">← Go Back</button>
      <button type="submit" class="btn-cancel" onclick="return confirm('Are you sure you want to cancel this order? This action cannot be undone.');">Yes, Cancel Order</button>
    </div>
  </form>
</div>

<?php require 'includes/footer.php'; ?>
