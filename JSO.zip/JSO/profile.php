<?php
$body_class = 'moving-gradient-bg';
require 'includes/header.php';
require_login();
$uid = $_SESSION['user_id'];
$errors = [];
$stmt = $mysqli->prepare("SELECT name,email,phone,address,created_at FROM users WHERE id=?");
$stmt->bind_param('i',$uid);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Get order count
$stmt = $mysqli->prepare("SELECT COUNT(*) as count FROM orders WHERE user_id=?");
$stmt->bind_param('i', $uid);
$stmt->execute();
$order_count = $stmt->get_result()->fetch_assoc()['count'];
$stmt->close();

// Get cart count
$stmt = $mysqli->prepare("SELECT SUM(quantity) as count FROM cart WHERE user_id=?");
$stmt->bind_param('i', $uid);
$stmt->execute();
$cart_count = $stmt->get_result()->fetch_assoc()['count'] ?? 0;
$stmt->close();

// Get membership badge
$membership = $order_count >= 10 ? 'Gold' : ($order_count >= 5 ? 'Silver' : 'Regular');

$name = $user['name'];
$email = $user['email'];
$phone = $user['phone'];
$address = $user['address'];

if($_SERVER['REQUEST_METHOD']=='POST'){
    $name = trim($_POST['name']); $phone = trim($_POST['phone']); $address = trim($_POST['address']);
    $stmt = $mysqli->prepare("UPDATE users SET name=?, phone=?, address=? WHERE id=?");
    $stmt->bind_param('sssi',$name,$phone,$address,$uid);
    if($stmt->execute()){ $msg = 'Profile updated'; } else { $errors[] = 'DB error'; }
}
?>
<h2>My Profile</h2>
<?php if(isset($msg)): ?><div style="color:green"><?=e($msg)?></div><?php endif; ?>
<?php if($errors): ?><div style="color:red"><?=implode('<br>',$errors)?></div><?php endif; ?>
<form method="post">
  <label>Name</label><input type="text" name="name" value="<?=e($name)?>" required>
  <label>Email</label><input type="email" value="<?=e($email)?>" disabled>
  <label>Phone</label><input type="text" name="phone" value="<?=e($phone)?>">
  <label>Address</label><textarea name="address"><?=e($address)?></textarea>
  <div style="margin-top:8px"><button class="btn">Update</button></div>
</form>

<?php require 'includes/footer.php';?>