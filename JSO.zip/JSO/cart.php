<?php
session_start();
require 'config/db.php';
require 'includes/functions.php';

require_login();

$body_class = 'diamond-shine-bg';
$csrf_token = ensure_csrf_token();

$uid = $_SESSION['user_id'];
$message = '';
$error = '';

// Handle non-AJAX add/remove from URL (legacy links)
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action'])) {
    $action = $_GET['action'];
    $pid = intval($_GET['id'] ?? 0);
    $qty = intval($_GET['qty'] ?? 1);
    $cartId = intval($_GET['cart_id'] ?? 0);

    if ($action === 'add' && $pid > 0 && $qty > 0) {
        $stmt = $mysqli->prepare("SELECT id, stock FROM products WHERE id=?");
        $stmt->bind_param('i', $pid);
        $stmt->execute();
        $product = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if ($product) {
            $stmt = $mysqli->prepare("SELECT id, quantity FROM cart WHERE user_id=? AND product_id=?");
            $stmt->bind_param('ii', $uid, $pid);
            $stmt->execute();
            $existing = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if ($existing) {
                $new_qty = $existing['quantity'] + $qty;
                $stmt = $mysqli->prepare("UPDATE cart SET quantity=? WHERE id=?");
                $stmt->bind_param('ii', $new_qty, $existing['id']);
                $stmt->execute();
                $stmt->close();
            } else {
                $stmt = $mysqli->prepare("INSERT INTO cart(user_id, product_id, quantity) VALUES(?, ?, ?)");
                $stmt->bind_param('iii', $uid, $pid, $qty);
                $stmt->execute();
                $stmt->close();
            }
        }
        header('Location: ' . base_url('/cart.php'));
        exit;
    }

    if ($action === 'remove' && $cartId > 0) {
        $stmt = $mysqli->prepare("DELETE FROM cart WHERE id=? AND user_id=?");
        $stmt->bind_param('ii', $cartId, $uid);
        $stmt->execute();
        $stmt->close();
        header('Location: ' . base_url('/cart.php'));
        exit;
    }
}

// Handle AJAX requests
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    // Validate CSRF token for POST requests
    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        echo json_encode(['success' => false, 'message' => 'Invalid CSRF token']);
        exit;
    }
    
    if ($_POST['action'] === 'add') {
        $pid = intval($_POST['product_id'] ?? 0);
        $qty = intval($_POST['quantity'] ?? 1);
        
        if ($pid <= 0 || $qty <= 0) {
            echo json_encode(['success' => false, 'message' => 'Invalid product or quantity']);
            exit;
        }
        
        // Check if product exists
        $stmt = $mysqli->prepare("SELECT id, stock FROM products WHERE id=?");
        $stmt->bind_param('i', $pid);
        $stmt->execute();
        $product = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        if (!$product) {
            echo json_encode(['success' => false, 'message' => 'Product not found']);
            exit;
        }
        
        // Check if already in cart
        $stmt = $mysqli->prepare("SELECT id, quantity FROM cart WHERE user_id=? AND product_id=?");
        $stmt->bind_param('ii', $uid, $pid);
        $stmt->execute();
        $existing = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        if ($existing) {
            // Update quantity
            $new_qty = $existing['quantity'] + $qty;
            $stmt = $mysqli->prepare("UPDATE cart SET quantity=? WHERE id=?");
            $stmt->bind_param('ii', $new_qty, $existing['id']);
            $stmt->execute();
            $stmt->close();
        } else {
            // Add to cart
            $stmt = $mysqli->prepare("INSERT INTO cart(user_id, product_id, quantity) VALUES(?, ?, ?)");
            $stmt->bind_param('iii', $uid, $pid, $qty);
            $stmt->execute();
            $stmt->close();
        }
        
        echo json_encode(['success' => true, 'message' => '✅ Added to cart!', 'cart_count' => cart_count()]);
        exit;
    }
    
    if ($_POST['action'] === 'remove') {
        $cart_id = intval($_POST['cart_id'] ?? 0);
        $stmt = $mysqli->prepare("DELETE FROM cart WHERE id=? AND user_id=?");
        $stmt->bind_param('ii', $cart_id, $uid);
        $stmt->execute();
        $stmt->close();
        
        echo json_encode(['success' => true, 'message' => 'Item removed', 'cart_count' => cart_count()]);
        exit;
    }
    
    if ($_POST['action'] === 'update_qty') {
        $cart_id = intval($_POST['cart_id'] ?? 0);
        $qty = intval($_POST['quantity'] ?? 1);
        
        if ($qty <= 0) {
            $stmt = $mysqli->prepare("DELETE FROM cart WHERE id=? AND user_id=?");
            $stmt->bind_param('ii', $cart_id, $uid);
            $stmt->execute();
            $stmt->close();
        } else {
            $stmt = $mysqli->prepare("UPDATE cart SET quantity=? WHERE id=? AND user_id=?");
            $stmt->bind_param('iii', $qty, $cart_id, $uid);
            $stmt->execute();
            $stmt->close();
        }
        
        echo json_encode(['success' => true, 'message' => 'Updated', 'cart_count' => cart_count()]);
        exit;
    }
}

// Fetch cart items (order by time added)
$stmt = $mysqli->prepare("SELECT c.id as cart_id, p.id as product_id, p.name, p.price, p.category_id, c.quantity FROM cart c JOIN products p ON p.id=c.product_id WHERE c.user_id=? ORDER BY c.added_at DESC");
$stmt->bind_param('i', $uid);
$stmt->execute();
$items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$subtotal = 0;
$discount = 0;
$shipping = 0;
$total = 0;

foreach ($items as $item) {
    $subtotal += $item['price'] * $item['quantity'];
}

// Check for applied coupon
if (isset($_SESSION['applied_coupon'])) {
    $coupon = $_SESSION['applied_coupon'];
    if ($coupon['discount_type'] === 'percentage') {
        $discount = ($subtotal * $coupon['discount_value']) / 100;
    } else {
        $discount = $coupon['discount_value'];
    }
}

// Shipping cost
$shipping = 50; // Standard shipping

$total = $subtotal - $discount + $shipping;

require 'includes/header.php';
?>

<style>
.cart-container {
  max-width: 1000px;
  margin: 40px auto;
  padding: 20px;
}

.cart-header {
  font-size: 28px;
  font-weight: 700;
  color: #333;
  margin-bottom: 30px;
}

.cart-content {
  display: grid;
  grid-template-columns: 1fr 350px;
  gap: 30px;
}

.cart-items {
  background: white;
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 2px 8px rgba(0,0,0,0.08);
}

.empty-cart {
  text-align: center;
  padding: 80px 20px;
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.08);
}

.empty-icon {
  font-size: 60px;
  margin-bottom: 20px;
}

.empty-text {
  color: #666;
  font-size: 16px;
  margin-bottom: 20px;
}

.continue-btn {
  display: inline-block;
  padding: 12px 30px;
  background: linear-gradient(180deg, #cda34f, #b0852b);
  color: white;
  text-decoration: none;
  border-radius: 6px;
  font-weight: 600;
}

.cart-item {
  display: flex;
  align-items: center;
  gap: 20px;
  padding: 20px;
  border-bottom: 1px solid #eee;
  transition: all 0.2s;
}

.cart-item:hover {
  background: #f9f9f9;
}

.item-image {
  width: 100px;
  height: 100px;
  background: #f5f5f5;
  border-radius: 6px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #999;
  font-size: 40px;
  flex-shrink: 0;
}

.item-details {
  flex: 1;
}

.item-name {
  font-weight: 700;
  color: #333;
  margin-bottom: 8px;
}

.item-price {
  color: #666;
  font-size: 14px;
  margin-bottom: 12px;
}

.qty-control {
  display: flex;
  align-items: center;
  gap: 8px;
  width: fit-content;
}

.qty-btn {
  width: 32px;
  height: 32px;
  border: 1px solid #ddd;
  background: white;
  border-radius: 4px;
  cursor: pointer;
  font-weight: 700;
  transition: all 0.2s;
}

.qty-btn:hover {
  background: #f5f5f5;
  border-color: #cda34f;
}

.qty-input {
  width: 50px;
  text-align: center;
  border: 1px solid #ddd;
  border-radius: 4px;
  padding: 6px;
}

.item-total {
  text-align: right;
  margin-left: 20px;
  min-width: 100px;
}

.item-total-price {
  font-size: 18px;
  font-weight: 700;
  color: #cda34f;
  margin-bottom: 10px;
}

.remove-btn {
  background: #f44336;
  color: white;
  border: none;
  padding: 6px 12px;
  border-radius: 4px;
  cursor: pointer;
  font-size: 12px;
  font-weight: 600;
  transition: all 0.2s;
}

.remove-btn:hover {
  background: #d32f2f;
}

.cart-summary {
  background: white;
  border-radius: 8px;
  padding: 20px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.08);
  position: sticky;
  top: 100px;
}

.summary-title {
  font-weight: 700;
  color: #333;
  margin-bottom: 20px;
  font-size: 16px;
}

.summary-row {
  display: flex;
  justify-content: space-between;
  margin-bottom: 12px;
  padding-bottom: 12px;
  border-bottom: 1px solid #eee;
  color: #666;
  font-size: 14px;
}

.summary-row.total {
  border-bottom: none;
  margin-top: 12px;
  font-weight: 700;
  font-size: 16px;
  color: #333;
}

.summary-row.total .amount {
  color: #cda34f;
  font-size: 20px;
}

.coupon-section {
  background: #f9f9f9;
  padding: 12px;
  border-radius: 6px;
  margin-bottom: 20px;
}

.coupon-input {
  width: 100%;
  padding: 8px;
  border: 1px solid #ddd;
  border-radius: 4px;
  margin-bottom: 8px;
  font-size: 13px;
  box-sizing: border-box;
}

.apply-coupon-btn {
  width: 100%;
  padding: 8px;
  background: #1976d2;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-weight: 600;
  font-size: 13px;
}

.checkout-btn {
  width: 100%;
  padding: 14px;
  background: linear-gradient(180deg, #cda34f, #b0852b);
  color: white;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-weight: 700;
  font-size: 16px;
  transition: all 0.2s;
}

.checkout-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 18px rgba(205,163,79,0.3);
}

.checkout-btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.success-msg, .error-msg {
  padding: 12px;
  border-radius: 6px;
  margin-bottom: 20px;
  font-size: 14px;
}

.success-msg {
  background: #d4edda;
  color: #155724;
  border-left: 4px solid #28a745;
}

.error-msg {
  background: #f8d7da;
  color: #721c24;
  border-left: 4px solid #f44336;
}

@media (max-width: 768px) {
  .cart-content {
    grid-template-columns: 1fr;
  }
  
  .cart-summary {
    position: static;
  }
  
  .cart-item {
    flex-wrap: wrap;
  }
  
  .item-total {
    width: 100%;
    text-align: left;
    margin-left: 0;
    margin-top: 10px;
  }
}
</style>

<div class="cart-container">
  <h1 class="cart-header">🛒 Shopping Cart</h1>

  <?php if ($message): ?>
    <div class="success-msg"><?php echo $message; ?></div>
  <?php endif; ?>

  <?php if ($error): ?>
    <div class="error-msg"><?php echo $error; ?></div>
  <?php endif; ?>

  <?php if (empty($items)): ?>
    <div class="empty-cart">
      <div class="empty-icon">🛍️</div>
      <p class="empty-text">Your cart is empty</p>
      <a href="<?php echo base_url('/catalog.php'); ?>" class="continue-btn">Continue Shopping</a>
    </div>
  <?php else: ?>
    <div class="cart-content">
      <!-- CART ITEMS -->
      <div class="cart-items">
        <?php foreach ($items as $item): ?>
          <div class="cart-item" id="item-<?php echo $item['cart_id']; ?>">
            <div class="item-image">💍</div>
            <div class="item-details">
              <div class="item-name"><?php echo e($item['name']); ?></div>
              <div class="item-price">₹<?php echo number_format($item['price']); ?> per item</div>
              <div class="qty-control">
                <button class="qty-btn" onclick="updateQty(<?php echo $item['cart_id']; ?>, -1)">−</button>
                <input type="number" class="qty-input" id="qty-<?php echo $item['cart_id']; ?>" value="<?php echo $item['quantity']; ?>" min="1" onchange="updateQty(<?php echo $item['cart_id']; ?>, 0, this.value)">
                <button class="qty-btn" onclick="updateQty(<?php echo $item['cart_id']; ?>, 1)">+</button>
              </div>
            </div>
            <div class="item-total">
              <div class="item-total-price" id="total-<?php echo $item['cart_id']; ?>">
                ₹<?php echo number_format($item['price'] * $item['quantity']); ?>
              </div>
              <button class="remove-btn" onclick="removeItem(<?php echo $item['cart_id']; ?>)">Remove</button>
            </div>
          </div>
        <?php endforeach; ?>
      </div>

      <!-- SUMMARY -->
      <div class="cart-summary">
        <div class="summary-title">Order Summary</div>
        
        <div class="summary-row">
          <span>Subtotal</span>
          <span id="subtotal">₹<?php echo number_format($subtotal, 0); ?></span>
        </div>

        <?php if (isset($_SESSION['applied_coupon'])): ?>
          <div class="summary-row" style="color: #4caf50;">
            <span>Discount (<?php echo $_SESSION['applied_coupon']['code']; ?>)</span>
            <span>-₹<?php echo number_format($discount, 0); ?></span>
          </div>
        <?php endif; ?>

        <div class="summary-row">
          <span>Shipping</span>
          <span id="shipping">₹<?php echo number_format($shipping, 0); ?></span>
        </div>

        <div class="summary-row total">
          <span>Total</span>
          <span class="amount" id="total">₹<?php echo number_format($total, 0); ?></span>
        </div>

        <div class="coupon-section">
          <input type="text" class="coupon-input" id="coupon_code" placeholder="Enter coupon code">
          <button class="apply-coupon-btn" onclick="applyCoupon()">Apply Coupon</button>
        </div>

        <button class="checkout-btn" onclick="proceedToCheckout()">Proceed to Checkout</button>
      </div>
    </div>
  <?php endif; ?>
</div>

<script>
function updateQty(cartId, change, newValue) {
  let input = document.getElementById('qty-' + cartId);
  let qty = newValue ? parseInt(newValue) : parseInt(input.value) + change;
  
  if (qty < 1) qty = 1;
  input.value = qty;

  fetch('<?php echo base_url('/cart.php'); ?>', {
    method: 'POST',
    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
    body: 'action=update_qty&cart_id=' + cartId + '&quantity=' + qty + '&csrf_token=' + encodeURIComponent(csrfToken)
  })
  .then(r => r.json())
  .then(data => {
    if (data.success) {
      location.reload();
    }
  });
}

function removeItem(cartId) {
  if (confirm('Remove this item from cart?')) {
    fetch('<?php echo base_url('/cart.php'); ?>', {
      method: 'POST',
      headers: {'Content-Type': 'application/x-www-form-urlencoded'},
      body: 'action=remove&cart_id=' + cartId + '&csrf_token=' + encodeURIComponent(csrfToken)
    })
    .then(r => r.json())
    .then(data => {
      if (data.success) {
        location.reload();
      }
    });
  }
}

function applyCoupon() {
  let code = document.getElementById('coupon_code').value.trim();
  if (!code) {
    alert('Please enter a coupon code');
    return;
  }
  
  fetch('<?php echo base_url('/api/coupon_handler.php?action=apply_coupon'); ?>', {
    method: 'POST',
    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
    body: 'coupon_code=' + code
  })
  .then(r => r.json())
  .then(data => {
    if (data.success) {
      alert('✅ Coupon applied! Discount: ₹' + data.discount);
      location.reload();
    } else {
      alert('❌ ' + data.message);
    }
  });
}

function proceedToCheckout() {
  window.location.href = '<?php echo base_url('/checkout.php'); ?>';
}

const csrfToken = '<?php echo e($csrf_token); ?>';
</script>

<?php require 'includes/footer.php'; ?>
