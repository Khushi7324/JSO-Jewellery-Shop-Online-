<?php
$body_class = 'gold-glitter-bg';
require 'includes/header.php';
?>

<style>
.info-page {
  max-width: 900px;
  margin: 40px auto;
  padding: 20px;
}
.info-section {
  background: white;
  border-radius: 10px;
  padding: 20px 24px;
  margin-bottom: 20px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.06);
}
.info-section h2 {
  margin: 0 0 10px 0;
  font-size: 22px;
  color: #333;
}
.info-section p, .info-section li {
  margin: 0 0 6px 0;
  color: #555;
  line-height: 1.6;
  font-size: 14px;
}
.info-section ul {
  padding-left: 18px;
}
</style>

<div class="info-page">
  <div class="info-section" id="contact">
    <h2>Contact Us</h2>
    <p>This demo store does not send real emails, but in a live site you can place your phone, email and address here.</p>
    <p>For now, use this page as a reference entry point for customer support.</p>
  </div>

  <div class="info-section" id="shipping">
    <h2>Shipping Info</h2>
    <ul>
      <li>Standard shipping fee is the same as shown at checkout (₹50 in this demo).</li>
      <li>Delivery status is updated in real time in the “Track Order” page after checkout.</li>
      <li>Express availability is simulated for pincodes starting with 5 or 6.</li>
    </ul>
  </div>

  <div class="info-section" id="returns">
    <h2>Returns</h2>
    <p>Returns are available within 7 days of delivery for eligible orders.</p>
    <p>Customers can start a return from the Track Order page using the “Return Product” button after delivery is marked as complete.</p>
  </div>

  <div class="info-section" id="faq">
    <h2>FAQ</h2>
    <p><strong>Q: Is payment live?</strong><br> A: No, payments are simulated, but the order flow and status updates are realistic.</p>
    <p><strong>Q: Can I use Cash on Delivery?</strong><br> A: Yes, COD is supported and routes you directly to order success with a COD tracking id.</p>
    <p><strong>Q: How do I track my order?</strong><br> A: Go to “My Orders” &gt; “View/Track” to see the full delivery timeline.</p>
  </div>
</div>

<?php require 'includes/footer.php'; ?>


