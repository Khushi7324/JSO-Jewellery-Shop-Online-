<?php
require __DIR__ . '/../config/db.php';

// Fix admin users missing email or phone
$queries = [
    "UPDATE users SET email = CONCAT(LOWER(REPLACE(name,' ','')), '@example.com') WHERE role='admin' AND (email IS NULL OR email='')",
    "UPDATE users SET phone = '0000000000' WHERE role='admin' AND (phone IS NULL OR phone='')",
];

foreach ($queries as $q) {
    $r = $mysqli->query($q);
    if ($r === false) {
        echo "Failed: " . $mysqli->error . "\n";
    } else {
        echo "OK: " . $q . "\n";
    }
}

// Print current admin rows
$res = $mysqli->query("SELECT id, name, email, phone, role FROM users WHERE role='admin'");
while ($row = $res->fetch_assoc()) {
    echo json_encode($row) . "\n";
}

echo "Done\n";
?>