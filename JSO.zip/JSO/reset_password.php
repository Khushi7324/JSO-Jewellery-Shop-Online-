<?php
$token = $_GET['token'] ?? '';
$new_password = $_POST['new_password'] ?? '';
$confirm_password = $_POST['confirm_password'] ?? '';
$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $token) {
    if (strlen($new_password) < 6) {
        $errors[] = 'Password must be at least 6 characters';
    } elseif ($new_password !== $confirm_password) {
        $errors[] = 'Passwords do not match';
    } else {
        // Check if token is valid and not expired (24 hours)
        $stmt = $mysqli->prepare("SELECT user_id FROM password_resets WHERE token = ? AND created_at > DATE_SUB(NOW(), INTERVAL 24 HOUR)");
        $stmt->bind_param('s', $token);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            $user_id = $result->fetch_assoc()['user_id'];
            
            // Update password
            $hash = password_hash($new_password, PASSWORD_DEFAULT);
            $stmt = $mysqli->prepare("UPDATE users SET password = ? WHERE id = ?");
            $stmt->bind_param('si', $hash, $user_id);
            $stmt->execute();
            
            // Delete the token
            $stmt = $mysqli->prepare("DELETE FROM password_resets WHERE token = ?");
            $stmt->bind_param('s', $token);
            $stmt->execute();
            
            // Flag success and show the proper dynamic link after header includes functions
            $success = true;
            $success_msg = 'Password reset successfully!';
        } else {
            $errors[] = 'Invalid or expired reset link';
        }
        $stmt->close();
    }
}

$body_class = 'gold-glitter-bg';
require 'includes/header.php';
?>

<div style="min-height:70vh;display:flex;align-items:center;justify-content:center;position:relative;padding-top:80px">
  <div class="glass-card fade-in-up" style="max-width:420px;width:100%">
    <h2 style="margin-top:0;color:var(--gold-dark)">Reset Password</h2>
    
    <?php if ($success): ?>
      <div style="color:#4caf50;margin-bottom:16px"><?php echo $success_msg; ?> <a href="<?php echo base_url('/login.php'); ?>">Login here</a></div>
    <?php else: ?>
      <?php if ($errors): ?>
        <div style="color:#d32f2f;margin-bottom:16px"><?=implode('<br>', $errors)?></div>
      <?php endif; ?>
      
      <?php if (!$token): ?>
        <p style="color:#777;margin-bottom:16px">Enter your email or phone to receive a reset link.</p>
        <form method="post" style="display:flex;flex-direction:column;gap:10px">
          <input class="gold-border" type="text" name="login" placeholder="Email or Phone (10 digits)" required>
          <button class="btn btn-glow" type="submit" name="send_reset">Send Reset Link</button>
        </form>
      <?php else: ?>
        <form method="post" style="display:flex;flex-direction:column;gap:10px">
          <input class="gold-border" type="password" name="new_password" placeholder="New Password (6+ chars)" required>
          <input class="gold-border" type="password" name="confirm_password" placeholder="Confirm New Password" required>
          <button class="btn btn-glow" type="submit">Reset Password</button>
        </form>
      <?php endif; ?>
    <?php endif; ?>
  </div>
</div>

<?php 
// Handle sending reset link
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_reset'])) {
    $login = trim($_POST['login']);
    $is_email = filter_var($login, FILTER_VALIDATE_EMAIL);
    $is_phone = preg_match('/^\d{10}$/', $login);
    
    if ($is_email || $is_phone) {
        $stmt = $mysqli->prepare("SELECT id, email FROM users WHERE email = ? OR phone = ?");
        $stmt->bind_param('ss', $login, $login);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            $token = bin2hex(random_bytes(32));
            
            // Save token
            $stmt = $mysqli->prepare("INSERT INTO password_resets (user_id, token, created_at) VALUES (?, ?, NOW())");
            $stmt->bind_param('is', $user['id'], $token);
            $stmt->execute();
            
            // In production, send email. For now, show the link generated from current host
            $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
            $proto = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
            $reset_link = $proto . '://' . $host . base_url('/reset_password.php?token=' . $token);
            echo "<script>alert('Reset link: $reset_link');</script>";
        }
        $stmt->close();
    }
}

require 'includes/footer.php';
?>
