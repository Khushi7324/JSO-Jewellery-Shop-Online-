<?php
require_once __DIR__.'/_auth.php';
require_once __DIR__.'/../includes/functions.php';

$customers = $mysqli->query("SELECT id, name, email, phone, created_at FROM users WHERE role='user' ORDER BY created_at DESC")->fetch_all(MYSQLI_ASSOC);
?>
<!doctype html><html><head><meta charset="utf-8"><title>Customers</title><link rel="stylesheet" href="<?php echo base_url('/assets/css/design-system.css'); ?>"><link rel="stylesheet" href="<?php echo base_url('/assets/css/style.css'); ?>"><link rel="stylesheet" href="<?php echo base_url('/assets/css/background.css'); ?>"></head><body class="dark-elegant-bg">
<div class="container">
  <h2 style="color:var(--color-secondary)">Customers</h2>
  <nav style="margin-bottom:20px"><a href="<?php echo base_url('/admin/dashboard.php'); ?>" style="color:#fff;text-decoration:none">← Dashboard</a> | <a href="<?php echo base_url('/admin/logout.php'); ?>" style="color:#fff;text-decoration:none">Logout</a></nav>
  <table style="width:100%; border-collapse:collapse">
    <tr style="background:rgba(205,163,79,0.1)">
      <th style="padding:10px;color:#fff">ID</th>
      <th style="padding:10px;color:#fff">Name</th>
      <th style="padding:10px;color:#fff">Email</th>
      <th style="padding:10px;color:#fff">Phone</th>
      <th style="padding:10px;color:#fff">Joined</th>
    </tr>
    <?php foreach ($customers as $c): ?>
    <tr>
      <td style="padding:10px;border-bottom:1px solid #444"><?=e($c['id'])?></td>
      <td style="padding:10px;border-bottom:1px solid #444"><?=e($c['name'])?></td>
      <td style="padding:10px;border-bottom:1px solid #444"><?=e($c['email'])?></td>
      <td style="padding:10px;border-bottom:1px solid #444"><?=e($c['phone'])?></td>
      <td style="padding:10px;border-bottom:1px solid #444"><?=e($c['created_at'])?></td>
    </tr>
    <?php endforeach; ?>
  </table>
</div>
</body></html>
