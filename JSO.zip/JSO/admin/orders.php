<?php
require_once __DIR__.'/_auth.php';
require_once __DIR__.'/../includes/functions.php';
if(isset($_POST['update_status'])){
    $oid = intval($_POST['order_id']); $status = $_POST['status'];
    $stmt = $mysqli->prepare("UPDATE orders SET status=? WHERE id=?"); $stmt->bind_param('si',$status,$oid); $stmt->execute();
    // Insert or update delivery_status
    $stmt = $mysqli->prepare("INSERT INTO delivery_status(order_id,status,update_time) VALUES(?,?,NOW()) ON DUPLICATE KEY UPDATE status=?, update_time=NOW()");
    $stmt->bind_param('iss', $oid, $status, $status);
    $stmt->execute();
    // Redirect to avoid form resubmit
    header("Location: " . base_url('/admin/orders.php?updated=1'));
    exit;
}
$orders = $mysqli->query("
SELECT o.*, u.name AS customer, dsl.latest_update AS last_update
FROM orders o
LEFT JOIN users u ON u.id = o.user_id
LEFT JOIN (
  SELECT order_id, MAX(update_time) AS latest_update
  FROM delivery_status
  GROUP BY order_id
) dsl ON dsl.order_id = o.id
ORDER BY o.order_date DESC
")->fetch_all(MYSQLI_ASSOC);
?>
<!doctype html><html><head><meta charset="utf-8"><title>Orders</title><link rel="stylesheet" href="<?php echo base_url('/assets/css/design-system.css'); ?>"><link rel="stylesheet" href="<?php echo base_url('/assets/css/style.css'); ?>"><link rel="stylesheet" href="<?php echo base_url('/assets/css/background.css'); ?>"></head><body class="dark-elegant-bg">
<div class="container">
  <h2 style="color:var(--color-secondary)">Orders</h2>
  <nav style="margin-bottom:20px"><a href="<?php echo base_url('/admin/dashboard.php'); ?>" style="color:#fff;text-decoration:none">← Dashboard</a> | <a href="<?php echo base_url('/admin/logout.php'); ?>" style="color:#fff;text-decoration:none">Logout</a></nav>
  <?php if(isset($_GET['updated'])): ?>
    <div style="color:#4caf50; margin-bottom:12px">Order status updated.</div>
  <?php endif; ?>
  <table style="width:100%; border-collapse:collapse">
    <tr style="background:rgba(205,163,79,0.1)">
      <th style="padding:10px;color:#fff">Order</th>
      <th style="padding:10px;color:#fff">Customer</th>
      <th style="padding:10px;color:#fff">Total</th>
      <th style="padding:10px;color:#fff">Status</th>
      <th style="padding:10px;color:#fff">Last Updated</th>
      <th style="padding:10px;color:#fff">Action</th>
    </tr>
  <?php foreach($orders as $o): ?>
    <tr>
      <td style="padding:10px;border-bottom:1px solid #444">#<?=e($o['id'])?> <br><?=e($o['order_date'])?></td>
      <td style="padding:10px;border-bottom:1px solid #444"><?=e($o['customer'])?></td>
      <td style="padding:10px;border-bottom:1px solid #444">₹ <?=number_format($o['total'],2)?></td>
      <td style="padding:10px;border-bottom:1px solid #444"><?=e($o['status'])?></td>
      <td style="padding:10px;border-bottom:1px solid #444"><?=e($o['last_update'] ?? 'N/A')?></td>
      <td style="padding:10px;border-bottom:1px solid #444">
        <?php if($o['status'] === 'Delivered' || $o['status'] === 'Cancelled'): ?>
          <div style="color:#4caf50;font-weight:600">Delivered</div>
          <div style="color:#999;font-size:12px">Updates locked</div>
        <?php else: ?>
          <form method="post" style="display:inline">
            <input type="hidden" name="order_id" value="<?=$o['id']?>">
            <select name="status" style="margin-right:8px">
              <option value="Pending" <?=($o['status']==='Pending')?'selected':''?>>Pending</option>
              <option value="Processing" <?=($o['status']==='Processing')?'selected':''?>>Processing</option>
              <option value="Packing" <?=($o['status']==='Packing')?'selected':''?>>Packing</option>
              <option value="Shipped" <?=($o['status']==='Shipped')?'selected':''?>>Shipped</option>
              <option value="Delivered" <?=($o['status']==='Delivered')?'selected':''?>>Delivered</option>
              <option value="Cancelled" <?=($o['status']==='Cancelled')?'selected':''?>>Cancelled</option>
            </select>
            <button class="btn btn-glow" name="update_status">Update</button>
          </form>
        <?php endif; ?>
        <br><a href="<?php echo base_url('/invoice.php?id=' . $o['id']); ?>" style="color:var(--color-secondary);text-decoration:none">View Invoice</a>
      </td>
    </tr>
  <?php endforeach; ?>
  </table>
</div></body></html>
