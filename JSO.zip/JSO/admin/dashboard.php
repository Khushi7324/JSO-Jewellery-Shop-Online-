<?php
// Redirect legacy dashboard route to the new admin dashboard page.
// We keep this minimal and do not require authentication here so automated tools
// can reach the redirect; the destination `dashboard_new.php` enforces RBAC.
// Redirect to the new dashboard. Use an absolute path to avoid duplicated
// segments when invoked from different SCRIPT_NAME contexts.
// Redirect to the restored original dashboard UI using base_url()
// Include helpers first (no output) so base_url() is available.
require_once __DIR__ . '/../includes/functions.php';
# Use base_url with a path relative to the admin root to avoid duplication.
// Redirect to the admin dashboard; make path explicit to include the /admin segment
header('Location: ' . base_url('/admin/dashboard_new.php'));
http_response_code(302);
exit;
