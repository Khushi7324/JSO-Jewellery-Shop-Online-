<?php
$authFile = __DIR__.'/_auth.php';
require_once $authFile;
require_once __DIR__.'/../includes/functions.php';
$errors=[];
if(isset($_POST['add'])){
    $name = trim($_POST['name']);
    if($name){ $stmt = $mysqli->prepare("INSERT INTO categories(name) VALUES(?)"); $stmt->bind_param('s',$name); $stmt->execute(); }
}
if(isset($_GET['del'])){ $id = intval($_GET['del']); $stmt = $mysqli->prepare("DELETE FROM categories WHERE id=?"); $stmt->bind_param('i',$id); $stmt->execute(); }
$cats = $mysqli->query("SELECT * FROM categories")->fetch_all(MYSQLI_ASSOC);
?>
<!doctype html><html><head><meta charset="utf-8"><title>Categories</title><link rel="stylesheet" href="<?php echo base_url('/assets/css/design-system.css'); ?>"><link rel="stylesheet" href="<?php echo base_url('/assets/css/style.css'); ?>"><link rel="stylesheet" href="<?php echo base_url('/assets/css/background.css'); ?>"></head><body class="dark-elegant-bg">
<div class="container">
  <h2>Categories</h2>
  <nav><a href="<?php echo base_url('/admin/dashboard.php'); ?>">Dashboard</a> | <a href="<?php echo base_url('/admin/products.php'); ?>">Products</a> | <a href="<?php echo base_url('/admin/logout.php'); ?>">Logout</a></nav>
  <form method="post" style="margin-top:12px"><input name="name" placeholder="Category name"><button class="btn" name="add">Add</button></form>
  <ul>
    <?php foreach($cats as $c): ?><li><?=e($c['name'])?> <a href="?del=<?=$c['id']?>">Delete</a></li><?php endforeach; ?>
  </ul>
</div></body></html>