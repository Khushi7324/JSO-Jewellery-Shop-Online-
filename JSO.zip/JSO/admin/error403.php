<?php
// Local admin copy to ensure redirects from admin pages resolve correctly.
// This simply includes the root `error403.php` page so both `/error403.php`
// and `/admin/error403.php` are handled during checks.
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../error403.php';
