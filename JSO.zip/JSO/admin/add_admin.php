<?php
require_once __DIR__.'/_auth.php';
require_once __DIR__.'/../includes/functions.php';

$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm'] ?? '';

    if (!$name || !$email || !$phone || !$password || !$confirm) {
        $errors[] = 'All fields are required';
    } elseif ($password !== $confirm) {
        $errors[] = 'Passwords do not match';
    } elseif (strlen($password) < 6) {
        $errors[] = 'Password must be at least 6 characters';
    } else {
        // Check if email already exists
        $stmt = $mysqli->prepare("SELECT id FROM users WHERE email=?");
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            $errors[] = 'Email already exists';
        } else {
            // Insert admin
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $role = 'admin';
            $stmt = $mysqli->prepare("INSERT INTO users (name, email, phone, password, role) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param('sssss', $name, $email, $phone, $hash, $role);
            if ($stmt->execute()) {
                $success = "Admin user created: $email";
            } else {
                $errors[] = 'Failed to create admin. Try again.';
            }
        }
        $stmt->close();
    }
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Add Admin</title><link rel="stylesheet" href="<?php echo base_url('/assets/css/design-system.css'); ?>"><link rel="stylesheet" href="<?php echo base_url('/assets/css/style.css'); ?>"><link rel="stylesheet" href="<?php echo base_url('/assets/css/background.css'); ?>"></head><body class="dark-elegant-bg">
<div class="container">
  <h2 style="color:var(--color-secondary)">Add New Admin</h2>
    <nav style="margin-bottom:20px"><a href="<?php echo base_url('/admin/dashboard.php'); ?>" style="color:#fff;text-decoration:none">← Dashboard</a> | <a href="<?php echo base_url('/admin/logout.php'); ?>" style="color:#fff;text-decoration:none">Logout</a></nav>
  <?php if ($errors): ?>
    <div style="color:#ff8d8d; margin-bottom:12px"><?=implode('<br>', $errors)?></div>
  <?php endif; ?>
  <?php if ($success): ?>
    <div style="color:#4caf50; margin-bottom:12px"><?=htmlspecialchars($success)?></div>
  <?php endif; ?>
  <form method="post" style="display:flex;flex-direction:column;gap:12px;max-width:420px">
    <input class="gold-border" type="text" name="name" placeholder="Full Name" required value="<?=htmlspecialchars($_POST['name'] ?? '')?>">
    <input class="gold-border" type="email" name="email" placeholder="Email" required value="<?=htmlspecialchars($_POST['email'] ?? '')?>">
    <input class="gold-border" type="text" name="phone" placeholder="Phone" required value="<?=htmlspecialchars($_POST['phone'] ?? '')?>">
    <input class="gold-border" type="password" name="password" placeholder="Password (min 6)" required>
    <input class="gold-border" type="password" name="confirm" placeholder="Confirm Password" required>
    <button class="btn btn-glow" type="submit">Create Admin</button>
  </form>
</div>
</body></html>
