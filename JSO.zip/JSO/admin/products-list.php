<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';

// Strict role-based access control
require_admin();

$message = '';
$error = '';

// Ensure CSRF token for the admin session/page
ensure_csrf_token();

// Handle product deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_product'])) {
  if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
    $error = 'Invalid CSRF token. Action blocked.';
  } else {
    $product_id = (int)$_POST['product_id'];
    $stmt = $mysqli->prepare("DELETE FROM products WHERE id = ?");
    $stmt->bind_param('i', $product_id);
    if ($stmt->execute()) {
      $message = 'Product deleted successfully!';
    } else {
      $error = 'Error deleting product: ' . $stmt->error;
    }
    $stmt->close();
  }
}

// Handle bulk delete
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['bulk_delete'])) {
  if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
    $error = 'Invalid CSRF token. Action blocked.';
  } else {
    $ids = isset($_POST['selected_ids']) ? array_map('intval', $_POST['selected_ids']) : [];
    if (!empty($ids)) {
      $id_list = implode(',', $ids);
      $result = $mysqli->query("DELETE FROM products WHERE id IN ($id_list)");
      $message = count($ids) . ' product(s) deleted successfully!';
    }
  }
}

// Get filter parameters
$search = $_GET['search'] ?? '';
$category_filter = $_GET['category'] ?? '';
$page = max(1, (int)($_GET['page'] ?? 1));
$limit = 20;
$offset = ($page - 1) * $limit;

// Build query
$where = '1=1';
$params = [];
$types = '';

if ($search) {
  $search_term = '%' . $search . '%';
  $where .= ' AND (name LIKE ? OR description LIKE ?)';
  $params = [$search_term, $search_term];
  $types = 'ss';
}

if ($category_filter) {
  $category_filter = (int)$category_filter;
  $where .= ' AND category_id = ?';
  $params[] = $category_filter;
  $types .= 'i';
}

// Get total count
$count_query = "SELECT COUNT(*) as total FROM products WHERE $where";
$count_stmt = $mysqli->prepare($count_query);
if ($count_stmt && $params) {
  $count_stmt->bind_param($types, ...$params);
}
$count_stmt->execute();
$count_result = $count_stmt->get_result();
$total = $count_result->fetch_assoc()['total'];
$total_pages = ceil($total / $limit);

// Get products
$query = "SELECT p.*, c.name as category_name FROM products p 
          LEFT JOIN categories c ON p.category_id = c.id 
          WHERE $where 
          ORDER BY p.created_at DESC 
          LIMIT ? OFFSET ?";

$params[] = $limit;
$params[] = $offset;
$types .= 'ii';

$stmt = $mysqli->prepare($query);
if ($params) {
  $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$products = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Get all categories
$cats_result = $mysqli->query("SELECT * FROM categories ORDER BY name");
$categories = $cats_result->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Product Management - Admin</title>
  <link rel="stylesheet" href="<?php echo base_url('/assets/css/design-system.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('/assets/css/style.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('/assets/css/background.css'); ?>">
  <style>
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }
    
    body {
      font-family: var(--font-primary);
      background: var(--color-bg-secondary);
      padding: 20px;
    }
    
    .admin-header {
      background: var(--color-bg-primary);
      padding: 20px;
      border-radius: var(--radius-md);
      margin-bottom: 20px;
      box-shadow: var(--shadow-md);
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      gap: 15px;
    }
    
    .admin-header h1 {
      font-size: 24px;
      color: var(--color-text-primary);
      font-family: var(--font-secondary);
    }
    
    .admin-nav {
      display: flex;
      gap: 10px;
      align-items: center;
    }
    
    .btn-primary {
      background: linear-gradient(135deg, var(--color-primary) 0%, var(--color-primary-dark) 100%);
      color: var(--color-text-light);
      padding: 10px 20px;
      border: none;
      border-radius: var(--radius-md);
      cursor: pointer;
      font-weight: 600;
      text-decoration: none;
      transition: all var(--transition-base);
      font-size: 13px;
      display: inline-block;
      font-family: var(--font-primary);
    }
    
    .btn-primary:hover {
      transform: translateY(-2px);
      box-shadow: var(--shadow-lg);
    }
    
    .btn-logout {
      background: var(--color-error);
    }
    
    .btn-logout:hover {
      background: #dc2626;
    }
    
    .filters-section {
      background: var(--color-bg-primary);
      padding: 20px;
      border-radius: var(--radius-md);
      margin-bottom: 20px;
      box-shadow: var(--shadow-md);
      display: flex;
      gap: 15px;
      flex-wrap: wrap;
      align-items: flex-end;
    }
    
    .filter-group {
      display: flex;
      flex-direction: column;
      gap: 6px;
      flex: 1;
      min-width: 200px;
    }
    
    .filter-group label {
      font-weight: 600;
      color: var(--color-text-primary);
      font-size: 13px;
      font-family: var(--font-primary);
    }
    
    .filter-group input,
    .filter-group select {
      padding: 10px;
      border: 2px solid #e5e7eb;
      border-radius: var(--radius-md);
      font-size: 13px;
      transition: all var(--transition-base);
      font-family: var(--font-primary);
      background: var(--color-bg-primary);
      color: var(--color-text-primary);
    }
    
    .filter-group input:focus,
    .filter-group select:focus {
      outline: none;
      border-color: var(--color-primary);
      box-shadow: 0 0 0 3px rgba(26, 115, 232, 0.1);
    }
    
    .filter-btn {
      background: var(--color-primary);
      color: var(--color-text-light);
      padding: 10px 20px;
      border: none;
      border-radius: var(--radius-md);
      cursor: pointer;
      font-weight: 600;
      transition: all var(--transition-base);
      font-family: var(--font-primary);
    }
    
    .filter-btn:hover {
      background: var(--color-primary-dark);
      transform: translateY(-2px);
      box-shadow: var(--shadow-md);
    }
    
    .message {
      background: #d4edda;
      border: 1px solid #c3e6cb;
      color: #155724;
      padding: 12px;
      border-radius: 6px;
      margin-bottom: 20px;
    }
    
    .error {
      background: #f8d7da;
      border: 1px solid #f5c6cb;
      color: #721c24;
      padding: 12px;
      border-radius: 6px;
      margin-bottom: 20px;
    }
    
    .products-table {
      background: var(--color-bg-primary);
      border-radius: var(--radius-md);
      overflow: hidden;
      box-shadow: var(--shadow-md);
    }
    
    .table-wrapper {
      overflow-x: auto;
    }
    
    table {
      width: 100%;
      border-collapse: collapse;
      font-size: 13px;
    }
    
    thead {
      background: var(--color-bg-tertiary);
      border-bottom: 2px solid #e5e7eb;
    }
    
    th {
      padding: 15px;
      text-align: left;
      font-weight: 700;
      color: var(--color-text-primary);
      font-family: var(--font-primary);
    }
    
    td {
      padding: 15px;
      border-bottom: 1px solid #e5e7eb;
      color: var(--color-text-secondary);
      font-family: var(--font-primary);
    }
    
    tbody tr:hover {
      background: var(--color-bg-secondary);
    }
    
    .checkbox {
      width: 18px;
      height: 18px;
      cursor: pointer;
    }
    
    .product-image {
      width: 40px;
      height: 40px;
      border-radius: 4px;
      object-fit: cover;
      background: #f0f0f0;
    }
    
    .action-buttons {
      display: flex;
      gap: 8px;
      flex-wrap: wrap;
    }
    
    .btn-edit, .btn-delete {
      padding: 6px 12px;
      border: none;
      border-radius: var(--radius-sm);
      cursor: pointer;
      font-size: 12px;
      font-weight: 600;
      transition: all var(--transition-base);
      text-decoration: none;
      font-family: var(--font-primary);
    }
    
    .btn-edit {
      background: var(--color-primary);
      color: var(--color-text-light);
    }
    
    .btn-edit:hover {
      background: var(--color-primary-dark);
      transform: translateY(-2px);
      box-shadow: var(--shadow-sm);
    }
    
    .btn-delete {
      background: var(--color-error);
      color: var(--color-text-light);
    }
    
    .btn-delete:hover {
      background: #dc2626;
      transform: translateY(-2px);
      box-shadow: var(--shadow-sm);
    }
    
    .pagination {
      display: flex;
      gap: 8px;
      justify-content: center;
      margin-top: 20px;
      padding: 20px;
      background: var(--color-bg-primary);
      border-radius: var(--radius-md);
      flex-wrap: wrap;
    }
    
    .pagination a, .pagination span {
      padding: 8px 12px;
      border: 1px solid #e5e7eb;
      border-radius: var(--radius-sm);
      cursor: pointer;
      text-decoration: none;
      color: var(--color-primary);
      transition: all var(--transition-base);
      font-family: var(--font-primary);
    }
    
    .pagination a:hover {
      background: var(--color-primary);
      color: var(--color-text-light);
      transform: translateY(-2px);
      box-shadow: var(--shadow-sm);
    }
    
    .pagination .active {
      background: var(--color-primary);
      color: var(--color-text-light);
      border-color: var(--color-primary);
    }
    
    .empty-state {
      text-align: center;
      padding: 60px 20px;
      color: #666;
    }
    
    .empty-state h3 {
      margin-bottom: 10px;
    }
    
    .bulk-actions {
      padding: 15px;
      background: var(--color-bg-tertiary);
      border-bottom: 1px solid #e5e7eb;
      display: flex;
      gap: 10px;
      align-items: center;
      flex-wrap: wrap;
    }
    
    .bulk-actions button {
      padding: 8px 16px;
      background: var(--color-error);
      color: var(--color-text-light);
      border: none;
      border-radius: var(--radius-sm);
      cursor: pointer;
      font-weight: 600;
      transition: all var(--transition-base);
      font-size: 12px;
      font-family: var(--font-primary);
    }
    
    .bulk-actions button:hover {
      background: #dc2626;
      transform: translateY(-2px);
      box-shadow: var(--shadow-sm);
    }
  </style>
</head>
<body>
  <div class="admin-header">
    <div>
      <h1>📦 Product Management</h1>
    </div>
    <div class="admin-nav">
      <a href="<?php echo base_url('/admin/add-product.php'); ?>" class="btn-primary">+ Add Product</a>
      <a href="<?php echo base_url('/admin/change_password.php'); ?>" class="btn-primary">Change Password</a>
      <a href="<?php echo base_url('/admin/logout.php'); ?>" class="btn-primary btn-logout">Logout</a>
    </div>
  </div>
  
  <?php if ($message): ?>
    <div class="message"><?= e($message) ?></div>
  <?php endif; ?>
  
  <?php if ($error): ?>
    <div class="error"><?= e($error) ?></div>
  <?php endif; ?>
  
  <div class="filters-section">
    <form method="GET" style="display: flex; gap: 15px; flex-wrap: wrap; width: 100%; align-items: flex-end;">
      <div class="filter-group" style="flex: 2; min-width: 250px;">
        <label>Search Products</label>
        <input type="text" name="search" placeholder="Product name or description..." value="<?= e($search) ?>">
      </div>
      
      <div class="filter-group">
        <label>Category</label>
        <select name="category">
          <option value="">All Categories</option>
          <?php foreach($categories as $cat): ?>
            <option value="<?= $cat['id'] ?>" <?= ($category_filter == $cat['id']) ? 'selected' : '' ?>>
              <?= e($cat['name']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>
      
      <button type="submit" class="filter-btn">🔍 Filter</button>
      <a href="<?php echo base_url('/admin/products-list.php'); ?>" class="filter-btn" style="background: #6c757d; text-decoration: none;">Reset</a>
    </form>
  </div>
  
  <div class="products-table">
    <?php if (!empty($products)): ?>
      <form method="POST">
        <?= csrf_input() ?>
        <div class="bulk-actions">
          <input type="checkbox" id="selectAll" class="checkbox" onchange="toggleSelectAll(this)">
          <span style="color: #666; font-size: 12px;">Select All</span>
          <button type="submit" name="bulk_delete" onclick="return confirm('Delete selected products?')">
            🗑️ Delete Selected
          </button>
          <span style="margin-left: auto; color: #999; font-size: 12px;">
            Total: <strong><?= $total ?></strong> | Page <?= $page ?> of <?= $total_pages ?>
          </span>
        </div>
        
        <div class="table-wrapper">
          <table>
            <thead>
              <tr>
                <th style="width: 30px;">
                  <input type="checkbox" id="headerCheckbox" class="checkbox" onchange="toggleSelectAll(this)">
                </th>
                <th style="width: 50px;">Image</th>
                <th>Name</th>
                <th>Category</th>
                <th style="text-align: right;">Price</th>
                <th style="text-align: center;">Stock</th>
                <th style="width: 140px;">Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach($products as $product): ?>
                <tr>
                  <td>
                    <input type="checkbox" name="selected_ids[]" value="<?= $product['id'] ?>" class="checkbox">
                  </td>
                  <td>
                    <?php if ($product['image']): ?>
                      <img src="<?php echo base_url('/' . ltrim($product['image'], '/')); ?>" alt="<?= e($product['name']) ?>" class="product-image">
                    <?php else: ?>
                      <div class="product-image" style="background: #e0e0e0;"></div>
                    <?php endif; ?>
                  </td>
                  <td>
                    <strong><?= e(substr($product['name'], 0, 40)) ?></strong><br>
                    <span style="color: #999; font-size: 11px;">ID: <?= $product['id'] ?></span>
                  </td>
                  <td><?= e($product['category_name'] ?? 'Uncategorized') ?></td>
                  <td style="text-align: right;">
                    <input type="number" step="0.01" min="0" class="inline-edit price-input" data-id="<?= $product['id'] ?>" value="<?= htmlspecialchars($product['price'], ENT_QUOTES) ?>" style="width:110px;padding:6px;border-radius:4px;border:1px solid #ddd;text-align:right;">
                    <span class="inline-status" id="status-price-<?= $product['id'] ?>" style="margin-left:8px;font-size:12px;color:#666;display:none"></span>
                  </td>
                  <td style="text-align: center;">
                    <input type="number" step="1" min="0" class="inline-edit stock-input" data-id="<?= $product['id'] ?>" value="<?= intval($product['stock']) ?>" style="width:80px;padding:6px;border-radius:4px;border:1px solid #ddd;text-align:center;">
                    <span class="inline-status" id="status-stock-<?= $product['id'] ?>" style="margin-left:6px;font-size:12px;color:#666;display:none"></span>
                  </td>
                  <td>
                    <div class="action-buttons">
                      <a href="<?php echo base_url('/admin/edit-product.php?id=' . $product['id']); ?>" class="btn-edit">✏️ Edit</a>
                      <form method="POST" style="display: inline;">
                        <?= csrf_input() ?>
                        <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                        <button type="submit" name="delete_product" class="btn-delete" onclick="return confirm('Delete this product?')">🗑️ Delete</button>
                      </form>
                    </div>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </form>
      
      <?php if ($total_pages > 1): ?>
        <div class="pagination">
          <?php if ($page > 1): ?>
            <a href="?search=<?= urlencode($search) ?>&category=<?= $category_filter ?>&page=1">« First</a>
            <a href="?search=<?= urlencode($search) ?>&category=<?= $category_filter ?>&page=<?= $page - 1 ?>">‹ Previous</a>
          <?php endif; ?>
          
          <?php for ($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
            <?php if ($i === $page): ?>
              <span class="active"><?= $i ?></span>
            <?php else: ?>
              <a href="?search=<?= urlencode($search) ?>&category=<?= $category_filter ?>&page=<?= $i ?>"><?= $i ?></a>
            <?php endif; ?>
          <?php endfor; ?>
          
          <?php if ($page < $total_pages): ?>
            <a href="?search=<?= urlencode($search) ?>&category=<?= $category_filter ?>&page=<?= $page + 1 ?>">Next ›</a>
            <a href="?search=<?= urlencode($search) ?>&category=<?= $category_filter ?>&page=<?= $total_pages ?>">Last »</a>
          <?php endif; ?>
        </div>
      <?php endif; ?>
    <?php else: ?>
      <div class="empty-state">
        <h3>📭 No products found</h3>
        <p>Try adjusting your filters or <a href="<?php echo base_url('/admin/add-product.php'); ?>" style="color: #667eea; cursor: pointer;">add a new product</a></p>
      </div>
    <?php endif; ?>
  </div>
  
  <script>
    const CSRF_TOKEN = '<?= e($_SESSION['csrf_token']) ?>';
    function toggleSelectAll(checkbox) {
      const checkboxes = document.querySelectorAll('input[name="selected_ids[]"]');
      checkboxes.forEach(cb => cb.checked = checkbox.checked);
    }
    
    // Inline edit handlers for price and stock
    (function(){
      const debounce = (fn, delay=600) => {
        let t;
        return function(...args){ clearTimeout(t); t = setTimeout(()=>fn.apply(this,args), delay); };
      };

      async function sendUpdate(id, payload, statusEl) {
        try {
          statusEl.style.display = 'inline';
          statusEl.textContent = 'Saving...';
          const form = new FormData();
          form.append('id', id);
          Object.keys(payload).forEach(k=>form.append(k, payload[k]));

          form.append('csrf_token', CSRF_TOKEN);
          const resp = await fetch('<?php echo base_url('/admin/update-product-ajax.php'); ?>', { method: 'POST', body: form });
          const json = await resp.json();
          if(json.success) {
            statusEl.textContent = 'Saved';
            setTimeout(()=>{ statusEl.style.display='none'; }, 1200);
          } else {
            statusEl.textContent = 'Error';
            console.error('Update error', json.message);
            setTimeout(()=>{ statusEl.style.display='none'; }, 2000);
          }
        } catch (err) {
          statusEl.textContent = 'Error';
          console.error(err);
          setTimeout(()=>{ statusEl.style.display='none'; }, 2000);
        }
      }

      const priceInputs = document.querySelectorAll('.price-input');
      priceInputs.forEach(inp => {
        const id = inp.dataset.id;
        const statusEl = document.getElementById('status-price-'+id);
        const handler = debounce(()=>{
          const val = inp.value;
          sendUpdate(id, { price: val }, statusEl);
        }, 700);
        inp.addEventListener('change', handler);
        inp.addEventListener('blur', handler);
        inp.addEventListener('keydown', (e)=>{ if(e.key === 'Enter') { e.preventDefault(); handler(); inp.blur(); } });
      });

      const stockInputs = document.querySelectorAll('.stock-input');
      stockInputs.forEach(inp => {
        const id = inp.dataset.id;
        const statusEl = document.getElementById('status-stock-'+id);
        const handler = debounce(()=>{
          const val = inp.value;
          sendUpdate(id, { stock: val }, statusEl);
        }, 500);
        inp.addEventListener('change', handler);
        inp.addEventListener('blur', handler);
        inp.addEventListener('keydown', (e)=>{ if(e.key === 'Enter') { e.preventDefault(); handler(); inp.blur(); } });
      });
    })();
  </script>
</body>
</html>
