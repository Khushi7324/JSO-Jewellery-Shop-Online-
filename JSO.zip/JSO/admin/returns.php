<?php
require_once __DIR__ . '/_auth.php';

$message = '';
$error = '';

// Handle status updates
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['return_id'], $_POST['action'])) {
    $rid = intval($_POST['return_id']);
    $action = $_POST['action'];
    $newStatus = null;
    if ($action === 'approve') $newStatus = 'approved';
    if ($action === 'reject') $newStatus = 'rejected';
    if ($action === 'receive') $newStatus = 'received';
    if ($action === 'refund') $newStatus = 'refunded';

    if ($newStatus) {
        $stmt = $mysqli->prepare("UPDATE returns SET status=? WHERE id=?");
        $stmt->bind_param('si', $newStatus, $rid);
        if ($stmt->execute()) {
            $message = "Return #{$rid} updated to {$newStatus}.";
        } else {
            $error = "Failed to update return #{$rid}.";
        }
        $stmt->close();
    }
}

// Fetch returns with related info
$filter = $_GET['filter'] ?? 'pending';
$allowed = ['pending','approved','rejected','received','refunded','all'];
if (!in_array($filter, $allowed, true)) $filter = 'pending';

$where = '';
if ($filter !== 'all') {
    $where = "WHERE r.status = '" . $mysqli->real_escape_string($filter) . "'";
}

$query = "
    SELECT r.*, u.name as user_name, u.email, o.total
    FROM returns r
    JOIN users u ON u.id = r.user_id
    JOIN orders o ON o.id = r.order_id
    $where
    ORDER BY r.created_at DESC
";
$returns = $mysqli->query($query)->fetch_all(MYSQLI_ASSOC);

$body_class = 'diamond-shine-bg';
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Admin - Returns</title>
  <link rel="stylesheet" href="<?php echo base_url('/assets/css/design-system.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('/assets/css/style.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('/assets/css/background.css'); ?>">
  <style>
    body { background: var(--color-bg-secondary); font-family: var(--font-primary); }
    .page { max-width: 1100px; margin: 30px auto; padding: 0 15px; }
    .card { background: var(--color-bg-primary); border-radius: var(--radius-lg); box-shadow: var(--shadow-md); padding: 20px; }
    .title { font-size: 22px; font-weight: 700; margin-bottom: 10px; font-family: var(--font-secondary); color: var(--color-text-primary); }
    .sub { color: var(--color-text-secondary); margin-bottom: 20px; }
    table { width: 100%; border-collapse: collapse; }
    th, td { padding: 12px; border-bottom: 1px solid #e5e7eb; text-align: left; font-family: var(--font-primary); }
    th { background: var(--color-bg-tertiary); font-size: 13px; text-transform: uppercase; letter-spacing: .3px; color: var(--color-text-primary); font-weight: 600; }
    td { color: var(--color-text-secondary); }
    .badge { padding: 6px 10px; border-radius: 12px; font-size: 12px; font-weight: 700; display: inline-block; }
    .b-pending { background: #fff3cd; color: #856404; }
    .b-approved { background: #d1ecf1; color: #0c5460; }
    .b-rejected { background: #f8d7da; color: #721c24; }
    .b-received { background: #e2f0d9; color: #2e7d32; }
    .b-refunded { background: #d4edda; color: #155724; }
    .actions button { margin-right: 6px; margin-bottom: 6px; }
    .btn { padding: 8px 12px; border: none; border-radius: 6px; cursor: pointer; font-weight: 600; }
    .btn-approve { background: var(--color-primary); color: var(--color-text-light); }
    .btn-approve:hover { background: var(--color-primary-dark); transform: translateY(-2px); box-shadow: var(--shadow-md); }
    .btn-reject { background: var(--color-error); color: var(--color-text-light); }
    .btn-reject:hover { background: #dc2626; transform: translateY(-2px); box-shadow: var(--shadow-md); }
    .btn-receive { background: var(--color-success); color: var(--color-text-light); }
    .btn-receive:hover { background: #059669; transform: translateY(-2px); box-shadow: var(--shadow-md); }
    .btn-refund { background: var(--color-accent); color: var(--color-text-light); }
    .btn-refund:hover { background: var(--color-accent-light); transform: translateY(-2px); box-shadow: var(--shadow-md); }
    .msg { padding: 10px 12px; border-radius: 6px; margin-bottom: 15px; }
    .msg-ok { background: #e8f5e9; color: #2e7d32; }
    .msg-err { background: #ffebee; color: #c62828; }
    .filters a { margin-right: 10px; font-weight: 600; color: var(--color-primary); text-decoration: none; font-family: var(--font-primary); }
    .filters a:hover { color: var(--color-primary-dark); }
    .filters .active { text-decoration: underline; color: var(--color-primary-dark); }
    .small { color: var(--color-text-tertiary); font-size: 12px; }
  </style>
</head>
<body>
  <div class="page">
    <div class="card">
      <div class="title">↩️ Returns</div>
      <div class="sub">Manage return requests submitted by customers.</div>

      <div class="filters">
        <?php foreach($allowed as $f): ?>
          <a class="<?php echo $f===$filter?'active':''; ?>" href="?filter=<?php echo $f; ?>"><?php echo ucfirst($f); ?></a>
        <?php endforeach; ?>
      </div>

      <?php if($message): ?><div class="msg msg-ok"><?php echo e($message); ?></div><?php endif; ?>
      <?php if($error): ?><div class="msg msg-err"><?php echo e($error); ?></div><?php endif; ?>

      <div class="table-responsive">
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Order</th>
              <th>User</th>
              <th>Reason</th>
              <th>Total</th>
              <th>Status</th>
              <th>Submitted</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php if(empty($returns)): ?>
              <tr><td colspan="8" style="text-align:center;color:#777;padding:20px;">No returns found.</td></tr>
            <?php else: ?>
              <?php foreach($returns as $r): ?>
                <tr>
                  <td>#<?php echo $r['id']; ?></td>
                  <td>#<?php echo $r['order_id']; ?></td>
                  <td><?php echo e($r['user_name']); ?><br><span class="small"><?php echo e($r['email']); ?></span></td>
                  <td><?php echo e($r['reason']); ?></td>
                  <td>₹<?php echo number_format($r['return_total'], 2); ?></td>
                  <td>
                    <span class="badge b-<?php echo $r['status']; ?>">
                      <?php echo ucfirst($r['status']); ?>
                    </span>
                  </td>
                  <td><?php echo date('M d, Y h:i A', strtotime($r['created_at'])); ?></td>
                  <td class="actions">
                    <form method="post" style="display:inline">
                      <input type="hidden" name="return_id" value="<?php echo $r['id']; ?>">
                      <?php if($r['status']==='pending'): ?>
                        <button class="btn btn-approve" name="action" value="approve">Approve</button>
                        <button class="btn btn-reject" name="action" value="reject">Reject</button>
                      <?php endif; ?>
                      <?php if(in_array($r['status'], ['approved','pending'])): ?>
                        <button class="btn btn-receive" name="action" value="receive">Mark Received</button>
                      <?php endif; ?>
                      <?php if(in_array($r['status'], ['received','approved'])): ?>
                        <button class="btn btn-refund" name="action" value="refund">Mark Refunded</button>
                      <?php endif; ?>
                    </form>
                    <div class="small"><a href="<?php echo base_url('/track_order.php?id=' . $r['order_id']); ?>">View order</a></div>
                  </td>
                </tr>
              <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</body>
</html>

