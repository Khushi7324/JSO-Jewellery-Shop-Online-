<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';

// Strict role-based access control
require_admin();

$product_id = (int)($_GET['id'] ?? 0);
$product = null;
$message = '';
$error = '';

// Get product if editing
if ($product_id) {
  $stmt = $mysqli->prepare("SELECT * FROM products WHERE id = ?");
  $stmt->bind_param('i', $product_id);
  $stmt->execute();
  $result = $stmt->get_result();
  $product = $result->fetch_assoc();
  $stmt->close();
  // Load existing angle images
  $angles_map = ['front','side','back','top','detail'];
  $angle_images = [];
  $stmtA = $mysqli->prepare("SELECT angle, image_url FROM product_images WHERE product_id=?");
  $stmtA->bind_param('i', $product_id);
  $stmtA->execute();
  $resA = $stmtA->get_result();
  while ($rowA = $resA->fetch_assoc()) { $angle_images[$rowA['angle']] = $rowA['image_url']; }
  $stmtA->close();
  
  if (!$product) {
    header('Location: ' . base_url('/admin/products-list.php'));
    exit;
  }
}

// Get all categories
$cats_result = $mysqli->query("SELECT * FROM categories ORDER BY name");
$categories = $cats_result->fetch_all(MYSQLI_ASSOC);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
    $error = 'Invalid CSRF token. Please reload the page and try again.';
  } else {
  $name = trim($_POST['name'] ?? '');
  $description = trim($_POST['description'] ?? '');
  $price = (float)($_POST['price'] ?? 0);
  $weight = (float)($_POST['weight'] ?? 0);
  $category_id = (int)($_POST['category_id'] ?? 0);
  $stock = (int)($_POST['stock'] ?? 0);
  $image = $_POST['image'] ?? ($product['image'] ?? '');
  $angles = [
    'front' => 'image_front',
    'side' => 'image_side',
    'back' => 'image_back',
    'top' => 'image_top',
    'detail' => 'image_detail'
  ];
  $uploaded_angles = [];
  
  // Validate
  if (!$name || $price <= 0 || $category_id <= 0) {
    $error = 'Please fill in all required fields (Name, Price, Category)';
  } else {
    // Handle image upload
    if (isset($_FILES['image']) && $_FILES['image']['tmp_name']) {
      $upload_dir = __DIR__ . '/../uploads/';
      if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);
      
      $filename = time() . '_' . basename($_FILES['image']['name']);
      $filepath = $upload_dir . $filename;
      // basic validation
      $allowed = ['image/jpeg','image/png','image/webp','image/gif'];
      $mime = mime_content_type($_FILES['image']['tmp_name']);
      if (in_array($mime, $allowed) && $_FILES['image']['size'] <= 5*1024*1024 && move_uploaded_file($_FILES['image']['tmp_name'], $filepath)) {
        $image = 'uploads/' . $filename;
      }
    }
    // Handle multi-angle uploads
    $upload_dir = __DIR__ . '/../uploads/';
    if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);
    foreach ($angles as $angle => $field) {
      if (isset($_FILES[$field]) && $_FILES[$field]['tmp_name']) {
        $filename = time() . '_' . $angle . '_' . basename($_FILES[$field]['name']);
        $filepath = $upload_dir . $filename;
        $allowed = ['image/jpeg','image/png','image/webp','image/gif'];
        $mime = mime_content_type($_FILES[$field]['tmp_name']);
        if (!in_array($mime, $allowed)) { continue; }
        if ($_FILES[$field]['size'] > 5*1024*1024) { continue; }
        if (move_uploaded_file($_FILES[$field]['tmp_name'], $filepath)) {
          $uploaded_angles[$angle] = 'uploads/' . $filename;
        }
      }
    }
    
    // Update existing product
    $stmt = $mysqli->prepare("UPDATE products SET name=?, description=?, price=?, weight=?, category_id=?, stock=?, image=? WHERE id=?");
    $stmt->bind_param('ssddissi', $name, $description, $price, $weight, $category_id, $stock, $image, $product_id);
    
    if ($stmt->execute()) {
      if (!empty($uploaded_angles)) {
        $stmtImg = $mysqli->prepare("INSERT INTO product_images (product_id, angle, image_url) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE image_url=VALUES(image_url)");
        foreach ($uploaded_angles as $angle => $url) {
          $a = $angle; $u = $url;
          $stmtImg->bind_param('iss', $product_id, $a, $u);
          $stmtImg->execute();
        }
        $stmtImg->close();
      }
      $message = 'Product updated successfully!';
      // Refresh product data
      $stmt2 = $mysqli->prepare("SELECT * FROM products WHERE id = ?");
      $stmt2->bind_param('i', $product_id);
      $stmt2->execute();
      $product = $stmt2->get_result()->fetch_assoc();
      $stmt2->close();
      // Refresh angle images
      $stmtA = $mysqli->prepare("SELECT angle, image_url FROM product_images WHERE product_id=?");
      $stmtA->bind_param('i', $product_id);
      $stmtA->execute();
      $resA = $stmtA->get_result();
      $angle_images = [];
      while ($rowA = $resA->fetch_assoc()) { $angle_images[$rowA['angle']] = $rowA['image_url']; }
      $stmtA->close();
    } else {
      $error = 'Error saving product: ' . $stmt->error;
    }
    $stmt->close();
  }
  }
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Edit Product - Admin</title>
  <link rel="stylesheet" href="<?php echo base_url('/assets/css/design-system.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('/assets/css/style.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('/assets/css/background.css'); ?>">
  <style>
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }
    
    body {
      font-family: var(--font-primary);
      background: var(--color-bg-secondary);
      padding: 20px;
    }
    
    .form-container {
      background: var(--color-bg-primary);
      border-radius: var(--radius-md);
      box-shadow: var(--shadow-md);
      max-width: 800px;
      margin: 0 auto;
      padding: 30px;
    }
    
    .form-header {
      margin-bottom: 30px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      gap: 15px;
    }
    
    .form-header h1 {
      font-size: 28px;
      color: var(--color-text-primary);
      font-family: var(--font-secondary);
    }
    
    .form-group {
      margin-bottom: 24px;
    }
    
    .form-group label {
      display: block;
      margin-bottom: 8px;
      font-weight: 600;
      color: var(--color-text-primary);
      font-size: 14px;
      font-family: var(--font-primary);
    }
    
    .form-group small {
      display: block;
      color: var(--color-text-muted);
      font-size: 12px;
      margin-top: 4px;
    }
    
    .form-group input,
    .form-group textarea,
    .form-group select {
      width: 100%;
      padding: 12px;
      border: 2px solid #e5e7eb;
      border-radius: var(--radius-md);
      font-size: 14px;
      font-family: var(--font-primary);
      transition: all var(--transition-base);
      background: var(--color-bg-primary);
      color: var(--color-text-primary);
    }
    
    .form-group input:focus,
    .form-group textarea:focus,
    .form-group select:focus {
      outline: none;
      border-color: var(--color-primary);
      box-shadow: 0 0 0 3px rgba(26, 115, 232, 0.1);
    }
    
    .form-group textarea {
      resize: vertical;
      min-height: 100px;
    }
    
    .form-row {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 20px;
      margin-bottom: 24px;
    }
    
    @media (max-width: 600px) {
      .form-row {
        grid-template-columns: 1fr;
      }
    }
    
    .image-preview {
      margin-top: 12px;
      display: flex;
      align-items: center;
      gap: 15px;
    }
    
    .image-preview img {
      width: 120px;
      height: 120px;
      border-radius: 8px;
      object-fit: cover;
      border: 1px solid #ddd;
    }
    
    .file-input-wrapper {
      position: relative;
      overflow: hidden;
      display: inline-block;
    }
    
    .file-input-wrapper input[type="file"] {
      position: absolute;
      left: -9999px;
    }
    
    .file-label {
      display: inline-block;
      padding: 10px 16px;
      background: var(--color-primary);
      color: var(--color-text-light);
      border-radius: var(--radius-md);
      cursor: pointer;
      font-weight: 600;
      font-size: 13px;
      transition: all var(--transition-base);
      font-family: var(--font-primary);
    }
    
    .file-label:hover {
      background: var(--color-primary-dark);
      transform: translateY(-2px);
      box-shadow: var(--shadow-md);
    }
    
    .form-actions {
      display: flex;
      gap: 10px;
      margin-top: 30px;
      flex-wrap: wrap;
    }
    
    .btn {
      padding: 12px 24px;
      border: none;
      border-radius: var(--radius-md);
      cursor: pointer;
      font-weight: 600;
      font-size: 14px;
      transition: all var(--transition-base);
      text-decoration: none;
      display: inline-block;
      font-family: var(--font-primary);
    }
    
    .btn-save {
      background: linear-gradient(135deg, var(--color-primary) 0%, var(--color-primary-dark) 100%);
      color: var(--color-text-light);
    }
    
    .btn-save:hover {
      transform: translateY(-2px);
      box-shadow: var(--shadow-lg);
    }
    
    .btn-cancel {
      background: var(--color-text-tertiary);
      color: var(--color-text-light);
    }
    
    .btn-cancel:hover {
      background: var(--color-text-secondary);
      transform: translateY(-2px);
      box-shadow: var(--shadow-md);
    }
    
    .message {
      background: #d4edda;
      border: 1px solid #c3e6cb;
      color: #155724;
      padding: 12px;
      border-radius: var(--radius-md);
      margin-bottom: 20px;
    }
    
    .error {
      background: #f8d7da;
      border: 1px solid #f5c6cb;
      color: #721c24;
      padding: 12px;
      border-radius: var(--radius-md);
      margin-bottom: 20px;
    }
    
    .required {
      color: var(--color-error);
      font-weight: 700;
    }
  </style>
</head>
<body>
  <div class="form-container">
    <div class="form-header">
      <h1>✏️ Edit Product</h1>
      <a href="<?php echo base_url('/admin/products-list.php'); ?>" class="btn btn-cancel">← Back</a>
    </div>
    
    <?php if ($message): ?>
      <div class="message"><?= e($message) ?></div>
    <?php endif; ?>
    
    <?php if ($error): ?>
      <div class="error"><?= e($error) ?></div>
    <?php endif; ?>
    
    <form method="POST" enctype="multipart/form-data">
      <?= csrf_input() ?>
      <div class="form-group">
        <label>Product Name <span class="required">*</span></label>
        <input type="text" name="name" value="<?= e($product['name'] ?? '') ?>" required autofocus>
        <small>Enter a clear and descriptive product name</small>
      </div>
      
      <div class="form-group">
        <label>Description</label>
        <textarea name="description"><?= e($product['description'] ?? '') ?></textarea>
        <small>Provide details about the product</small>
      </div>
      
      <div class="form-row">
        <div class="form-group">
          <label>Category <span class="required">*</span></label>
          <select name="category_id" required>
            <option value="">-- Select Category --</option>
            <?php foreach($categories as $cat): ?>
              <option value="<?= $cat['id'] ?>" <?= (isset($product['category_id']) && $product['category_id'] == $cat['id']) ? 'selected' : '' ?>>
                <?= e($cat['name']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        
        <div class="form-group">
          <label>Price (₹) <span class="required">*</span></label>
          <input type="number" name="price" step="0.01" value="<?= $product['price'] ?? '' ?>" required>
          <small>Enter the selling price in rupees</small>
        </div>
      </div>
      
      <div class="form-row">
        <div class="form-group">
          <label>Weight (grams)</label>
          <input type="number" name="weight" step="0.001" value="<?= $product['weight'] ?? '' ?>">
        </div>
        
        <div class="form-group">
          <label>Stock Quantity</label>
          <input type="number" name="stock" value="<?= $product['stock'] ?? 0 ?>">
          <small>Number of items available</small>
        </div>
      </div>
      
      <div class="form-group">
        <label>Product Image</label>
        <div class="file-input-wrapper">
          <input type="file" id="image_input" name="image" accept="image/*">
          <label for="image_input" class="file-label">📷 Choose Image</label>
        </div>
        
        <?php if ($product && $product['image']): ?>
          <div class="image-preview">
            <img src="<?php echo resolve_asset_url($product['image']); ?>" alt="Product Image">
            <div>
              <p style="font-size: 12px; color: #666;">Current Image</p>
              <p style="font-size: 12px; color: #999;"><?= e($product['image']) ?></p>
            </div>
          </div>
        <?php endif; ?>
      </div>
      
      <div class="form-group">
        <label>Additional Photos</label>
        <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:12px">
          <div>
            <small>Front</small>
            <?php if (!empty($angle_images['front'])): ?>
              <div class="image-preview"><img src="<?php echo resolve_asset_url($angle_images['front']); ?>" alt="Front"></div>
            <?php endif; ?>
            <input type="file" name="image_front" accept="image/*">
          </div>
          <div>
            <small>Side</small>
            <?php if (!empty($angle_images['side'])): ?>
              <div class="image-preview"><img src="<?php echo resolve_asset_url($angle_images['side']); ?>" alt="Side"></div>
            <?php endif; ?>
            <input type="file" name="image_side" accept="image/*">
          </div>
          <div>
            <small>Back</small>
            <?php if (!empty($angle_images['back'])): ?>
              <div class="image-preview"><img src="<?php echo resolve_asset_url($angle_images['back']); ?>" alt="Back"></div>
            <?php endif; ?>
            <input type="file" name="image_back" accept="image/*">
          </div>
          <div>
            <small>Top</small>
            <?php if (!empty($angle_images['top'])): ?>
              <div class="image-preview"><img src="<?php echo resolve_asset_url($angle_images['top']); ?>" alt="Top"></div>
            <?php endif; ?>
            <input type="file" name="image_top" accept="image/*">
          </div>
          <div>
            <small>Detail</small>
            <?php if (!empty($angle_images['detail'])): ?>
              <div class="image-preview"><img src="<?php echo resolve_asset_url($angle_images['detail']); ?>" alt="Detail"></div>
            <?php endif; ?>
            <input type="file" name="image_detail" accept="image/*">
          </div>
        </div>
        <small>Upload to replace existing angle photos.</small>
      </div>
      
      <div class="form-actions">
        <button type="submit" class="btn btn-save">💾 Update Product</button>
        <a href="<?php echo base_url('/admin/products-list.php'); ?>" class="btn btn-cancel">Cancel</a>
      </div>
    </form>
  </div>
</body>
</html>
