<?php
$authFile = __DIR__.'/_auth.php';
require_once $authFile;
require_once __DIR__.'/../includes/functions.php';

// CSRF
ensure_csrf_token();

$message = '';
$error = '';
$edit_coupon = null;

// POST handlers: add / update / toggle / delete
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $act = $_POST['action'];
    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid CSRF token. Please reload and try again.';
    } else if ($act === 'add') {
        $code = strtoupper(trim($_POST['code'] ?? ''));
        $discount_type = ($_POST['discount_type'] === 'percentage') ? 'percentage' : 'fixed';
        $discount_value = (float)($_POST['discount_value'] ?? 0);
        $min_purchase = (float)($_POST['min_purchase'] ?? 0);
        $max_uses = intval($_POST['max_uses'] ?? -1);
        $is_active = isset($_POST['is_active']) ? 1 : 0;

        $vf = $_POST['valid_from'] ?? '';
        $vt = $_POST['valid_till'] ?? '';
        $valid_from = $vf ? date('Y-m-d H:i:s', strtotime(str_replace('T',' ',$vf))) : date('Y-m-d H:i:s');
        $valid_till = $vt ? date('Y-m-d H:i:s', strtotime(str_replace('T',' ',$vt))) : date('Y-m-d H:i:s');

        if (!$code || $discount_value <= 0) {
            $error = 'Please provide coupon code and a valid discount value.';
        } else {
            $stmt = $mysqli->prepare("INSERT INTO coupons (code, discount_type, discount_value, min_purchase, max_uses, used_count, is_active, valid_from, valid_till, created_at) VALUES (?, ?, ?, ?, ?, 0, ?, ?, ?, NOW())");
            if (!$stmt) {
                $error = 'Database error: ' . $mysqli->error;
            } else {
                $stmt->bind_param('ssddisss', $code, $discount_type, $discount_value, $min_purchase, $max_uses, $is_active, $valid_from, $valid_till);
                if ($stmt->execute()) {
                    $message = 'Coupon created successfully.';
                } else {
                    $error = 'Error creating coupon: ' . $stmt->error;
                }
                $stmt->close();
            }
        }
    } else if ($act === 'update') {
        $id = intval($_POST['id'] ?? 0);
        $code = strtoupper(trim($_POST['code'] ?? ''));
        $discount_type = ($_POST['discount_type'] === 'percentage') ? 'percentage' : 'fixed';
        $discount_value = (float)($_POST['discount_value'] ?? 0);
        $min_purchase = (float)($_POST['min_purchase'] ?? 0);
        $max_uses = intval($_POST['max_uses'] ?? -1);
        $is_active = isset($_POST['is_active']) ? 1 : 0;
        $vf = $_POST['valid_from'] ?? '';
        $vt = $_POST['valid_till'] ?? '';
        $valid_from = $vf ? date('Y-m-d H:i:s', strtotime(str_replace('T',' ',$vf))) : date('Y-m-d H:i:s');
        $valid_till = $vt ? date('Y-m-d H:i:s', strtotime(str_replace('T',' ',$vt))) : date('Y-m-d H:i:s');

        if (!$id || !$code || $discount_value <= 0) {
            $error = 'Missing required fields for update.';
        } else {
            $stmt = $mysqli->prepare("UPDATE coupons SET code=?, discount_type=?, discount_value=?, min_purchase=?, max_uses=?, is_active=?, valid_from=?, valid_till=? WHERE id = ?");
            if (!$stmt) {
                $error = 'Database error: ' . $mysqli->error;
            } else {
                $stmt->bind_param('ssddisssi', $code, $discount_type, $discount_value, $min_purchase, $max_uses, $is_active, $valid_from, $valid_till, $id);
                if ($stmt->execute()) {
                    $message = 'Coupon updated successfully.';
                } else {
                    $error = 'Error updating coupon: ' . $stmt->error;
                }
                $stmt->close();
            }
        }
    } else if ($act === 'toggle') {
        $id = intval($_POST['id'] ?? 0);
        if ($id) {
            // Fetch current value
            $stmt = $mysqli->prepare("SELECT is_active FROM coupons WHERE id = ?");
            if ($stmt) {
                $stmt->bind_param('i', $id); $stmt->execute(); $stmt->bind_result($cur); $stmt->fetch(); $stmt->close();
                $new = $cur ? 0 : 1;
                $stmt2 = $mysqli->prepare("UPDATE coupons SET is_active = ? WHERE id = ?");
                if ($stmt2) { $stmt2->bind_param('ii', $new, $id); $stmt2->execute(); $stmt2->close(); $message = 'Coupon status updated.'; }
            }
        }
    } else if ($act === 'delete') {
        $id = intval($_POST['id'] ?? 0);
        if ($id) {
            $stmt = $mysqli->prepare("DELETE FROM coupons WHERE id = ?");
            if ($stmt) { $stmt->bind_param('i', $id); $stmt->execute(); $stmt->close(); $message = 'Coupon deleted.'; }
        }
    }
}

// GET: prepare edit coupon if requested
if (isset($_GET['action']) && $_GET['action'] === 'edit' && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $stmt = $mysqli->prepare("SELECT * FROM coupons WHERE id = ? LIMIT 1");
    if ($stmt) { $stmt->bind_param('i', $id); $stmt->execute(); $res = $stmt->get_result(); $edit_coupon = $res->fetch_assoc() ?: null; $stmt->close(); }
}

// Fetch coupons (robust to missing table)
$coupons = [];
$res = $mysqli->query("SELECT * FROM coupons ORDER BY created_at DESC");
if ($res) { $coupons = $res->fetch_all(MYSQLI_ASSOC); }

?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Coupons - Admin</title>
  <link rel="stylesheet" href="<?php echo base_url('/assets/css/design-system.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('/assets/css/style.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('/assets/css/background.css'); ?>">
</head>
<body class="dark-elegant-bg">
<div class="container">
  <h2>Coupons</h2>
  <nav><a href="<?php echo base_url('/admin/dashboard.php'); ?>">Dashboard</a> | <a href="<?php echo base_url('/admin/products.php'); ?>">Products</a> | <a href="<?php echo base_url('/admin/logout.php'); ?>">Logout</a></nav>

  <?php if ($message): ?>
    <div class="message"><?php echo e($message); ?></div>
  <?php endif; ?>
  <?php if ($error): ?>
    <div class="error"><?php echo e($error); ?></div>
  <?php endif; ?>

<?php if (!empty($edit_coupon)): ?>
  <h3>Edit Coupon (ID: <?php echo e($edit_coupon['id']); ?>)</h3>
  <form method="post" style="max-width:640px">
    <?php echo csrf_input(); ?>
    <input type="hidden" name="action" value="update">
    <input type="hidden" name="id" value="<?php echo e($edit_coupon['id']); ?>">
    <div><label>Code <input name="code" value="<?php echo e($edit_coupon['code']); ?>"></label></div>
    <div>
      <label>Type
        <select name="discount_type">
          <option value="percentage" <?php echo ($edit_coupon['discount_type']==='percentage') ? 'selected':''; ?>>Percentage</option>
          <option value="fixed" <?php echo ($edit_coupon['discount_type']==='fixed') ? 'selected':''; ?>>Fixed (₹)</option>
        </select>
      </label>
    </div>
    <div><label>Value <input name="discount_value" type="number" step="0.01" value="<?php echo e($edit_coupon['discount_value']); ?>"></label></div>
    <div><label>Min Purchase <input name="min_purchase" type="number" step="0.01" value="<?php echo e($edit_coupon['min_purchase']); ?>"></label></div>
    <div><label>Max Uses <input name="max_uses" type="number" value="<?php echo e($edit_coupon['max_uses']); ?>"></label> <small>-1 = unlimited</small></div>
    <div><label>Valid From <input name="valid_from" type="datetime-local" value="<?php echo e(date('Y-m-d\TH:i', strtotime($edit_coupon['valid_from']))); ?>"></label></div>
    <div><label>Valid Till <input name="valid_till" type="datetime-local" value="<?php echo e(date('Y-m-d\TH:i', strtotime($edit_coupon['valid_till']))); ?>"></label></div>
    <div><label><input name="is_active" type="checkbox" <?php echo $edit_coupon['is_active'] ? 'checked':''; ?>> Active</label></div>
    <div style="margin-top:12px"><button class="btn" type="submit">Update Coupon</button> <a href="<?php echo base_url('/admin/coupons.php'); ?>" class="btn">Cancel</a></div>
  </form>
<?php else: ?>
  <h3>Add New Coupon</h3>
  <form method="post" style="max-width:640px">
    <?php echo csrf_input(); ?>
    <input type="hidden" name="action" value="add">
    <div><label>Code <input name="code" placeholder="SAVE10"></label></div>
    <div>
      <label>Type
        <select name="discount_type">
          <option value="percentage">Percentage</option>
          <option value="fixed">Fixed (₹)</option>
        </select>
      </label>
    </div>
    <div><label>Value <input name="discount_value" type="number" step="0.01"></label></div>
    <div><label>Min Purchase <input name="min_purchase" type="number" step="0.01" value="0"></label></div>
    <div><label>Max Uses <input name="max_uses" type="number" value="-1"></label> <small>-1 = unlimited</small></div>
    <div><label>Valid From <input name="valid_from" type="datetime-local"></label></div>
    <div><label>Valid Till <input name="valid_till" type="datetime-local"></label></div>
    <div><label><input name="is_active" type="checkbox" checked> Active</label></div>
    <div style="margin-top:12px"><button class="btn" type="submit">Add Coupon</button></div>
  </form>
<?php endif; ?>

  <h3 style="margin-top:24px">Existing Coupons</h3>
  <?php if (empty($coupons)): ?>
    <p>No coupons found.</p>
  <?php else: ?>
    <table class="table">
      <thead><tr><th>ID</th><th>Code</th><th>Type</th><th>Value</th><th>Active</th><th>Valid</th><th>Actions</th></tr></thead>
      <tbody>
      <?php foreach ($coupons as $c): ?>
        <tr>
          <td><?php echo e($c['id']); ?></td>
          <td><?php echo e($c['code']); ?></td>
          <td><?php echo e($c['discount_type']); ?></td>
          <td><?php echo e($c['discount_value']); ?></td>
          <td><?php echo $c['is_active'] ? 'Yes' : 'No'; ?></td>
          <td><?php echo e($c['valid_from']); ?> → <?php echo e($c['valid_till']); ?></td>
          <td>
            <a href="?action=edit&id=<?php echo e($c['id']); ?>">Edit</a>
            <form method="post" style="display:inline;margin-left:6px">
              <?php echo csrf_input(); ?>
              <input type="hidden" name="action" value="toggle">
              <input type="hidden" name="id" value="<?php echo e($c['id']); ?>">
              <button class="btn" type="submit"><?php echo $c['is_active'] ? 'Deactivate' : 'Activate'; ?></button>
            </form>
            <form method="post" style="display:inline;margin-left:6px" onsubmit="return confirm('Delete coupon?');">
              <?php echo csrf_input(); ?>
              <input type="hidden" name="action" value="delete">
              <input type="hidden" name="id" value="<?php echo e($c['id']); ?>">
              <button class="btn btn-danger" type="submit">Delete</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  <?php endif; ?>

</div>
</body>
</html>