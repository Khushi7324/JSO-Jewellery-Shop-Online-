<?php
require_once __DIR__.'/_auth.php';
require_once __DIR__.'/../includes/functions.php';

$admin_id = $_SESSION['admin_id'];
$errors = [];
$success = '';

// Handle add / edit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'save') {
        $id    = intval($_POST['id'] ?? 0);
        $name  = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $role  = trim($_POST['role'] ?? 'user');
        $pass  = $_POST['password'] ?? '';

        if ($name === '' || $email === '' || $role === '') {
            $errors[] = 'Name, email, and role are required.';
        } else {
            if ($id > 0) {
                // Update existing
                if ($pass !== '') {
                    $hash = password_hash($pass, PASSWORD_DEFAULT);
                    $stmt = $mysqli->prepare("UPDATE users SET name=?, email=?, phone=?, role=?, password=? WHERE id=?");
                    $stmt->bind_param('sssssi', $name, $email, $phone, $role, $hash, $id);
                } else {
                    $stmt = $mysqli->prepare("UPDATE users SET name=?, email=?, phone=?, role=? WHERE id=?");
                    $stmt->bind_param('ssssi', $name, $email, $phone, $role, $id);
                }
                if ($stmt && $stmt->execute()) {
                    $success = "User #$id updated.";
                } else {
                    $errors[] = 'Failed to update user.';
                }
                if ($stmt) $stmt->close();
            } else {
                // Insert new
                $hash = $pass ? password_hash($pass, PASSWORD_DEFAULT) : password_hash(bin2hex(random_bytes(4)), PASSWORD_DEFAULT);
                $stmt = $mysqli->prepare("INSERT INTO users (name, email, phone, role, password) VALUES (?, ?, ?, ?, ?)");
                $stmt->bind_param('sssss', $name, $email, $phone, $role, $hash);
                if ($stmt && $stmt->execute()) {
                    $success = "User created: $email";
                } else {
                    $errors[] = 'Failed to create user (email might exist).';
                }
                if ($stmt) $stmt->close();
            }
        }
    } elseif ($action === 'delete') {
        $id = intval($_POST['id'] ?? 0);
        if ($id === $admin_id) {
            $errors[] = 'You cannot delete your own admin account.';
        } else {
            $stmt = $mysqli->prepare("DELETE FROM users WHERE id=?");
            $stmt->bind_param('i', $id);
            if ($stmt && $stmt->execute()) {
                $success = "User #$id deleted.";
            } else {
                $errors[] = 'Failed to delete user.';
            }
            if ($stmt) $stmt->close();
        }
    }
}

// Editing existing user?
$edit_id = isset($_GET['edit']) ? intval($_GET['edit']) : 0;
$edit_user = null;
if ($edit_id > 0) {
    $stmt = $mysqli->prepare("SELECT id, name, email, phone, role FROM users WHERE id=?");
    $stmt->bind_param('i', $edit_id);
    $stmt->execute();
    $edit_user = $stmt->get_result()->fetch_assoc();
    $stmt->close();
}

$profiles = $mysqli->query("SELECT id, name, email, phone, role, created_at FROM users ORDER BY created_at DESC")->fetch_all(MYSQLI_ASSOC);
?>
<!doctype html><html><head><meta charset="utf-8"><title>User Profiles</title><link rel="stylesheet" href="<?php echo base_url('/assets/css/design-system.css'); ?>"><link rel="stylesheet" href="<?php echo base_url('/assets/css/style.css'); ?>"><link rel="stylesheet" href="<?php echo base_url('/assets/css/background.css'); ?>"></head><body class="dark-elegant-bg">
<div class="container">
  <h2 style="color:var(--color-secondary)">User Profiles</h2>
  <nav style="margin-bottom:20px"><a href="<?php echo base_url('/admin/dashboard.php'); ?>" style="color:#fff;text-decoration:none">← Dashboard</a> | <a href="<?php echo base_url('/admin/logout.php'); ?>" style="color:#fff;text-decoration:none">Logout</a></nav>

  <?php if ($errors): ?><div style="color:#ff8d8d; margin-bottom:12px"><?php echo implode('<br>', array_map('e',$errors)); ?></div><?php endif; ?>
  <?php if ($success): ?><div style="color:#4caf50; margin-bottom:12px"><?php echo e($success); ?></div><?php endif; ?>

  <div style="background:rgba(0,0,0,0.35);padding:16px;border-radius:8px;margin-bottom:20px;border:1px solid rgba(255,255,255,0.08)">
    <h3 style="color:#fff;margin-top:0;"><?php echo $edit_user ? 'Edit User #'.$edit_user['id'] : 'Add User / Admin'; ?></h3>
    <form method="post" style="display:flex;flex-wrap:wrap;gap:10px">
      <input type="hidden" name="id" value="<?php echo $edit_user['id'] ?? 0; ?>">
      <input type="hidden" name="action" value="save">
      <input class="gold-border" type="text" name="name" placeholder="Full Name" required style="flex:1 1 200px" value="<?php echo e($edit_user['name'] ?? ''); ?>">
      <input class="gold-border" type="email" name="email" placeholder="Email" required style="flex:1 1 220px" value="<?php echo e($edit_user['email'] ?? ''); ?>">
      <input class="gold-border" type="text" name="phone" placeholder="Phone" style="flex:1 1 160px" value="<?php echo e($edit_user['phone'] ?? ''); ?>">
      <select class="gold-border" name="role" style="flex:1 1 140px">
        <?php $roleSel = $edit_user['role'] ?? 'user'; ?>
        <option value="user" <?php if($roleSel==='user') echo 'selected'; ?>>user</option>
        <option value="admin" <?php if($roleSel==='admin') echo 'selected'; ?>>admin</option>
      </select>
      <input class="gold-border" type="password" name="password" placeholder="<?php echo $edit_user ? 'New Password (optional)' : 'Password'; ?>" style="flex:1 1 200px">
      <button class="btn btn-glow" type="submit" style="flex:0 0 140px"><?php echo $edit_user ? 'Update' : 'Create'; ?></button>
      <?php if($edit_user): ?><a href="<?php echo base_url('/admin/profiles.php'); ?>" style="color:#fff;text-decoration:none;align-self:center">Reset</a><?php endif; ?>
    </form>
  </div>

  <table style="width:100%; border-collapse:collapse">
    <tr style="background:rgba(205,163,79,0.1)">
      <th style="padding:10px;color:#fff">ID</th>
      <th style="padding:10px;color:#fff">Name</th>
      <th style="padding:10px;color:#fff">Email</th>
      <th style="padding:10px;color:#fff">Phone</th>
      <th style="padding:10px;color:#fff">Role</th>
      <th style="padding:10px;color:#fff">Joined</th>
      <th style="padding:10px;color:#fff">Actions</th>
    </tr>
    <?php foreach ($profiles as $p): ?>
    <tr>
      <td style="padding:10px;border-bottom:1px solid #444"><?=e($p['id'])?></td>
      <td style="padding:10px;border-bottom:1px solid #444"><?=e($p['name'])?></td>
      <td style="padding:10px;border-bottom:1px solid #444"><?=e($p['email'])?></td>
      <td style="padding:10px;border-bottom:1px solid #444"><?=e($p['phone'])?></td>
      <td style="padding:10px;border-bottom:1px solid #444"><?=e($p['role'])?></td>
      <td style="padding:10px;border-bottom:1px solid #444"><?=e($p['created_at'])?></td>
      <td style="padding:10px;border-bottom:1px solid #444">
        <a href="<?php echo base_url('/admin/profiles.php?edit=' . $p['id']); ?>" style="color:var(--color-secondary);text-decoration:none">Edit</a>
        <?php if($p['id'] != $admin_id): ?>
        | <form method="post" style="display:inline" onsubmit="return confirm('Delete user #<?php echo $p['id']; ?>?');">
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="id" value="<?php echo $p['id']; ?>">
            <button style="background:none;border:none;color:#ff8d8d;cursor:pointer">Delete</button>
          </form>
        <?php endif; ?>
      </td>
    </tr>
    <?php endforeach; ?>
  </table>
</div>
</body></html>
