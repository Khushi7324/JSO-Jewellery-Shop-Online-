<?php
session_start();
require_once __DIR__ . '/../includes/functions.php';

// Clear only admin session and keep user session intact.
unset($_SESSION['admin_id']);
header('Location: ' . base_url('/admin/login.php'));
exit;