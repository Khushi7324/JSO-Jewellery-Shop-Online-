<?php
session_start();
require_once __DIR__.'/../config/db.php';
require_once __DIR__.'/../includes/functions.php';

$errors = [];

if($_SERVER['REQUEST_METHOD']=='POST'){
    // allow admin to login with email, phone or username
    $identifier = trim($_POST['email']); 
    $password = $_POST['password'];
    
  if(empty($identifier) || empty($password)){
    $errors[] = 'Please enter email/phone/username and password';
  } else {
    // Try to match by email, phone or name (username)
    $stmt = $mysqli->prepare("SELECT id, password, role FROM users WHERE email=? OR phone=? OR name=? LIMIT 1");
    if(!$stmt){
      $errors[] = 'Database error: failed to prepare statement';
    } else {
      $stmt->bind_param('sss', $identifier, $identifier, $identifier);
      $stmt->execute();
      $stmt->bind_result($id, $hash, $role);
      if($stmt->fetch()){
          if(password_verify($password, $hash) && $role === 'admin'){
            // Keep existing user session intact; store dedicated admin session id.
            $_SESSION['admin_id'] = $id;
            header('Location: ' . base_url('/admin/dashboard.php'));
            exit;
        } else if(password_verify($password, $hash) && $role !== 'admin'){
          $errors[] = 'Access denied: Admin role required';
        } else {
          $errors[] = 'Invalid email or password';
        }
      } else {
        $errors[] = 'Invalid email or password';
      }
      $stmt->close();
    }
  }
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Admin Login</title><link rel="stylesheet" href="<?php echo base_url('/assets/css/design-system.css'); ?>"><link rel="stylesheet" href="<?php echo base_url('/assets/css/style.css'); ?>"><link rel="stylesheet" href="<?php echo base_url('/assets/css/background.css'); ?>"></head><body class="dark-elegant-bg">
<div style="min-height:100vh;display:flex;align-items:center;justify-content:center">
  <div class="glass-card fade-in-up" style="max-width:420px;width:100%">
    <h2 style="margin-top:0;color:var(--color-secondary)">Admin Portal</h2>
    <p style="color:var(--color-text-muted);font-size:13px;margin:0 0 16px 0">Login with admin account credentials</p>
    <?php if($errors): ?><div style="color:#ff8d8d; margin-bottom:8px"><?=implode('<br>',$errors)?></div><?php endif; ?>
    <form method="post" style="display:flex;flex-direction:column;gap:10px">
      <input class="gold-border" type="text" name="email" placeholder="Email / Phone / Username" required>
      <input class="gold-border" type="password" name="password" placeholder="Password" required>
      <button class="btn btn-glow" type="submit">Login</button>
    </form>
    <p style="margin-top:16px;font-size:13px;color:#999">
      Need to create admin?<br>
      <a href="<?php echo base_url('/init_admin.php'); ?>" style="color:var(--color-secondary)">Create/Reset Admin User</a>
    </p>
    <p style="margin-top:16px;font-size:13px;color:var(--color-text-muted)">
      <a href="<?php echo base_url('/login.php'); ?>" style="color:var(--color-secondary)">← Back to User Login</a>
    </p>
  </div>
</div>
</body></html>