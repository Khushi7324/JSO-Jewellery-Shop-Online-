<?php
require_once __DIR__.'/_auth.php';
require_once __DIR__.'/../config/db.php';
require_once __DIR__.'/../includes/functions.php';
// simple dashboard (original UI restored)
$stmt = $mysqli->query("SELECT COUNT(*) as c FROM products"); $pc = $stmt->fetch_assoc()['c'];
$stmt = $mysqli->query("SELECT COUNT(*) as c FROM orders"); $oc = $stmt->fetch_assoc()['c'];
?>
<!doctype html><html><head><meta charset="utf-8"><title>Admin Dashboard</title><link rel="stylesheet" href="<?php echo base_url('/assets/css/style.css'); ?>"><link rel="stylesheet" href="<?php echo base_url('/assets/css/background.css'); ?>"></head><body class="dark-elegant-bg">
<div class="container">
  <h2 style="color:var(--gold)">Admin Dashboard</h2>
  <nav style="margin-bottom:20px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap">
    <div>
      <a href="<?php echo base_url('/admin/orders.php'); ?>" style="color:#fff;text-decoration:none">Orders</a> |
      <a href="<?php echo base_url('/admin/customers.php'); ?>" style="color:#fff;text-decoration:none">Customers</a> |
      <a href="<?php echo base_url('/admin/products.php'); ?>" style="color:#fff;text-decoration:none">Products</a> |
      <a href="<?php echo base_url('/admin/profiles.php'); ?>" style="color:#fff;text-decoration:none">Profiles</a> |
      <a href="<?php echo base_url('/admin/profile.php'); ?>" style="color:#fff;text-decoration:none">My Profile</a> |
      <a href="<?php echo base_url('/admin/add_admin.php'); ?>" style="color:#fff;text-decoration:none">Add Admin</a> |
      <a href="<?php echo base_url('/admin/logout.php'); ?>" style="color:#fff;text-decoration:none">Logout</a>
    </div>
    <?php if (DEVELOPMENT): ?>
      <span style="background:#ff6b6b;color:#fff;padding:4px 12px;border-radius:20px;font-size:12px;font-weight:600;white-space:nowrap;margin-left:10px">🔧 Development Mode</span>
    <?php endif; ?>
  </nav>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-top:20px">
    <div style="background:linear-gradient(135deg,rgba(205,163,79,0.1), rgba(205,163,79,0.05));padding:24px;border-radius:10px;border:1px solid rgba(205,163,79,0.2)">
      <p style="margin:0 0 8px;color:#ccc;font-size:14px;font-weight:600">Total Products</p>
      <h3 style="margin:0;font-size:32px;color:var(--gold)"><?=$pc?></h3>
    </div>
    <div style="background:linear-gradient(135deg,rgba(205,163,79,0.1), rgba(205,163,79,0.05));padding:24px;border-radius:10px;border:1px solid rgba(205,163,79,0.2)">
      <p style="margin:0 0 8px;color:#ccc;font-size:14px;font-weight:600">Total Orders</p>
      <h3 style="margin:0;font-size:32px;color:var(--gold)"><?=$oc?></h3>
    </div>
  </div>
</div>
</body></html>
