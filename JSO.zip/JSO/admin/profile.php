<?php
require_once __DIR__.'/_auth.php';
require_once __DIR__.'/../config/db.php';
require_once __DIR__.'/../includes/functions.php';

$admin_id = $_SESSION['admin_id'];
$errors = [];
$msg = '';

// Fetch current admin info
$stmt = $mysqli->prepare("SELECT name, email, phone FROM users WHERE id=? AND role='admin'");
$stmt->bind_param('i', $admin_id);
$stmt->execute();
$admin = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$admin) {
    die('Admin not found.');
}

$name  = $admin['name'];
$email = $admin['email'];
$phone = $admin['phone'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name  = trim($_POST['name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $new_pass = $_POST['password'] ?? '';
    $confirm  = $_POST['password_confirm'] ?? '';

    if ($name === '') {
        $errors[] = 'Name is required.';
    }

    if ($new_pass !== '' && $new_pass !== $confirm) {
        $errors[] = 'New password and confirm password do not match.';
    }

    if (!$errors) {
        if ($new_pass !== '') {
            $hash = password_hash($new_pass, PASSWORD_DEFAULT);
            $stmt = $mysqli->prepare("UPDATE users SET name=?, phone=?, password=? WHERE id=? AND role='admin'");
            $stmt->bind_param('sssi', $name, $phone, $hash, $admin_id);
        } else {
            $stmt = $mysqli->prepare("UPDATE users SET name=?, phone=? WHERE id=? AND role='admin'");
            $stmt->bind_param('ssi', $name, $phone, $admin_id);
        }
        if ($stmt && $stmt->execute()) {
            $msg = 'Profile updated successfully.';
        } else {
            $errors[] = 'Failed to update profile.';
        }
        if ($stmt) $stmt->close();
    }
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Admin Profile</title>
  <link rel="stylesheet" href="<?php echo base_url('/assets/css/design-system.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('/assets/css/style.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('/assets/css/background.css'); ?>">
  <style>
    .profile-card {
      max-width: 480px;
      margin: 40px auto;
      background: rgba(0,0,0,0.4);
      padding: 24px;
      border-radius: var(--radius-lg);
      color: var(--color-text-light);
      box-shadow: var(--shadow-xl);
    }
    .profile-card h2 { margin-top: 0; color: var(--color-secondary); font-family: var(--font-secondary); }
    .profile-card label { display:block; margin:10px 0 4px; font-weight:600; font-family: var(--font-primary); }
    .profile-card input {
      width:100%;
      padding:8px 10px;
      border-radius:var(--radius-md);
      border:2px solid #555;
      background:#111;
      color:var(--color-text-light);
      font-family: var(--font-primary);
      transition: all var(--transition-base);
    }
    .profile-card input:focus {
      outline: none;
      border-color: var(--color-secondary);
      box-shadow: 0 0 0 3px rgba(205, 163, 79, 0.1);
    }
    .profile-card button {
      margin-top:14px;
      padding:10px 16px;
      border:none;
      border-radius:var(--radius-md);
      background:linear-gradient(135deg,var(--color-secondary),var(--color-secondary-dark));
      color:var(--color-text-light);
      font-weight:700;
      cursor:pointer;
      font-family: var(--font-primary);
      transition: all var(--transition-base);
    }
    .profile-card button:hover {
      transform: translateY(-2px);
      box-shadow: var(--shadow-md);
    }
    .msg-ok { margin-top:10px; color:var(--color-success); }
    .msg-err { margin-top:10px; color:var(--color-error); }
  </style>
</head>
<body class="dark-elegant-bg">
  <div class="container">
    <nav style="margin:20px 0;">
      <a href="<?php echo base_url('/admin/dashboard.php'); ?>" style="color:#fff;text-decoration:none">← Back to Dashboard</a>
    </nav>
    <div class="profile-card">
      <h2>Admin Profile</h2>
      <?php if($msg): ?><div class="msg-ok"><?php echo e($msg); ?></div><?php endif; ?>
      <?php if($errors): ?><div class="msg-err"><?php echo implode('<br>', array_map('e', $errors)); ?></div><?php endif; ?>
      <form method="post">
        <label>Name</label>
        <input type="text" name="name" value="<?php echo e($name); ?>" required>

        <label>Email (readonly)</label>
        <input type="email" value="<?php echo e($email); ?>" disabled>

        <label>Phone</label>
        <input type="text" name="phone" value="<?php echo e($phone); ?>">

        <label>New Password (optional)</label>
        <input type="password" name="password" placeholder="Leave blank to keep current">

        <label>Confirm New Password</label>
        <input type="password" name="password_confirm" placeholder="Repeat new password">

        <button type="submit">Save Changes</button>
      </form>
    </div>
  </div>
</body>
</html>


