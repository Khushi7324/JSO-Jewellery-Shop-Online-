<?php
require_once __DIR__ . '/_auth.php';
require_once __DIR__ . '/../includes/functions.php';
// ensure CSRF token for admin forms
ensure_csrf_token();
$cats = $mysqli->query("SELECT * FROM categories")->fetch_all(MYSQLI_ASSOC);
if(isset($_POST['add'])){
  if(!validate_csrf_token($_POST['csrf_token'] ?? '')){
    $error = 'Invalid CSRF token. Please reload the page.';
  } else {
  $name = $_POST['name']; $desc = $_POST['description']; $price = $_POST['price']; $weight = $_POST['weight']; $cat = $_POST['category']; $stock = intval($_POST['stock']);
    $imgpath = '';
    if(isset($_FILES['image']) && $_FILES['image']['tmp_name']){
        $d = __DIR__ . '/../uploads/'; if(!is_dir($d)) mkdir($d,0777,true);
        $fn = time().'_'.basename($_FILES['image']['name']); move_uploaded_file($_FILES['image']['tmp_name'], $d.$fn);
        $imgpath = 'uploads/'.$fn;
    }
    $stmt = $mysqli->prepare("INSERT INTO products(name,description,price,weight,category_id,stock,image) VALUES(?,?,?,?,?,?,?)");
    $stmt->bind_param('ssddiss',$name,$desc,$price,$weight,$cat,$stock,$imgpath); $stmt->execute();
  }
}
// Handle delete via POST + CSRF (avoid GET deletes)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_product'])) {
  if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
    $error = 'Invalid CSRF token. Please reload the page.';
  } else {
    $id = intval($_POST['product_id']);
    $stmt = $mysqli->prepare("DELETE FROM products WHERE id=?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $stmt->close();
  }
}
$products = $mysqli->query("SELECT p.*, c.name as category FROM products p LEFT JOIN categories c ON p.category_id=c.id")->fetch_all(MYSQLI_ASSOC);
?>
<!doctype html><html><head><meta charset="utf-8"><title>Products</title><link rel="stylesheet" href="<?php echo base_url('/assets/css/design-system.css'); ?>"><link rel="stylesheet" href="<?php echo base_url('/assets/css/style.css'); ?>"><link rel="stylesheet" href="<?php echo base_url('/assets/css/background.css'); ?>"></head><body class="dark-elegant-bg">
<div class="container">
  <h2>Products</h2>
  <nav><a href="<?php echo base_url('/admin/dashboard.php'); ?>">Dashboard</a> | <a href="<?php echo base_url('/admin/categories.php'); ?>">Categories</a> | <a href="<?php echo base_url('/admin/orders.php'); ?>">Orders</a> | <a href="<?php echo base_url('/admin/logout.php'); ?>">Logout</a></nav>
  <form method="post" enctype="multipart/form-data" style="margin-top:12px">
    <?= csrf_input() ?>
    <input name="name" placeholder="Name" required>
    <input name="price" placeholder="Price" required>
    <input name="weight" placeholder="Weight">
    <select name="category"><?php foreach($cats as $c): ?><option value="<?=$c['id']?>"><?=e($c['name'])?></option><?php endforeach; ?></select>
    <input name="stock" placeholder="Stock" value="1">
    <input type="file" name="image">
    <textarea name="description" placeholder="Description"></textarea>
    <div><button class="btn" name="add">Add Product</button></div>
  </form>
  <h3>Existing Products</h3>
  <table style="width:100%"><tr><th>Image</th><th>Name</th><th>Category</th><th>Price</th><th>Stock</th><th>Action</th></tr>
  <?php foreach($products as $p): ?>
    <tr>
      <td><img src="<?php echo base_url('/' . ltrim($p['image'], '/')); ?>" style="width:80px;height:60px;object-fit:cover"></td>
      <td><?=e($p['name'])?></td>
      <td><?=e($p['category'])?></td>
      <td>₹ <?=e($p['price'])?></td>
      <td><?=e($p['stock'])?></td>
      <td>
        <a href="<?php echo base_url('/admin/edit-product.php?id=' . $p['id']); ?>">Edit</a>
        &nbsp;|&nbsp;
        <form method="POST" style="display:inline;">
          <?= csrf_input() ?>
          <input type="hidden" name="product_id" value="<?= $p['id'] ?>">
          <button type="submit" name="delete_product" class="btn-link" style="background:none;border:none;color:#007bff;cursor:pointer;padding:0;font-size:inherit;">Delete</button>
        </form>
      </td>
    </tr>
  <?php endforeach; ?>
  </table>
</div></body></html>