<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';

// Strict role-based access control
require_admin();

$message = '';
$error = '';

// ensure CSRF token for this admin form
ensure_csrf_token();

// Get all categories
$cats_result = $mysqli->query("SELECT * FROM categories ORDER BY name");
if ($cats_result) {
  $categories = $cats_result->fetch_all(MYSQLI_ASSOC);
} else {
  // categories table might be missing in some environments; default to empty list
  $categories = [];
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
    $error = 'Invalid CSRF token. Please reload the page and try again.';
  } else {
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $price = (float)($_POST['price'] ?? 0);
    $weight = (float)($_POST['weight'] ?? 0);
    $category_id = (int)($_POST['category_id'] ?? 0);
    $stock = (int)($_POST['stock'] ?? 0);
    $image = 'uploads/placeholder.svg'; // Default image
    // collect optional multi-angle uploads
    $angles = [
      'front' => 'image_front',
      'side' => 'image_side',
      'back' => 'image_back',
      'top' => 'image_top',
      'detail' => 'image_detail'
    ];
    $uploaded_angles = [];

    // Validate
    if (!$name || $price <= 0 || $category_id <= 0) {
      $error = 'Please fill in all required fields (Name, Price, Category)';
    } else {
      // Handle primary image upload
      if (isset($_FILES['image']) && $_FILES['image']['tmp_name']) {
        $upload_dir = __DIR__ . '/../uploads/';
        if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);

        // sanitize filename to avoid path tricks or unsafe chars
        $orig = basename($_FILES['image']['name']);
        $safe_name = preg_replace('/[^A-Za-z0-9._-]/', '_', $orig);
        $filename = time() . '_' . $safe_name;
        $filepath = $upload_dir . $filename;

        // basic validation
        $allowed = ['image/jpeg','image/png','image/webp','image/gif'];
        $mime = mime_content_type($_FILES['image']['tmp_name']);
        if (!in_array($mime, $allowed)) {
          $error = 'Invalid image type. Allowed: JPG, PNG, WEBP, GIF';
        } elseif ($_FILES['image']['size'] > 5*1024*1024) {
          $error = 'Image too large. Max 5MB';
        } elseif (move_uploaded_file($_FILES['image']['tmp_name'], $filepath)) {
          $image = 'uploads/' . $filename;
        } else {
          $error = 'Error uploading image file';
        }
      }

      // Handle multi-angle uploads
      if (!$error) {
        $upload_dir = __DIR__ . '/../uploads/';
        if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);
        foreach ($angles as $angle => $field) {
          if (isset($_FILES[$field]) && $_FILES[$field]['tmp_name']) {
            // sanitize filename
            $orig = basename($_FILES[$field]['name']);
            $safe_name = preg_replace('/[^A-Za-z0-9._-]/', '_', $orig);
            $filename = time() . '_' . $angle . '_' . $safe_name;
            $filepath = $upload_dir . $filename;
            $allowed = ['image/jpeg','image/png','image/webp','image/gif'];
            $mime = mime_content_type($_FILES[$field]['tmp_name']);
            if (!in_array($mime, $allowed)) { continue; }
            if ($_FILES[$field]['size'] > 5*1024*1024) { continue; }
            if (move_uploaded_file($_FILES[$field]['tmp_name'], $filepath)) {
              $uploaded_angles[$angle] = 'uploads/' . $filename;
            }
          }
        }
        // if front uploaded, prefer it as primary image
        if (!empty($uploaded_angles['front'])) {
          $image = $uploaded_angles['front'];
        }
      }

      if (!$error) {
        // Insert new product
        $stmt = $mysqli->prepare("INSERT INTO products (name, description, price, weight, category_id, stock, image, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())");
        if (!$stmt) {
          $error = 'Database error: ' . $mysqli->error;
        } else {
          $stmt->bind_param('ssddiis', $name, $description, $price, $weight, $category_id, $stock, $image);

          if ($stmt->execute()) {
            $new_product_id = $mysqli->insert_id;
            $image_save_error = '';
            // Persist multi-angle images (non-fatal if table is missing)
            if (!empty($uploaded_angles)) {
              $stmtImg = $mysqli->prepare("INSERT INTO product_images (product_id, angle, image_url) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE image_url=VALUES(image_url)");
              if ($stmtImg) {
                foreach ($uploaded_angles as $angle => $url) {
                  $a = $angle; $u = $url;
                  $stmtImg->bind_param('iss', $new_product_id, $a, $u);
                  $stmtImg->execute();
                }
                $stmtImg->close();
              } else {
                // product_images table might not exist yet; warn but don't fail the product creation
                $image_save_error = ' Note: angle images could not be saved (' . $mysqli->error . ').';
              }
            }
            header('Location: ' . base_url('/admin/products-list.php?message=' . urlencode('Product created successfully' . $image_save_error)));
            exit;
          } else {
            $error = 'Error creating product: ' . $stmt->error;
          }
          $stmt->close();
        }
      }
    }
  }
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Add New Product - Admin</title>
  <link rel="stylesheet" href="<?php echo base_url('/assets/css/design-system.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('/assets/css/style.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('/assets/css/background.css'); ?>">
  <style>
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }
    
    body {
      font-family: var(--font-primary);
      background: var(--color-bg-secondary);
      padding: 20px;
    }
    
    .form-container {
      background: var(--color-bg-primary);
      border-radius: var(--radius-md);
      box-shadow: var(--shadow-md);
      max-width: 800px;
      margin: 0 auto;
      padding: 30px;
    }
    
    .form-header {
      margin-bottom: 30px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      gap: 15px;
    }
    
    .form-header h1 {
      font-size: 28px;
      color: var(--color-text-primary);
      font-family: var(--font-secondary);
    }
    
    .form-group {
      margin-bottom: 24px;
    }
    
    .form-group label {
      display: block;
      margin-bottom: 8px;
      font-weight: 600;
      color: var(--color-text-primary);
      font-size: 14px;
      font-family: var(--font-primary);
    }
    
    .form-group small {
      display: block;
      color: var(--color-text-muted);
      font-size: 12px;
      margin-top: 4px;
    }
    
    .form-group input,
    .form-group textarea,
    .form-group select {
      width: 100%;
      padding: 12px;
      border: 2px solid #e5e7eb;
      border-radius: var(--radius-md);
      font-size: 14px;
      font-family: var(--font-primary);
      transition: all var(--transition-base);
      background: var(--color-bg-primary);
      color: var(--color-text-primary);
    }
    
    .form-group input:focus,
    .form-group textarea:focus,
    .form-group select:focus {
      outline: none;
      border-color: var(--color-primary);
      box-shadow: 0 0 0 3px rgba(26, 115, 232, 0.1);
    }
    
    .form-group textarea {
      resize: vertical;
      min-height: 100px;
    }
    
    .form-row {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 20px;
      margin-bottom: 24px;
    }
    
    @media (max-width: 600px) {
      .form-row {
        grid-template-columns: 1fr;
      }
    }
    
    .file-input-wrapper {
      position: relative;
      overflow: hidden;
      display: inline-block;
    }
    
    .file-input-wrapper input[type="file"] {
      position: absolute;
      left: -9999px;
    }
    
    .file-label {
      display: inline-block;
      padding: 10px 16px;
      background: var(--color-primary);
      color: var(--color-text-light);
      border-radius: var(--radius-md);
      cursor: pointer;
      font-weight: 600;
      font-size: 13px;
      transition: all var(--transition-base);
      font-family: var(--font-primary);
    }
    
    .file-label:hover {
      background: var(--color-primary-dark);
      transform: translateY(-2px);
      box-shadow: var(--shadow-md);
    }
    
    .form-actions {
      display: flex;
      gap: 10px;
      margin-top: 30px;
      flex-wrap: wrap;
    }
    
    .btn {
      padding: 12px 24px;
      border: none;
      border-radius: var(--radius-md);
      cursor: pointer;
      font-weight: 600;
      font-size: 14px;
      transition: all var(--transition-base);
      text-decoration: none;
      display: inline-block;
      font-family: var(--font-primary);
    }
    
    .btn-save {
      background: linear-gradient(135deg, var(--color-primary) 0%, var(--color-primary-dark) 100%);
      color: var(--color-text-light);
    }
    
    .btn-save:hover {
      transform: translateY(-2px);
      box-shadow: var(--shadow-lg);
    }
    
    .btn-cancel {
      background: var(--color-text-tertiary);
      color: var(--color-text-light);
    }
    
    .btn-cancel:hover {
      background: var(--color-text-secondary);
      transform: translateY(-2px);
      box-shadow: var(--shadow-md);
    }
    
    .message {
      background: #d4edda;
      border: 1px solid #c3e6cb;
      color: #155724;
      padding: 12px;
      border-radius: var(--radius-md);
      margin-bottom: 20px;
    }
    
    .error {
      background: #f8d7da;
      border: 1px solid #f5c6cb;
      color: #721c24;
      padding: 12px;
      border-radius: var(--radius-md);
      margin-bottom: 20px;
    }
    
    .required {
      color: var(--color-error);
      font-weight: 700;
    }
  </style>
</head>
<body>
  <div class="form-container">
    <div class="form-header">
      <h1>➕ Add New Product</h1>
      <a href="<?php echo base_url('/admin/products-list.php'); ?>" class="btn btn-cancel">← Back</a>
    </div>
    
    <?php if ($message): ?>
      <div class="message"><?= e($message) ?></div>
    <?php endif; ?>
    
    <?php if ($error): ?>
      <div class="error"><?= e($error) ?></div>
    <?php endif; ?>
    
    <form method="POST" enctype="multipart/form-data">
      <?= csrf_input() ?>
      <div class="form-group">
        <label>Product Name <span class="required">*</span></label>
        <input type="text" name="name" value="<?= e($_POST['name'] ?? '') ?>" required autofocus>
        <small>Enter a clear and descriptive product name</small>
      </div>
      
      <div class="form-group">
        <label>Description</label>
        <textarea name="description"><?= e($_POST['description'] ?? '') ?></textarea>
        <small>Provide details about the product (optional)</small>
      </div>
      
      <div class="form-row">
        <div class="form-group">
          <label>Category <span class="required">*</span></label>
          <select name="category_id" required>
            <option value="">-- Select Category --</option>
            <?php foreach($categories as $cat): ?>
              <option value="<?= $cat['id'] ?>" <?= ($_POST['category_id'] ?? '') == $cat['id'] ? 'selected' : '' ?>>
                <?= e($cat['name']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        
        <div class="form-group">
          <label>Price (₹) <span class="required">*</span></label>
          <input type="number" name="price" step="0.01" value="<?= e($_POST['price'] ?? '') ?>" required>
          <small>Enter the selling price in rupees</small>
        </div>
      </div>
      
      <div class="form-row">
        <div class="form-group">
          <label>Weight (grams)</label>
          <input type="number" name="weight" step="0.001" value="<?= e($_POST['weight'] ?? '') ?>">
          <small>Optional: Product weight for jewelry (e.g., 2.5 for 2.5 grams)</small>
        </div>
        
        <div class="form-group">
          <label>Stock Quantity</label>
          <input type="number" name="stock" value="<?= e($_POST['stock'] ?? '10') ?>">
          <small>Number of items available in inventory</small>
        </div>
      </div>
      
      <div class="form-group">
        <label>Product Image</label>
        <div class="file-input-wrapper">
          <input type="file" id="image_input" name="image" accept="image/*">
          <label for="image_input" class="file-label">📷 Choose Image</label>
        </div>
        <small>Upload a product image (JPG, PNG, etc.). Optional - a default image will be used if not provided.</small>
      </div>
      
      <div class="form-group">
        <label>Additional Photos (optional)</label>
        <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:12px">
          <div>
            <small>Front</small>
            <input type="file" name="image_front" accept="image/*">
          </div>
          <div>
            <small>Side</small>
            <input type="file" name="image_side" accept="image/*">
          </div>
          <div>
            <small>Back</small>
            <input type="file" name="image_back" accept="image/*">
          </div>
          <div>
            <small>Top</small>
            <input type="file" name="image_top" accept="image/*">
          </div>
          <div>
            <small>Detail</small>
            <input type="file" name="image_detail" accept="image/*">
          </div>
        </div>
        <small>These photos appear as angle thumbnails on the product page.</small>
      </div>
      
      <div class="form-actions">
        <button type="submit" class="btn btn-save">✅ Create Product</button>
        <a href="<?php echo base_url('/admin/products-list.php'); ?>" class="btn btn-cancel">Cancel</a>
      </div>
    </form>
  </div>
</body>
</html>
