<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';

// Simple admin authentication check
if (!isset($_SESSION['admin'])) {
  $_SESSION['admin'] = false;
}

// Ensure a demo admin user exists (convenience for local/dev setups)
// This will only insert if there are no users with role='admin' and DEVELOPMENT is enabled
if (defined('DEVELOPMENT') && DEVELOPMENT) {
  try {
    $check = $mysqli->prepare("SELECT id FROM users WHERE role = 'admin' LIMIT 1");
    if ($check) {
      $check->execute();
      $res = $check->get_result();
      if (!$res || $res->num_rows === 0) {
        $demo_user = 'admin';
        $demo_pass = password_hash('admin123', PASSWORD_DEFAULT);
        $role = 'admin';
        $ins = $mysqli->prepare("INSERT INTO users (name, password, role) VALUES (?, ?, ?)");
        if ($ins) {
          $ins->bind_param('sss', $demo_user, $demo_pass, $role);
          $ins->execute();
          $ins->close();
        }
      }
      $check->close();
    }
  } catch (Exception $e) {
    // ignore - non-fatal convenience step
  }
}

// Handle login: use DB-backed users table (name, password, role)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['admin_login'])) {
  $username = trim($_POST['username'] ?? '');
  $password = $_POST['password'] ?? '';

  if ($username === '' || $password === '') {
    $login_error = 'Please provide username and password';
  } else {
    $stmt = $mysqli->prepare('SELECT id, password, role FROM users WHERE name = ? LIMIT 1');
    if ($stmt) {
      $stmt->bind_param('s', $username);
      $stmt->execute();
      $stmt->bind_result($id, $hash, $role);
      if ($stmt->fetch() && password_verify($password, $hash) && $role === 'admin') {
        $_SESSION['admin'] = true;
        $_SESSION['admin_id'] = $id;
        $stmt->close();
        header('Location: ' . base_url('/admin/products-list.php'));
        exit;
      } else {
        $login_error = 'Invalid credentials';
      }
      $stmt->close();
    } else {
      $login_error = 'Login system not available';
    }
  }
}

// If already logged in, redirect to products
if (!empty($_SESSION['admin'])) {
  header('Location: ' . base_url('/admin/products-list.php'));
  exit;
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Admin Login - JSO Shop</title>
  <style>
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }
    
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20px;
    }
    
    .login-container {
      background: white;
      border-radius: 12px;
      box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
      width: 100%;
      max-width: 400px;
      padding: 40px;
    }
    
    .login-header {
      text-align: center;
      margin-bottom: 30px;
    }
    
    .login-header h1 {
      font-size: 28px;
      color: #333;
      margin-bottom: 8px;
    }
    
    .login-header p {
      color: #666;
      font-size: 14px;
    }
    
    .form-group {
      margin-bottom: 20px;
    }
    
    .form-group label {
      display: block;
      margin-bottom: 8px;
      color: #333;
      font-weight: 600;
      font-size: 14px;
    }
    
    .form-group input {
      width: 100%;
      padding: 12px;
      border: 1px solid #ddd;
      border-radius: 6px;
      font-size: 14px;
      transition: all 0.3s ease;
    }
    
    .form-group input:focus {
      outline: none;
      border-color: #667eea;
      box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
    }
    
    .login-btn {
      width: 100%;
      padding: 12px;
      background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
      color: white;
      border: none;
      border-radius: 6px;
      font-weight: 700;
      cursor: pointer;
      transition: all 0.3s ease;
      font-size: 14px;
    }
    
    .login-btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 8px 20px rgba(102, 126, 234, 0.3);
    }
    
    .login-error {
      background: #fff5f5;
      border: 1px solid #fc8181;
      color: #c53030;
      padding: 12px;
      border-radius: 6px;
      margin-bottom: 20px;
      font-size: 13px;
    }
    
    .demo-notice {
      background: #f0f4ff;
      border: 1px solid #cbd5e0;
      color: #2d3748;
      padding: 12px;
      border-radius: 6px;
      margin-top: 20px;
      font-size: 12px;
      line-height: 1.5;
    }
  </style>
</head>
<body>
  <div class="login-container">
    <div class="login-header">
      <h1>Admin Panel</h1>
      <p>JSO Jewelry Shop</p>
    </div>
    
    <?php if (isset($login_error)): ?>
      <div class="login-error"><?= e($login_error) ?></div>
    <?php endif; ?>
    
    <form method="POST">
      <div class="form-group">
        <label>Username</label>
        <input type="text" name="username" placeholder="Enter username" required autofocus>
      </div>
      
      <div class="form-group">
        <label>Password</label>
        <input type="password" name="password" placeholder="Enter password" required>
      </div>
      
      <button type="submit" name="admin_login" class="login-btn">Login</button>
    </form>
    
    <div class="demo-notice">
      <strong>Demo Credentials:</strong><br>
      Username: <code>admin</code><br>
      Password: <code>admin123</code>
    </div>
  </div>
</body>
</html>
