<?php
session_start();
require_once __DIR__.'/../config/db.php';
require_once __DIR__.'/../includes/functions.php';

// Strict role-based access control
if(!isAdmin()){
    http_response_code(403);
    header('Location: ' . base_url('/error403.php'));
    exit;
}
?>