<?php
session_start();
require '../config/db.php';
require_once __DIR__ . '/../includes/functions.php';

// Strict role-based access control
require_admin();

// Get admin info
$admin_id = $_SESSION['admin_id'];
$stmt = $mysqli->prepare("SELECT name, email FROM users WHERE id=?");
$stmt->bind_param('i', $admin_id);
$stmt->execute();
$admin = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Get statistics
$stats = [];

// Total products
$stmt = $mysqli->query("SELECT COUNT(*) as cnt FROM products");
$stats['products'] = $stmt->fetch_assoc()['cnt'];

// Total users (exclude admins)
$stmt = $mysqli->query("SELECT COUNT(*) as cnt FROM users WHERE role IS NULL OR role!='admin'");
$stats['users'] = $stmt->fetch_assoc()['cnt'];

// Total orders
$stmt = $mysqli->query("SELECT COUNT(*) as cnt FROM orders");
$stats['orders'] = $stmt->fetch_assoc()['cnt'];

// Total revenue
$stmt = $mysqli->query("SELECT SUM(total) as revenue FROM orders WHERE status='delivered'");
$result = $stmt->fetch_assoc();
$stats['revenue'] = $result['revenue'] ?? 0;

// Recent orders
$stmt = $mysqli->prepare("SELECT o.id, o.total, o.status, o.order_date as created_at, u.name, u.phone FROM orders o JOIN users u ON o.user_id=u.id ORDER BY o.order_date DESC LIMIT 10");
$stmt->execute();
$recent_orders = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Pending returns
$stmt = $mysqli->query("SELECT COUNT(*) as cnt FROM returns WHERE status='pending'");
$stats['pending_returns'] = $stmt->fetch_assoc()['cnt'];

// Pending deliveries
$stmt = $mysqli->query("SELECT COUNT(*) as cnt FROM orders WHERE status='confirmed' OR status='shipped'");
$stats['pending_deliveries'] = $stmt->fetch_assoc()['cnt'];

?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Admin Dashboard - Jewelry Shop</title>
  <link rel="stylesheet" href="<?php echo base_url('/assets/css/design-system.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('/assets/css/style.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('/assets/css/background.css'); ?>">
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: var(--font-primary);
      background: var(--color-bg-secondary);
      color: var(--color-text-primary);
    }

    .admin-wrapper {
      display: flex;
      min-height: 100vh;
    }

    .sidebar {
      width: 250px;
      background: linear-gradient(180deg, var(--color-bg-dark), var(--color-bg-dark-secondary));
      color: var(--color-text-light);
      padding: 20px;
      box-shadow: 2px 0 10px rgba(0,0,0,0.1);
      position: fixed;
      height: 100vh;
      overflow-y: auto;
    }

    .sidebar-logo {
      font-size: 24px;
      font-weight: 900;
      margin-bottom: 30px;
      padding-bottom: 15px;
      border-bottom: 1px solid rgba(255,255,255,0.1);
    }

    .sidebar-menu {
      list-style: none;
    }

    .sidebar-menu li {
      margin-bottom: 8px;
    }

    .sidebar-menu a {
      display: block;
      padding: 12px 15px;
      color: #ecf0f1;
      text-decoration: none;
      border-radius: 6px;
      transition: all 0.2s;
    }

    .sidebar-menu a:hover {
      background: rgba(255,255,255,0.1);
      color: var(--color-secondary);
    }

    .sidebar-menu a.active {
      background: var(--color-secondary);
      color: var(--color-bg-dark);
      font-weight: 600;
    }

    .main-content {
      flex: 1;
      margin-left: 250px;
    }

    .header {
      background: var(--color-bg-primary);
      padding: 20px 30px;
      box-shadow: var(--shadow-md);
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .header-title {
      font-size: 24px;
      font-weight: 700;
    }

    .header-user {
      display: flex;
      align-items: center;
      gap: 20px;
    }

    .user-info {
      text-align: right;
    }

    .user-name {
      font-weight: 700;
      color: var(--color-text-primary);
    }

    .user-role {
      font-size: 12px;
      color: var(--color-text-muted);
    }

    .logout-btn {
      padding: 8px 16px;
      background: var(--color-error);
      color: var(--color-text-light);
      border: none;
      border-radius: var(--radius-sm);
      cursor: pointer;
      font-weight: 600;
      transition: all var(--transition-base);
      font-family: var(--font-primary);
    }

    .logout-btn:hover {
      background: #dc2626;
      transform: translateY(-2px);
      box-shadow: var(--shadow-md);
    }

    .dashboard-content {
      padding: 30px;
    }

    .stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 20px;
      margin-bottom: 40px;
    }

    .stat-card {
      background: var(--color-bg-primary);
      padding: 20px;
      border-radius: var(--radius-md);
      box-shadow: var(--shadow-md);
      text-align: center;
    }

    .stat-icon {
      font-size: 36px;
      margin-bottom: 10px;
    }

    .stat-value {
      font-size: 32px;
      font-weight: 900;
      color: var(--color-secondary);
      margin-bottom: 5px;
      font-family: var(--font-secondary);
    }

    .stat-label {
      font-size: 13px;
      color: var(--color-text-muted);
      font-weight: 600;
      text-transform: uppercase;
      font-family: var(--font-primary);
    }

    .section-title {
      font-size: 20px;
      font-weight: 700;
      color: var(--color-text-primary);
      margin-bottom: 20px;
      padding-bottom: 10px;
      border-bottom: 2px solid var(--color-secondary);
      font-family: var(--font-secondary);
    }

    .table-responsive {
      background: var(--color-bg-primary);
      border-radius: var(--radius-md);
      box-shadow: var(--shadow-md);
      overflow: hidden;
    }

    table {
      width: 100%;
      border-collapse: collapse;
    }

    thead {
      background: var(--color-bg-tertiary);
      border-bottom: 2px solid #e5e7eb;
    }

    th {
      padding: 15px;
      text-align: left;
      font-weight: 700;
      font-size: 13px;
      text-transform: uppercase;
      color: var(--color-text-secondary);
      font-family: var(--font-primary);
    }

    td {
      padding: 15px;
      border-bottom: 1px solid #e5e7eb;
      color: var(--color-text-secondary);
      font-family: var(--font-primary);
    }

    tr:hover {
      background: var(--color-bg-secondary);
    }

    .status-badge {
      padding: 4px 10px;
      border-radius: 20px;
      font-size: 11px;
      font-weight: 600;
      text-transform: uppercase;
    }

    .status-delivered {
      background: #d4edda;
      color: #155724;
    }

    .status-pending {
      background: #fff3cd;
      color: #856404;
    }

    .status-shipped {
      background: #d1ecf1;
      color: #0c5460;
    }

    .status-confirmed {
      background: #cfe2ff;
      color: #084298;
    }

    .status-cancelled {
      background: #f8d7da;
      color: #721c24;
    }

    .action-links {
      display: flex;
      gap: 8px;
    }

    .action-links a {
      padding: 4px 10px;
      background: var(--color-primary);
      color: var(--color-text-light);
      text-decoration: none;
      border-radius: var(--radius-sm);
      font-size: 12px;
      font-weight: 600;
      transition: all var(--transition-base);
      font-family: var(--font-primary);
    }

    .action-links a:hover {
      background: var(--color-accent);
      transform: translateY(-2px);
      box-shadow: var(--shadow-sm);
    }

    .quick-actions {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
      gap: 15px;
      margin-top: 20px;
    }

    .action-btn {
      padding: 15px;
      background: var(--color-bg-primary);
      border: 2px solid var(--color-secondary);
      border-radius: var(--radius-md);
      text-align: center;
      cursor: pointer;
      transition: all var(--transition-base);
      text-decoration: none;
      color: var(--color-secondary);
      font-weight: 600;
      font-family: var(--font-primary);
    }

    .action-btn:hover {
      background: var(--color-secondary);
      color: var(--color-text-light);
      transform: translateY(-2px);
      box-shadow: var(--shadow-md);
    }

    @media (max-width: 1024px) {
      .sidebar {
        width: 200px;
      }

      .main-content {
        margin-left: 200px;
      }

      .stats-grid {
        grid-template-columns: repeat(2, 1fr);
      }
    }

    @media (max-width: 768px) {
      .admin-wrapper {
        flex-direction: column;
      }

      .sidebar {
        width: 100%;
        height: auto;
        position: static;
      }

      .main-content {
        margin-left: 0;
      }

      .stats-grid {
        grid-template-columns: 1fr;
      }

      .header {
        flex-direction: column;
        text-align: center;
        gap: 15px;
      }
    }
  </style>
</head>
<body>
  <div class="admin-wrapper">
    <!-- SIDEBAR -->
    <div class="sidebar">
      <div class="sidebar-logo">💎 JSO Admin</div>
      <ul class="sidebar-menu">
        <li><a href="<?php echo base_url('/admin/dashboard.php'); ?>" class="active">📊 Dashboard</a></li>
        <li><a href="<?php echo base_url('/admin/products.php'); ?>">📦 Products</a></li>
        <li><a href="<?php echo base_url('/admin/categories.php'); ?>">🏷️ Categories</a></li>
        <li><a href="<?php echo base_url('/admin/orders.php'); ?>">📋 Orders</a></li>
        <li><a href="<?php echo base_url('/admin/users.php'); ?>">👥 Users</a></li>
        <li><a href="<?php echo base_url('/admin/coupons.php'); ?>">🎟️ Coupons</a></li>
        <li><a href="<?php echo base_url('/admin/offers.php'); ?>">🎁 Offers</a></li>
        <li><a href="<?php echo base_url('/admin/returns.php'); ?>">↩️ Returns</a></li>
        <li><a href="<?php echo base_url('/admin/settings.php'); ?>">⚙️ Settings</a></li>
        <li><a href="<?php echo base_url('/admin/logout.php'); ?>">🚪 Logout</a></li>
      </ul>
    </div>

    <!-- MAIN CONTENT -->
    <div class="main-content">
      <!-- HEADER -->
      <div class="header">
        <div class="header-title">📊 Dashboard</div>
        <div class="header-user">
          <div class="user-info">
            <div class="user-name"><?php echo htmlspecialchars($admin['name']); ?></div>
            <div class="user-role">Administrator</div>
          </div>
          <a href="<?php echo base_url('/admin/logout.php'); ?>" class="logout-btn">Logout</a>
        </div>
      </div>

      <!-- DASHBOARD CONTENT -->
      <div class="dashboard-content">
        <!-- STATISTICS -->
        <div class="stats-grid">
          <div class="stat-card">
            <div class="stat-icon">📦</div>
            <div class="stat-value"><?php echo number_format($stats['products']); ?></div>
            <div class="stat-label">Total Products</div>
          </div>

          <div class="stat-card">
            <div class="stat-icon">👥</div>
            <div class="stat-value"><?php echo number_format($stats['users']); ?></div>
            <div class="stat-label">Total Users</div>
          </div>

          <div class="stat-card">
            <div class="stat-icon">📋</div>
            <div class="stat-value"><?php echo number_format($stats['orders']); ?></div>
            <div class="stat-label">Total Orders</div>
          </div>

          <div class="stat-card">
            <div class="stat-icon">💰</div>
            <div class="stat-value">₹<?php echo number_format($stats['revenue'], 0); ?></div>
            <div class="stat-label">Total Revenue</div>
          </div>

          <div class="stat-card">
            <div class="stat-icon">⏳</div>
            <div class="stat-value"><?php echo $stats['pending_deliveries']; ?></div>
            <div class="stat-label">Pending Delivery</div>
          </div>

          <div class="stat-card">
            <div class="stat-icon">↩️</div>
            <div class="stat-value"><?php echo $stats['pending_returns']; ?></div>
            <div class="stat-label">Pending Returns</div>
          </div>
        </div>

        <!-- QUICK ACTIONS -->
        <h2 class="section-title">Quick Actions</h2>
        <div class="quick-actions">
          <a href="<?php echo base_url('/admin/products.php?action=add'); ?>" class="action-btn">+ Add Product</a>
          <a href="<?php echo base_url('/admin/categories.php?action=add'); ?>" class="action-btn">+ Add Category</a>
          <a href="<?php echo base_url('/admin/coupons.php?action=add'); ?>" class="action-btn">+ Add Coupon</a>
          <a href="<?php echo base_url('/admin/offers.php?action=add'); ?>" class="action-btn">+ Create Offer</a>
        </div>

        <!-- RECENT ORDERS -->
        <h2 class="section-title" style="margin-top: 40px;">📋 Recent Orders</h2>
        <div class="table-responsive">
          <table>
            <thead>
              <tr>
                <th>Order ID</th>
                <th>Customer</th>
                <th>Phone</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Date</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($recent_orders as $order): ?>
                <tr>
                  <td><strong>#<?php echo $order['id']; ?></strong></td>
                  <td><?php echo htmlspecialchars($order['name']); ?></td>
                  <td><?php echo $order['phone']; ?></td>
                  <td>₹<?php echo number_format($order['total']); ?></td>
                  <td><span class="status-badge status-<?php echo strtolower($order['status']); ?>"><?php echo ucfirst($order['status']); ?></span></td>
                  <td><?php echo date('M d, Y', strtotime($order['created_at'])); ?></td>
                  <td>
                    <div class="action-links">
                      <a href="<?php echo base_url('/admin/orders.php?id=' . $order['id']); ?>">View</a>
                    </div>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>

      </div>
    </div>
  </div>
</body>
</html>
