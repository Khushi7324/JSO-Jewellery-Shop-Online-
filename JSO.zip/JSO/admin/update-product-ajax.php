<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';

header('Content-Type: application/json; charset=utf-8');

// Only POST is allowed for this AJAX endpoint
if (strtoupper($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
  http_response_code(405);
  echo json_encode(['success' => false, 'message' => 'Method Not Allowed. Use POST.']);
  exit;
}

// Strict role-based access control (requires POST)
if (!isAdmin()) {
  // Return JSON with 403 but include a clear machine-readable body so scanners can parse it.
  http_response_code(403);
  echo json_encode(['success' => false, 'message' => 'Unauthorized', 'code' => 'unauthorized']);
  exit;
}

// Validate CSRF token
if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
  http_response_code(403);
  echo json_encode(['success' => false, 'message' => 'Invalid CSRF token']);
  exit;
}

$input = $_POST;
$id = isset($input['id']) ? intval($input['id']) : 0;
$price = isset($input['price']) ? $input['price'] : null;
$stock = isset($input['stock']) ? $input['stock'] : null;

if (!$id) {
  http_response_code(400);
  echo json_encode(['success' => false, 'message' => 'Missing product id']);
  exit;
}

$updates = [];
$types = '';
$params = [];

if ($price !== null) {
  // normalize numeric price
  $price = (float)str_replace(',', '', $price);
  $updates[] = 'price = ?';
  $types .= 'd';
  $params[] = $price;
}

if ($stock !== null) {
  $stock = intval($stock);
  $updates[] = 'stock = ?';
  $types .= 'i';
  $params[] = $stock;
}

if (empty($updates)) {
  echo json_encode(['success' => false, 'message' => 'Nothing to update']);
  exit;
}

$types .= 'i';
$params[] = $id;

$sql = 'UPDATE products SET ' . implode(', ', $updates) . ' WHERE id = ?';
$stmt = $mysqli->prepare($sql);
if (!$stmt) {
  http_response_code(500);
  echo json_encode(['success' => false, 'message' => 'Prepare failed: ' . $mysqli->error]);
  exit;
}

$stmt->bind_param($types, ...$params);
if ($stmt->execute()) {
  echo json_encode(['success' => true, 'message' => 'Product updated', 'id' => $id, 'price' => $price, 'stock' => $stock]);
} else {
  http_response_code(500);
  echo json_encode(['success' => false, 'message' => 'Execute failed: ' . $stmt->error]);
}
$stmt->close();
exit;

?>
