<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';

// Strict role-based access control
require_admin();

$admin_id = $_SESSION['admin_id'] ?? null;
if (!$admin_id) {
  $error = 'Admin session invalid. Please log in again.';
}

$success = '';
$error = '';

// ensure CSRF token
ensure_csrf_token();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
  if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
    $error = 'Invalid CSRF token. Please reload the page and try again.';
  } else {
    $current = $_POST['current_password'] ?? '';
    $new = $_POST['new_password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    if (!$current || !$new || !$confirm) {
      $error = 'Please fill all fields.';
    } elseif ($new !== $confirm) {
      $error = 'New password and confirmation do not match.';
    } elseif (strlen($new) < 8) {
      $error = 'New password should be at least 8 characters.';
    } else {
      // Fetch current hash
      $stmt = $mysqli->prepare('SELECT password FROM users WHERE id = ? LIMIT 1');
      if ($stmt) {
        $stmt->bind_param('i', $admin_id);
        $stmt->execute();
        $stmt->bind_result($hash);
        if ($stmt->fetch()) {
          if (password_verify($current, $hash)) {
            $stmt->close();
            $new_hash = password_hash($new, PASSWORD_DEFAULT);
            $upd = $mysqli->prepare('UPDATE users SET password = ? WHERE id = ?');
            $upd->bind_param('si', $new_hash, $admin_id);
            if ($upd->execute()) {
              $success = 'Password updated successfully.';
            } else {
              $error = 'Failed to update password: ' . $upd->error;
            }
            $upd->close();
          } else {
            $error = 'Current password is incorrect.';
            $stmt->close();
          }
        } else {
          $error = 'Admin user not found.';
          $stmt->close();
        }
      } else {
        $error = 'Database error.';
      }
    }
  }
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Change Admin Password</title>
  <link rel="stylesheet" href="<?php echo base_url('/assets/css/design-system.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('/assets/css/style.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('/assets/css/background.css'); ?>">
  <style>
    body { font-family: var(--font-primary); background:var(--color-bg-secondary); padding:20px; }
    .card { max-width:540px; margin:40px auto; background:var(--color-bg-primary); padding:24px; border-radius:var(--radius-md); box-shadow:var(--shadow-lg); }
    h2 { margin-bottom:12px; font-family: var(--font-secondary); color: var(--color-text-primary); }
    .form-group { margin-bottom:14px; }
    label { display:block; margin-bottom:6px; font-weight:600; font-family: var(--font-primary); color: var(--color-text-primary); }
    input[type=password] { width:100%; padding:10px; border:2px solid #e5e7eb; border-radius:var(--radius-md); font-family: var(--font-primary); transition: all var(--transition-base); }
    input[type=password]:focus { outline: none; border-color: var(--color-primary); box-shadow: 0 0 0 3px rgba(26, 115, 232, 0.1); }
    .btn { display:inline-block; padding:10px 16px; border-radius:var(--radius-md); background:linear-gradient(135deg,var(--color-primary) 0%,var(--color-primary-dark) 100%); color:var(--color-text-light); border:none; cursor:pointer; font-weight:700; font-family: var(--font-primary); transition: all var(--transition-base); }
    .btn:hover { transform: translateY(-2px); box-shadow: var(--shadow-lg); }
    .btn[disabled] { opacity:0.6; cursor:not-allowed; }
    .message { background:#d4edda; border:1px solid #c3e6cb; color:#155724; padding:10px; border-radius:var(--radius-md); margin-bottom:12px; }
    .error { background:#f8d7da; border:1px solid #f5c6cb; color:#721c24; padding:10px; border-radius:var(--radius-md); margin-bottom:12px; }
    .nav { text-align:right; margin-bottom:12px; }
    a.btn-link { background:var(--color-text-tertiary); padding:8px 12px; text-decoration:none; color:var(--color-text-light); border-radius:var(--radius-md); margin-left:8px; font-family: var(--font-primary); transition: all var(--transition-base); }
    a.btn-link:hover { background:var(--color-text-secondary); transform: translateY(-2px); box-shadow: var(--shadow-sm); }
  </style>
</head>
<body>
  <div class="card">
    <div class="nav">
      <a href="<?php echo base_url('/admin/products-list.php'); ?>" class="btn-link">← Back to Products</a>
      <a href="<?php echo base_url('/admin/logout.php'); ?>" class="btn-link">Logout</a>
    </div>
    <h2>Change Password</h2>

    <?php if ($success): ?>
      <div class="message"><?= e($success) ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
      <div class="error"><?= e($error) ?></div>
    <?php endif; ?>

    <form method="POST">
      <?= csrf_input() ?>
      <div class="form-group">
        <label for="current_password">Current Password</label>
        <input id="current_password" type="password" name="current_password" required>
      </div>
      <div class="form-group">
        <label for="new_password">New Password</label>
        <input id="new_password" type="password" name="new_password" required>
      </div>
      <div class="form-group">
        <label for="confirm_password">Confirm New Password</label>
        <input id="confirm_password" type="password" name="confirm_password" required>
      </div>

      <button type="submit" name="change_password" class="btn">Change Password</button>
    </form>
  </div>
</body>
</html>
