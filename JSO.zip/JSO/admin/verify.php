﻿<?php
/* admin/verify.php -- safe verification script */

echo "=== ADMIN SYSTEM VERIFICATION ===\n\n";

// 1) Basic files
echo "1. Checking admin files...\n";
$files = [
    'index.php' => 'Login page',
    'products-list.php' => 'Product list/management',
    'add-product.php' => 'Add new product',
    'edit-product.php' => 'Edit product',
    'logout.php' => 'Logout'
];

foreach ($files as $file => $desc) {
    $path = __DIR__ . '/' . $file;
    $status = file_exists($path) ? 'EXISTS' : 'MISSING';
    echo sprintf("  %-50s : %s\n", $file . ' (' . $desc . ')', $status);
}

// 2) Database checks
echo "\n2. Checking database...\n";
require_once __DIR__ . '/../config/db.php';

try {
    $res = $mysqli->query("SELECT COUNT(*) as cnt FROM products");
    $row = $res ? $res->fetch_assoc() : null;
    echo '  ✓ Total products: ' . ($row['cnt'] ?? 'N/A') . "\n";

    $res = $mysqli->query("SELECT COUNT(DISTINCT category_id) as cnt FROM products");
    $row = $res ? $res->fetch_assoc() : null;
    echo '  ✓ Categories with products: ' . ($row['cnt'] ?? 'N/A') . "\n";

    // Check for optional support tables
    $tablesToCheck = ['product_images','returns','delivery_status','orders'];
    foreach ($tablesToCheck as $t) {
        $r = $mysqli->query("SHOW TABLES LIKE '" . $mysqli->real_escape_string($t) . "'");
        $exists = ($r && $r->num_rows > 0) ? 'PRESENT' : 'MISSING';
        echo "  ✓ Table {$t}: {$exists}\n";
    }
} catch (mysqli_sql_exception $e) {
    echo "  ✗ DB error: {$e->getMessage()}\n";
}

// 3) Functions & helpers
echo "\n3. Checking dependencies...\n";
require_once __DIR__ . '/../includes/functions.php';
echo '  ✓ base_url() ' . (function_exists('base_url') ? 'ok' : 'missing') . "\n";
echo '  ✓ e() ' . (function_exists('e') ? 'ok' : 'missing') . "\n";

echo "\n=== ✅ VERIFICATION COMPLETE ===\n";

