<?php
$body_class = 'moving-gradient-bg';
require 'includes/header.php';
$errors = [];
$success = false;

if($_SERVER['REQUEST_METHOD']=='POST'){
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $phone = trim($_POST['phone'] ?? '');
    $dob = $_POST['dob'] ?? '';
    $address = trim($_POST['address'] ?? '');
    
    // Validation
    if(!$name) $errors[] = '❌ Full name is required';
    if(strlen($name) < 3) $errors[] = '❌ Name must be at least 3 characters';
    
    // Email is optional, but if provided must be valid
    if($email && !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = '❌ Email format is invalid';
    
    if(strlen($password) < 6) $errors[] = '❌ Password must be at least 6 characters';
    if($password !== $confirm_password) $errors[] = '❌ Passwords do not match';
    
    if(!preg_match('/^\d{10}$/', $phone)) $errors[] = '❌ Phone must be exactly 10 digits';
    
    if($dob && strtotime($dob) > time()) $errors[] = '❌ Date of birth cannot be in the future';
    
    if(!$address) $errors[] = '❌ Delivery address is required';
    if(strlen($address) < 10) $errors[] = '❌ Address must be at least 10 characters';
    
    // Check if phone already exists (phone is unique)
    if(!count($errors)){
        $check_stmt = $mysqli->prepare("SELECT id FROM users WHERE phone = ?");
        $check_stmt->bind_param('s', $phone);
        $check_stmt->execute();
        $check_stmt->store_result();
        if($check_stmt->num_rows > 0){
            $errors[] = '❌ Phone number already registered. Try login instead!';
        }
        $check_stmt->close();
    }
    
    // Check if email already exists (only if email provided)
    if(!count($errors) && $email){
        $check_stmt = $mysqli->prepare("SELECT id FROM users WHERE email = ?");
        $check_stmt->bind_param('s', $email);
        $check_stmt->execute();
        $check_stmt->store_result();
        if($check_stmt->num_rows > 0){
            $errors[] = '❌ Email already registered. Try login instead!';
        }
        $check_stmt->close();
    }
    
    // Insert if no errors
    if(!count($errors)){
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $mysqli->prepare("INSERT INTO users(name, email, phone, dob, address, password, role) VALUES(?, ?, ?, ?, ?, ?, 'user')");
        $stmt->bind_param('ssssss', $name, $email, $phone, $dob, $address, $hash);
        
        if($stmt->execute()){
          // Do NOT auto-login the user after registration. Redirect to login page
          // to allow user to explicitly login and then view/buy products.
          $success = true;
        } else {
            if(strpos($mysqli->error, 'Duplicate') !== false){
                $errors[] = '❌ This email is already registered';
            } else {
                $errors[] = '❌ Registration error: ' . $mysqli->error;
            }
        }
        $stmt->close();
    }
}
?>
<div style="min-height:70vh;display:flex;align-items:center;justify-content:center;position:relative;padding-top:80px">
  <div style="position:absolute;left:8%;top:10%" class="sparkle-anim" aria-hidden></div>
  <div style="position:absolute;right:12%;bottom:12%" class="sparkle-anim" aria-hidden></div>
  
  <?php if($success): ?>
  <div class="glass-card" style="max-width:540px;width:100%;text-align:center;padding:40px">
    <h2 style="color:var(--gold);margin:0 0 16px 0">✨ Welcome <?=e($name)?>!</h2>
    <p style="color:#555;margin-bottom:24px">Your account has been created successfully. Please login to continue.</p>
    <p style="color:#777;font-size:14px;margin-bottom:24px">Redirecting to login page...</p>
    <a href="<?php echo base_url('/login.php'); ?>" class="btn btn-glow" style="display:inline-block;text-decoration:none">Go to Login</a>
    <script>setTimeout(() => location.href='<?php echo base_url('/login.php'); ?>', 2000);</script>
  </div>
  <?php else: ?>
  <div class="glass-card register-form" style="max-width:540px;width:100%">
    <h2 style="margin-top:0;color:var(--gold-dark);border-bottom:2px solid var(--gold);padding-bottom:12px">💎 Create Your Account</h2>
    
    <?php if($errors): ?>
    <div style="background:rgba(200,50,50,0.1);border-left:4px solid #d32f2f;color:#b71c1c;margin-bottom:16px;padding:12px;border-radius:6px">
      <strong>Please fix the following errors:</strong><br>
      <?=implode('<br>',$errors)?>
    </div>
    <?php endif; ?>
    
    <form method="post" onsubmit="return validateForm(event)" style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
      
      <input class="gold-border" type="text" name="name" id="name" placeholder="Full Name" value="<?=e($_POST['name'] ?? '')?>" required>
      
      <input class="gold-border" type="tel" name="phone" id="phone" placeholder="Phone (10 digits) *" value="<?=e($_POST['phone'] ?? '')?>" pattern="\d{10}" maxlength="10" required>
      
      <input class="gold-border" type="email" name="email" id="email" placeholder="Email (optional)" value="<?=e($_POST['email'] ?? '')?>">
      
      <input class="gold-border" type="date" name="dob" id="dob" value="<?=e($_POST['dob'] ?? '')?>">
      
      <input class="gold-border" type="password" name="password" id="password" placeholder="Password (6+ chars)" required>
      
      <input class="gold-border" type="password" name="confirm_password" id="confirm_password" placeholder="Confirm Password" required>
      
      <div style="grid-column:1/3">
        <textarea class="gold-border" name="address" id="address" placeholder="Delivery Address (min 10 chars)" style="width:100%;min-height:90px;padding:8px;border-radius:6px;font-family:inherit" required><?=e($_POST['address'] ?? '')?></textarea>
      </div>
      
      <div style="grid-column:1/3;display:flex;justify-content:space-between;gap:12px">
        <a href="login.php" style="align-self:center;color:var(--gold);text-decoration:none;font-size:14px">Already have account? Login</a>
        <button class="btn btn-glow" type="submit">Create Account</button>
      </div>
    </form>
  </div>
  <?php endif; ?>
</div>

<script>
function validateForm(e) {
  const phone = document.getElementById('phone').value;
  const password = document.getElementById('password').value;
  const confirm = document.getElementById('confirm_password').value;
  
  if(!/^\d{10}$/.test(phone)) {
    alert('❌ Phone must be exactly 10 digits');
    e.preventDefault();
    return false;
  }
  if(password !== confirm) {
    alert('❌ Passwords do not match');
    e.preventDefault();
    return false;
  }
  return true;
}

// Real-time password match indicator
document.getElementById('confirm_password')?.addEventListener('input', function() {
  const pwd = document.getElementById('password').value;
  const conf = this.value;
  if(conf) {
    this.style.borderColor = pwd === conf ? '#4CAF50' : '#d32f2f';
  }
});
</script>

<?php require 'includes/footer.php';?>