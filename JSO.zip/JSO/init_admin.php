<?php
require 'config/db.php';
require 'includes/functions.php';

$email = 'admin@example.com';
$passHash = password_hash('admin123', PASSWORD_DEFAULT);
$role = 'admin';
$name = 'Admin';
$phone = '0000000000';

// Upsert admin without violating FK constraints (do not hard-delete users).
// Find any existing admin user (by role). If found, update to ensure it has correct email/password; otherwise insert.
$stmt = $mysqli->prepare("SELECT id FROM users WHERE role='admin' LIMIT 1");
$stmt->execute();
$stmt->bind_result($uid);
$exists = $stmt->fetch();
$stmt->close();

if ($exists && $uid) {
    // Update the existing admin record to ensure email/password are set as expected
    $stmt = $mysqli->prepare("UPDATE users SET name=?, email=?, phone=?, password=? WHERE id=?");
    $stmt->bind_param('ssssi', $name, $email, $phone, $passHash, $uid);
    $stmt->execute();
    $stmt->close();
    $message = 'Admin user updated';
} else {
    // Insert new admin
    $stmt = $mysqli->prepare("INSERT INTO users (name, email, phone, password, role) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param('sssss', $name, $email, $phone, $passHash, $role);
    $stmt->execute();
    $stmt->close();
    $message = 'Admin user created';
}

echo "<h2 style='color:#cda34f'>{$message}</h2>";
echo "<p style='color:#fff'>Email: admin@example.com</p>";
echo "<p style='color:#fff'>Password: admin123</p>";
echo "<p><a href='" . base_url('/admin/login.php') . "' style='color:#cda34f;text-decoration:underline'>Go to Admin Login</a></p>";
echo "<hr style='margin:20px 0'>";
echo "<p style='color:#999'>After logging in, you can add more admins from the dashboard (Add Admin link).</p>";
?>
<!doctype html><html><head><meta charset="utf-8"><title>Admin Setup</title><link rel="stylesheet" href="<?php echo base_url('/assets/css/style.css'); ?>"><link rel="stylesheet" href="<?php echo base_url('/assets/css/background.css'); ?>"></head><body class="dark-elegant-bg">
</body></html>
