<?php
session_start();
require 'config/db.php';
require 'includes/functions.php';

require_login();

$uid = $_SESSION['user_id'];
$error = '';
$body_class = 'diamond-shine-bg';

// Get user info
$stmt = $mysqli->prepare("SELECT * FROM users WHERE id=?");
$stmt->bind_param('i', $uid);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Get cart items
$stmt = $mysqli->prepare("SELECT c.id, p.id as product_id, p.name, p.price, c.quantity FROM cart c JOIN products p ON p.id=c.product_id WHERE c.user_id=?");
$stmt->bind_param('i', $uid);
$stmt->execute();
$items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

  if (empty($items)) {
  header('Location: ' . base_url('/cart.php'));
  exit;
}

$subtotal = 0;
foreach ($items as $item) {
    $subtotal += $item['price'] * $item['quantity'];
}

$discount = 0;
if (isset($_SESSION['applied_coupon'])) {
    $coupon = $_SESSION['applied_coupon'];
    if ($coupon['discount_type'] === 'percentage') {
        $discount = ($subtotal * $coupon['discount_value']) / 100;
    } else {
        $discount = $coupon['discount_value'];
    }
}

$shipping = 50;
$total = $subtotal - $discount + $shipping;

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $city = trim($_POST['city'] ?? '');
    $postal_code = trim($_POST['postal_code'] ?? '');
    $state = trim($_POST['state'] ?? '');
    $payment_method = $_POST['payment_method'] ?? 'card';

    if (!$name || !$email || !$phone || !$address || !$city || !$postal_code) {
        $error = 'Please fill in all fields';
    } else {
        // Create order (align with orders table schema)
        $order_date = date('Y-m-d H:i:s');
        $stmt = $mysqli->prepare("INSERT INTO orders(user_id, total, payment_mode, pincode, address, status, payment_status, order_date) VALUES(?, ?, ?, ?, ?, 'Pending', 'Pending', ?)");
        $stmt->bind_param('idssss', $uid, $total, $payment_method, $postal_code, $address, $order_date);
        
        if ($stmt->execute()) {
            $order_id = $stmt->insert_id;
            $stmt->close();

            // Add order items
            foreach ($items as $item) {
                $stmt = $mysqli->prepare("INSERT INTO order_items(order_id, product_id, quantity, price) VALUES(?, ?, ?, ?)");
                $stmt->bind_param('iiii', $order_id, $item['product_id'], $item['quantity'], $item['price']);
                $stmt->execute();
                $stmt->close();
            }

            // Clear cart
            $stmt = $mysqli->prepare("DELETE FROM cart WHERE user_id=?");
            $stmt->bind_param('i', $uid);
            $stmt->execute();
            $stmt->close();

            // Redirect based on payment method
            $_SESSION['current_order_id'] = $order_id;
            $_SESSION['order_total'] = $total;
            
            if ($payment_method === 'cod') {
              // Mark order for cash on delivery and generate a tracking placeholder.
              $tracking_id = 'COD-' . strtoupper(substr(uniqid(), -7));
              try {
                $stmt = $mysqli->prepare("UPDATE orders SET payment_status='cash_on_delivery', status='processing', tracking_id=? WHERE id=?");
                if ($stmt) {
                  $stmt->bind_param('si', $tracking_id, $order_id);
                  $stmt->execute();
                  $stmt->close();
                }
              } catch (mysqli_sql_exception $e) {
                error_log('Failed to UPDATE order tracking: ' . $e->getMessage());
              }

              // Record delivery timeline entry for COD orders.
              try {
                $stmt = $mysqli->prepare("INSERT INTO delivery_status(order_id, status, update_time) VALUES(?, 'cod_confirmed', NOW())");
                if ($stmt) {
                  $stmt->bind_param('i', $order_id);
                  $stmt->execute();
                  $stmt->close();
                }
              } catch (mysqli_sql_exception $e) {
                error_log('Failed to INSERT delivery_status: ' . $e->getMessage());
              }
              
              unset($_SESSION['current_order_id']);
              unset($_SESSION['order_total']);
              unset($_SESSION['applied_coupon']);
              
              header('Location: ' . base_url('/payment_success.php?order_id=' . $order_id . '&method=cod'));
            } else {
              header('Location: ' . base_url('/payment.php'));
            }
            exit;
        } else {
            $error = 'Failed to create order. Please try again.';
        }
    }
}

require 'includes/header.php';
?>

<style>
.checkout-container {
  max-width: 1200px;
  margin: 40px auto;
  padding: 20px;
}

.checkout-header {
  font-size: 28px;
  font-weight: 700;
  color: #333;
  margin-bottom: 40px;
}

.checkout-content {
  display: grid;
  grid-template-columns: 1fr 350px;
  gap: 30px;
}

.checkout-form {
  background: white;
  border-radius: 8px;
  padding: 30px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.08);
}

.form-section {
  margin-bottom: 30px;
}

.form-section-title {
  font-size: 16px;
  font-weight: 700;
  color: #333;
  margin-bottom: 20px;
  padding-bottom: 10px;
  border-bottom: 2px solid #f0f0f0;
}

.form-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 20px;
  margin-bottom: 20px;
}

.form-row.full {
  grid-template-columns: 1fr;
}

.form-group {
  display: flex;
  flex-direction: column;
}

.form-group label {
  font-weight: 600;
  color: #333;
  margin-bottom: 8px;
  font-size: 14px;
}

.form-group input,
.form-group select,
.form-group textarea {
  padding: 12px;
  border: 1px solid #ddd;
  border-radius: 6px;
  font-size: 14px;
  font-family: inherit;
  transition: all 0.2s;
}

.form-group input:focus,
.form-group select:focus,
.form-group textarea:focus {
  outline: none;
  border-color: #cda34f;
  box-shadow: 0 0 0 3px rgba(205,163,79,0.1);
}

.payment-methods {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 15px;
}

.payment-option {
  padding: 15px;
  border: 2px solid #ddd;
  border-radius: 6px;
  cursor: pointer;
  text-align: center;
  transition: all 0.2s;
}

.payment-option input[type="radio"] {
  display: none;
}

.payment-option input[type="radio"]:checked + label {
  display: none;
}

.payment-option input[type="radio"]:checked ~ .payment-label {
  display: block;
}

.payment-option:has(input[type="radio"]:checked) {
  border-color: #cda34f;
  background: rgba(205,163,79,0.05);
}

.payment-option label {
  display: block;
  font-weight: 600;
  color: #333;
  cursor: pointer;
}

.payment-label {
  display: none;
  font-weight: 700;
  color: #cda34f;
}

.error-msg {
  padding: 12px;
  background: #f8d7da;
  color: #721c24;
  border-radius: 6px;
  margin-bottom: 20px;
  border-left: 4px solid #f44336;
}

.submit-btn {
  width: 100%;
  padding: 16px;
  background: linear-gradient(180deg, #cda34f, #b0852b);
  color: white;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-weight: 700;
  font-size: 16px;
  transition: all 0.2s;
}

.submit-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 18px rgba(205,163,79,0.3);
}

.order-summary {
  background: white;
  border-radius: 8px;
  padding: 20px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.08);
  position: sticky;
  top: 100px;
}

.order-title {
  font-weight: 700;
  color: #333;
  margin-bottom: 20px;
  font-size: 16px;
}

.order-items {
  margin-bottom: 20px;
  max-height: 300px;
  overflow-y: auto;
}

.order-item {
  display: flex;
  justify-content: space-between;
  margin-bottom: 12px;
  padding-bottom: 12px;
  border-bottom: 1px solid #eee;
  font-size: 14px;
  color: #666;
}

.order-item-name {
  color: #333;
  font-weight: 500;
}

.order-item-qty {
  color: #999;
  font-size: 12px;
}

.summary-row {
  display: flex;
  justify-content: space-between;
  margin-bottom: 10px;
  padding-bottom: 10px;
  border-bottom: 1px solid #eee;
  color: #666;
  font-size: 14px;
}

.summary-row.total {
  border-bottom: none;
  margin-top: 15px;
  font-weight: 700;
  font-size: 16px;
  color: #333;
}

.summary-row.total .amount {
  color: #cda34f;
  font-size: 18px;
}

@media (max-width: 768px) {
  .checkout-content {
    grid-template-columns: 1fr;
  }
  
  .order-summary {
    position: static;
  }
  
  .form-row {
    grid-template-columns: 1fr;
  }
  
  .payment-methods {
    grid-template-columns: 1fr;
  }
}
</style>

<div class="checkout-container">
  <h1 class="checkout-header">🛍️ Checkout</h1>

  <?php if ($error): ?>
    <div class="error-msg"><?php echo e($error); ?></div>
  <?php endif; ?>

  <div class="checkout-content">
    <!-- CHECKOUT FORM -->
    <form method="POST" class="checkout-form">
      <!-- DELIVERY INFORMATION -->
      <div class="form-section">
        <div class="form-section-title">📍 Delivery Information</div>
        
        <div class="form-row">
          <div class="form-group">
            <label for="name">Full Name</label>
            <input type="text" id="name" name="name" value="<?php echo e($user['name']); ?>" required>
          </div>
          <div class="form-group">
            <label for="phone">Phone Number</label>
            <input type="text" id="phone" name="phone" value="<?php echo e($user['phone'] ?? ''); ?>" required>
          </div>
        </div>

        <div class="form-row full">
          <div class="form-group">
            <label for="email">Email Address</label>
            <input type="email" id="email" name="email" value="<?php echo e($user['email']); ?>" required>
          </div>
        </div>

        <div class="form-row full">
          <div class="form-group">
            <label for="address">Delivery Address</label>
            <textarea id="address" name="address" rows="3" required><?php echo e($user['address'] ?? ''); ?></textarea>
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label for="city">City</label>
            <input type="text" id="city" name="city" value="<?php echo e($user['city'] ?? ''); ?>" required>
          </div>
          <div class="form-group">
            <label for="state">State</label>
            <input type="text" id="state" name="state" value="<?php echo e($user['state'] ?? ''); ?>" required>
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label for="postal_code">Postal Code</label>
            <input type="text" id="postal_code" name="postal_code" value="<?php echo e($user['postal_code'] ?? ''); ?>" required>
          </div>
        </div>
      </div>

      <!-- PAYMENT METHOD -->
      <div class="form-section">
        <div class="form-section-title">💳 Payment Method</div>
        
        <div class="payment-methods">
          <div class="payment-option">
            <input type="radio" id="card" name="payment_method" value="card" checked>
            <label for="card">💳 Credit/Debit Card</label>
            <div class="payment-label">✓ Card</div>
          </div>
          
          <div class="payment-option">
            <input type="radio" id="upi" name="payment_method" value="upi">
            <label for="upi">📱 UPI</label>
            <div class="payment-label">✓ UPI</div>
          </div>
          
          <div class="payment-option">
            <input type="radio" id="netbanking" name="payment_method" value="netbanking">
            <label for="netbanking">🏦 Net Banking</label>
            <div class="payment-label">✓ Net Banking</div>
          </div>
          
          <div class="payment-option">
            <input type="radio" id="wallet" name="payment_method" value="wallet">
            <label for="wallet">💰 Wallet</label>
            <div class="payment-label">✓ Wallet</div>
          </div>

          <div class="payment-option">
            <input type="radio" id="cod" name="payment_method" value="cod">
            <label for="cod">💵 Cash on Delivery</label>
            <div class="payment-label">✓ Cash on Delivery</div>
          </div>
        </div>
      </div>

      <button type="submit" class="submit-btn">Proceed to Payment →</button>
    </form>

    <!-- ORDER SUMMARY -->
    <div class="order-summary">
      <div class="order-title">Order Summary</div>
      
      <div class="order-items">
        <?php foreach ($items as $item): ?>
          <div class="order-item">
            <div>
              <div class="order-item-name"><?php echo e($item['name']); ?></div>
              <div class="order-item-qty">Qty: <?php echo $item['quantity']; ?></div>
            </div>
            <div>₹<?php echo number_format($item['price'] * $item['quantity']); ?></div>
          </div>
        <?php endforeach; ?>
      </div>

      <div class="summary-row">
        <span>Subtotal</span>
        <span>₹<?php echo number_format($subtotal); ?></span>
      </div>

      <?php if ($discount > 0): ?>
        <div class="summary-row" style="color: #4caf50;">
          <span>Discount</span>
          <span>-₹<?php echo number_format($discount); ?></span>
        </div>
      <?php endif; ?>

      <div class="summary-row">
        <span>Shipping</span>
        <span>₹<?php echo number_format($shipping); ?></span>
      </div>

      <div class="summary-row total">
        <span>Total</span>
        <span class="amount">₹<?php echo number_format($total); ?></span>
      </div>
    </div>
  </div>
</div>

<?php require 'includes/footer.php'; ?>
