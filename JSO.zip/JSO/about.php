<?php
$body_class = 'gold-glitter-bg';
require 'includes/header.php';
?>

<style>
.info-page {
  max-width: 900px;
  margin: 40px auto;
  padding: 20px;
}
.info-section {
  background: white;
  border-radius: 10px;
  padding: 20px 24px;
  margin-bottom: 20px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.06);
}
.info-section h2 {
  margin: 0 0 10px 0;
  font-size: 22px;
  color: #333;
}
.info-section p {
  margin: 0 0 6px 0;
  color: #555;
  line-height: 1.6;
  font-size: 14px;
}
</style>

<div class="info-page">
  <div class="info-section" id="story">
    <h2>Our Story</h2>
    <p>VMD Jewels is crafted as a premium jewellery experience for modern shoppers, blending elegant imitation pieces with an authentic guarantee experience in the UI.</p>
    <p>This demo store showcases a complete end‑to‑end shopping journey: discovery, purchase, delivery tracking and returns.</p>
  </div>

  <div class="info-section" id="craftsmanship">
    <h2>Craftsmanship</h2>
    <p>Products in the catalog are organised into Gold, Diamond, Platinum, Gemstone and Silver categories, with detailed product pages, multiple images and carefully tuned pricing.</p>
    <p>The layout is optimised for clarity and focus on each piece, mimicking a real jewellery catalogue.</p>
  </div>

  <div class="info-section" id="quality">
    <h2>Quality Assurance</h2>
    <p>The application simulates a robust ordering system with proper order history, tracking, returns and admin approvals — reflecting the checks a real jewellery business would maintain.</p>
    <p>Every feature is tested to avoid errors so that the browsing and checkout experience feels reliable.</p>
  </div>

  <div class="info-section" id="awards">
    <h2>Awards</h2>
    <p>This section is a placeholder where, in a production deployment, you would highlight brand awards, certifications and customer trust badges.</p>
  </div>
</div>

<?php require 'includes/footer.php'; ?>


