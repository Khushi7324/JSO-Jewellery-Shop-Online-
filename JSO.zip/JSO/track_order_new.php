<?php
session_start();
require 'config/db.php';
require 'includes/functions.php';

require_login();

$user_id = $_SESSION['user_id'];
$order_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Get order
$stmt = $mysqli->prepare("SELECT * FROM orders WHERE id=? AND user_id=?");
$stmt->bind_param('ii', $order_id, $user_id);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$order) {
    header('Location: ' . base_url('/my_orders.php'));
    exit;
}

// Get order items
$stmt = $mysqli->prepare("SELECT oi.*, p.name, p.price, p.image_url FROM order_items oi JOIN products p ON oi.product_id=p.id WHERE oi.order_id=?");
$stmt->bind_param('i', $order_id);
$stmt->execute();
$items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Get delivery status history
$stmt = $mysqli->prepare("SELECT * FROM delivery_status WHERE order_id=? ORDER BY update_time ASC");
$stmt->bind_param('i', $order_id);
$stmt->execute();
$delivery_history = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Get latest status
$latest_status = !empty($delivery_history) ? end($delivery_history)['status'] : $order['status'];

// Status mapping
$status_map = [
    'Pending' => ['step' => 1, 'label' => 'Order Placed', 'icon' => '📋'],
    'Processing' => ['step' => 2, 'label' => 'Processing', 'icon' => '⚙️'],
    'Packing' => ['step' => 2, 'label' => 'Processing', 'icon' => '⚙️'],
    'Shipped' => ['step' => 3, 'label' => 'Shipped', 'icon' => '📦'],
    'Delivered' => ['step' => 4, 'label' => 'Delivered', 'icon' => '✅'],
    'Completed' => ['step' => 4, 'label' => 'Delivered', 'icon' => '✅']
];

$current_status = $status_map[$latest_status] ?? $status_map['Pending'];

// Calculate expected delivery (3-5 business days from order date)
$order_date = new DateTime($order['order_date']);
$expected_delivery = clone $order_date;
$expected_delivery->add(new DateInterval('P5D'));

// Check if return is available (within 7 days of delivery)
$return_available = false;
if ($latest_status === 'Delivered' || $latest_status === 'Completed') {
    $deliveredEntry = null;
    foreach($delivery_history as $entry) {
        if($entry['status'] === 'Completed' || $entry['status'] === 'Delivered') {
            $deliveredEntry = $entry;
            break;
        }
    }
    if ($deliveredEntry) {
        $deliveryDate = new DateTime($deliveredEntry['update_time']);
        $today = new DateTime();
        $daysSinceDelivery = $today->diff($deliveryDate)->days;
        $return_available = $daysSinceDelivery <= 7;
    }
}

$body_class = 'light-bg';
require 'includes/header.php';
?>

<style>
.tracking-container {
    max-width: 1000px;
    margin: 20px auto;
    padding: 0 15px;
    font-family: 'Amazon Ember', Arial, sans-serif;
}

.tracking-header {
    background: linear-gradient(135deg, #ff9800 0%, #f57c00 100%);
    color: white;
    padding: 30px;
    border-radius: 12px;
    margin-bottom: 25px;
    box-shadow: 0 4px 15px rgba(255, 152, 0, 0.2);
}

.tracking-header h1 {
    margin: 0 0 10px 0;
    font-size: 28px;
    font-weight: 400;
}

.current-status {
    font-size: 20px;
    margin-bottom: 15px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.expected-delivery {
    font-size: 16px;
    opacity: 0.95;
}

.expected-delivery strong {
    font-size: 18px;
    font-weight: 600;
}

.timeline-container {
    background: white;
    padding: 30px;
    border-radius: 12px;
    margin-bottom: 25px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.08);
}

.timeline {
    display: flex;
    justify-content: space-between;
    position: relative;
    margin-bottom: 20px;
}

.timeline::before {
    content: '';
    position: absolute;
    top: 20px;
    left: 0;
    right: 0;
    height: 2px;
    background: #e0e0e0;
    z-index: 1;
}

.timeline-progress {
    position: absolute;
    top: 20px;
    left: 0;
    height: 2px;
    background: #ff9800;
    z-index: 2;
    transition: width 0.5s ease;
}

.timeline-step {
    flex: 1;
    text-align: center;
    position: relative;
    z-index: 3;
}

.timeline-icon {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: #f5f5f5;
    border: 3px solid #e0e0e0;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 10px;
    font-size: 18px;
    transition: all 0.3s ease;
}

.timeline-step.completed .timeline-icon {
    background: #4caf50;
    border-color: #4caf50;
    color: white;
}

.timeline-step.active .timeline-icon {
    background: #ff9800;
    border-color: #ff9800;
    color: white;
    box-shadow: 0 0 0 6px rgba(255, 152, 0, 0.1);
}

.timeline-label {
    font-size: 14px;
    color: #666;
    font-weight: 500;
}

.timeline-step.active .timeline-label {
    color: #ff9800;
    font-weight: 600;
}

.timeline-step.completed .timeline-label {
    color: #4caf50;
}

.info-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 25px;
    margin-bottom: 25px;
}

.info-box {
    background: white;
    padding: 25px;
    border-radius: 12px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.08);
}

.info-box h3 {
    margin: 0 0 20px 0;
    color: #333;
    font-size: 18px;
    font-weight: 600;
    border-bottom: 2px solid #ff9800;
    padding-bottom: 10px;
}

.address-info p {
    margin: 8px 0;
    color: #555;
    line-height: 1.5;
}

.address-info .name {
    font-weight: 600;
    color: #333;
    font-size: 16px;
}

.order-summary {
    display: flex;
    gap: 15px;
    padding: 15px 0;
    border-bottom: 1px solid #eee;
}

.order-summary:last-child {
    border-bottom: none;
}

.product-image {
    width: 80px;
    height: 80px;
    object-fit: cover;
    border-radius: 8px;
    border: 1px solid #eee;
}

.product-details {
    flex: 1;
}

.product-name {
    font-weight: 600;
    color: #333;
    margin-bottom: 5px;
}

.product-qty {
    color: #666;
    font-size: 14px;
}

.product-price {
    font-weight: 600;
    color: #ff9800;
    font-size: 18px;
}

.dates-section {
    background: white;
    padding: 25px;
    border-radius: 12px;
    margin-bottom: 25px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.08);
}

.dates-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 20px;
}

.date-item {
    padding: 15px;
    background: #f8f9fa;
    border-radius: 8px;
    border-left: 4px solid #ff9800;
}

.date-label {
    font-size: 12px;
    color: #666;
    text-transform: uppercase;
    margin-bottom: 5px;
    font-weight: 600;
}

.date-value {
    font-size: 14px;
    color: #333;
    font-weight: 500;
}

.tracking-activity {
    background: white;
    border-radius: 12px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.08);
    overflow: hidden;
}

.activity-header {
    padding: 20px 25px;
    background: #f8f9fa;
    border-bottom: 1px solid #e0e0e0;
    display: flex;
    justify-content: space-between;
    align-items: center;
    cursor: pointer;
}

.activity-header h3 {
    margin: 0;
    color: #333;
    font-size: 18px;
    font-weight: 600;
}

.toggle-icon {
    font-size: 20px;
    color: #666;
    transition: transform 0.3s ease;
}

.activity-header.collapsed .toggle-icon {
    transform: rotate(-90deg);
}

.activity-content {
    max-height: 500px;
    overflow-y: auto;
    transition: max-height 0.3s ease;
}

.activity-content.collapsed {
    max-height: 0;
}

.activity-table {
    width: 100%;
    border-collapse: collapse;
}

.activity-table th {
    background: #f8f9fa;
    padding: 15px;
    text-align: left;
    font-weight: 600;
    color: #333;
    font-size: 14px;
    border-bottom: 2px solid #e0e0e0;
}

.activity-table td {
    padding: 15px;
    border-bottom: 1px solid #f0f0f0;
    font-size: 14px;
    color: #555;
}

.activity-table tr:last-child td {
    border-bottom: none;
}

.location-badge {
    display: inline-block;
    padding: 4px 8px;
    background: #e3f2fd;
    color: #1976d2;
    border-radius: 4px;
    font-size: 12px;
    font-weight: 500;
}

.last-updated {
    text-align: center;
    color: #666;
    font-size: 13px;
    margin-top: 20px;
    font-style: italic;
}

.return-section {
    text-align: center;
    margin-top: 25px;
}

.btn-return {
    background: #ff9800;
    color: white;
    padding: 12px 30px;
    border: none;
    border-radius: 6px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    text-decoration: none;
    display: inline-block;
    transition: all 0.3s ease;
}

.btn-return:hover {
    background: #f57c00;
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(255, 152, 0, 0.3);
}

@media (max-width: 768px) {
    .info-grid {
        grid-template-columns: 1fr;
    }
    
    .timeline {
        flex-direction: column;
        gap: 20px;
    }
    
    .timeline::before {
        top: 0;
        bottom: 0;
        left: 20px;
        width: 2px;
        height: auto;
    }
    
    .timeline-progress {
        top: 0;
        left: 20px;
        width: 2px;
        height: auto;
    }
    
    .timeline-step {
        display: flex;
        align-items: center;
        text-align: left;
    }
    
    .timeline-icon {
        margin: 0 15px 0 0;
    }
    
    .dates-grid {
        grid-template-columns: 1fr;
    }
}
</style>

<div class="tracking-container">
    <!-- Header Section -->
    <div class="tracking-header">
        <h1>📦 Shipment Tracking</h1>
        <div class="current-status">
            <span><?= $current_status['icon'] ?></span>
            <span><?= $current_status['label'] ?></span>
        </div>
        <div class="expected-delivery">
            Expected Delivery: <strong><?= $expected_delivery->format('M d, Y') ?></strong>
        </div>
    </div>

    <!-- Status Timeline -->
    <div class="timeline-container">
        <div class="timeline">
            <div class="timeline-progress" style="width: <?= (($current_status['step'] - 1) / 3) * 100 ?>%"></div>
            
            <div class="timeline-step <?= $current_status['step'] >= 1 ? 'completed' : '' ?>">
                <div class="timeline-icon">📋</div>
                <div class="timeline-label">Order Placed</div>
            </div>
            
            <div class="timeline-step <?= $current_status['step'] >= 2 ? 'completed' : '' ?> <?= $current_status['step'] == 2 ? 'active' : '' ?>">
                <div class="timeline-icon">⚙️</div>
                <div class="timeline-label">Processing</div>
            </div>
            
            <div class="timeline-step <?= $current_status['step'] >= 3 ? 'completed' : '' ?> <?= $current_status['step'] == 3 ? 'active' : '' ?>">
                <div class="timeline-icon">📦</div>
                <div class="timeline-label">Shipped</div>
            </div>
            
            <div class="timeline-step <?= $current_status['step'] >= 4 ? 'completed' : '' ?> <?= $current_status['step'] == 4 ? 'active' : '' ?>">
                <div class="timeline-icon">✅</div>
                <div class="timeline-label">Delivered</div>
            </div>
        </div>
    </div>

    <!-- Info Grid -->
    <div class="info-grid">
        <!-- Customer Address -->
        <div class="info-box">
            <h3>📍 Delivery Address</h3>
            <div class="address-info">
                <p class="name"><?= htmlspecialchars($order['name'] ?? 'Customer Name') ?></p>
                <p><?= htmlspecialchars($order['address'] ?? 'Delivery Address') ?></p>
                <p><?= htmlspecialchars($order['city'] ?? 'City') ?>, <?= htmlspecialchars($order['state'] ?? 'State') ?> - <?= htmlspecialchars($order['pincode'] ?? 'PIN Code') ?></p>
                <p>📱 <?= htmlspecialchars($order['phone'] ?? 'Phone Number') ?></p>
            </div>
        </div>

        <!-- Order Summary -->
        <div class="info-box">
            <h3>📋 Order Summary</h3>
            <p style="margin-bottom: 15px;"><strong>Order ID:</strong> #<?= $order_id ?></p>
            <?php foreach ($items as $item): ?>
                <div class="order-summary">
                    <img src="<?= htmlspecialchars($item['image_url'] ?? (base_url('/assets/images/product-placeholder.jpg'))) ?>" alt="<?= htmlspecialchars($item['name']) ?>" class="product-image">
                    <div class="product-details">
                        <div class="product-name"><?= htmlspecialchars($item['name']) ?></div>
                        <div class="product-qty">Quantity: <?= $item['quantity'] ?></div>
                    </div>
                    <div class="product-price">₹<?= number_format($item['price'] * $item['quantity'], 2) ?></div>
                </div>
            <?php endforeach; ?>
            <div style="margin-top: 15px; padding-top: 15px; border-top: 2px solid #ff9800;">
                <strong>Total: ₹<?= number_format($order['total'], 2) ?></strong>
            </div>
        </div>
    </div>

    <!-- Dates Section -->
    <div class="dates-section">
        <h3 style="margin: 0 0 20px 0; color: #333; font-size: 18px; font-weight: 600;">📅 Important Dates</h3>
        <div class="dates-grid">
            <div class="date-item">
                <div class="date-label">Order Placed</div>
                <div class="date-value"><?= date('M d, Y h:i A', strtotime($order['order_date'])) ?></div>
            </div>
            <div class="date-item">
                <div class="date-label">Payment Confirmed</div>
                <div class="date-value"><?= date('M d, Y h:i A', strtotime($order['order_date'])) ?></div>
            </div>
            <?php if (!empty($delivery_history)): ?>
                <?php foreach ($delivery_history as $activity): ?>
                    <div class="date-item">
                        <div class="date-label"><?= htmlspecialchars($activity['status']) ?></div>
                        <div class="date-value"><?= date('M d, Y h:i A', strtotime($activity['update_time'])) ?></div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <!-- Tracking Activity -->
    <div class="tracking-activity">
        <div class="activity-header" onclick="toggleActivity()">
            <h3>📊 Tracking Activity</h3>
            <span class="toggle-icon">▼</span>
        </div>
        <div class="activity-content" id="activityContent">
            <table class="activity-table">
                <thead>
                    <tr>
                        <th>Date & Time</th>
                        <th>Location</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><?= date('M d, Y h:i A', strtotime($order['order_date'])) ?></td>
                        <td><span class="location-badge">Online</span></td>
                        <td>Order placed successfully</td>
                    </tr>
                    <?php if (!empty($delivery_history)): ?>
                        <?php $activities = array_reverse($delivery_history); ?>
                        <?php foreach ($activities as $activity): ?>
                            <tr>
                                <td><?= date('M d, Y h:i A', strtotime($activity['update_time'])) ?></td>
                                <td><span class="location-badge">Warehouse</span></td>
                                <td><?= htmlspecialchars($activity['status']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Return Request Button -->
    <?php if ($return_available): ?>
        <div class="return-section">
            <a href="<?php echo base_url('/return_product.php?id=' . $order_id); ?>" class="btn-return">
                ↩️ Request Return
            </a>
        </div>
    <?php endif; ?>

    <!-- Last Updated -->
    <div class="last-updated">
        Last updated: <?= !empty($delivery_history) ? date('M d, Y h:i A', strtotime(end($delivery_history)['update_time'])) : date('M d, Y h:i A', strtotime($order['order_date'])) ?>
    </div>
</div>

<script>
function toggleActivity() {
    const header = document.querySelector('.activity-header');
    const content = document.getElementById('activityContent');
    
    header.classList.toggle('collapsed');
    content.classList.toggle('collapsed');
}

// Auto-refresh every 5 minutes
setInterval(() => {
    location.reload();
}, 300000);
</script>

<?php require 'includes/footer.php'; ?>
