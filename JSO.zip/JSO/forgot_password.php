<?php
session_start();
require 'config/db.php';
require 'includes/functions.php';

$body_class = 'gold-glitter-bg';

$message = '';
$error = '';
$step = isset($_GET['step']) ? $_GET['step'] : 1;

// Step 1: Get phone/email
if ($_SERVER['REQUEST_METHOD'] == 'POST' && $step == 1) {
    $phone_email = trim($_POST['phone_email'] ?? '');
    
    if (empty($phone_email)) {
        $error = 'Please enter phone number or email';
    } else {
        // Check if user exists
        $stmt = $mysqli->prepare("SELECT id, phone, email, name FROM users WHERE phone=? OR email=?");
        $stmt->bind_param('ss', $phone_email, $phone_email);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        if (!$user) {
            $error = 'User not found';
        } else {
            // Generate reset token
            $token = bin2hex(random_bytes(32));
            $expiry = date('Y-m-d H:i:s', strtotime('+1 hour'));
            
            $stmt = $mysqli->prepare("UPDATE users SET reset_token=?, reset_expiry=? WHERE id=?");
            $stmt->bind_param('ssi', $token, $expiry, $user['id']);
            $stmt->execute();
            $stmt->close();
            
            $_SESSION['reset_user_id'] = $user['id'];
            $_SESSION['reset_phone'] = $user['phone'];
            $_SESSION['reset_email'] = $user['email'];
            $_SESSION['reset_name'] = $user['name'];
            
            // Use dynamic base for redirect
            header('Location: ' . route_url('/forgot_password.php?step=2'));
            exit;
        }
    }
}

// Step 2: Verify OTP (simulated - user gets SMS/Email with code)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && $step == 2) {
    $otp = trim($_POST['otp'] ?? '');
    
    if (empty($otp)) {
        $error = 'Please enter OTP';
    } elseif ($otp !== '123456') {  // Demo OTP
        $error = 'Invalid OTP. Demo OTP: 123456';
    } else {
        $_SESSION['otp_verified'] = true;
        header('Location: ' . route_url('/forgot_password.php?step=3'));
        exit;
    }
}

// Step 3: Reset password
if ($_SERVER['REQUEST_METHOD'] == 'POST' && $step == 3) {
    if (!isset($_SESSION['otp_verified']) || !$_SESSION['otp_verified']) {
        $error = 'Please verify OTP first';
    } else {
        $password = $_POST['password'] ?? '';
        $confirm = $_POST['confirm_password'] ?? '';
        
        if (empty($password) || empty($confirm)) {
            $error = 'Please fill all fields';
        } elseif (strlen($password) < 6) {
            $error = 'Password must be at least 6 characters';
        } elseif ($password !== $confirm) {
            $error = 'Passwords do not match';
        } else {
            $hashed = password_hash($password, PASSWORD_BCRYPT);
            $user_id = $_SESSION['reset_user_id'];
            
            $stmt = $mysqli->prepare("UPDATE users SET password=?, reset_token=NULL, reset_expiry=NULL WHERE id=?");
            $stmt->bind_param('si', $hashed, $user_id);
            $stmt->execute();
            $stmt->close();
            
            unset($_SESSION['reset_user_id']);
            unset($_SESSION['reset_phone']);
            unset($_SESSION['reset_email']);
            unset($_SESSION['reset_name']);
            unset($_SESSION['otp_verified']);
            
            $message = 'Password reset successfully! Redirecting to login...';
            header('Refresh: 2; url=' . route_url('/login.php'));
        }
    }
}

require 'includes/header.php';
?>

<style>
.forgot-container {
  max-width: 400px;
  margin: 40px auto;
  padding: 30px;
  background: white;
  border-radius: 10px;
  box-shadow: 0 4px 20px rgba(0,0,0,0.1);
  border-left: 4px solid #cda34f;
}

.forgot-title {
  text-align: center;
  color: #333;
  margin-bottom: 30px;
  font-size: 24px;
  font-weight: 700;
}

.step-indicator {
  display: flex;
  justify-content: space-between;
  margin-bottom: 30px;
  font-size: 12px;
  color: #999;
}

.step-indicator .step {
  text-align: center;
  flex: 1;
}

.step-indicator .step.active {
  color: #cda34f;
  font-weight: 700;
}

.step-indicator .step.completed {
  color: #4caf50;
}

.form-group {
  margin-bottom: 20px;
}

.form-group label {
  display: block;
  margin-bottom: 8px;
  color: #333;
  font-weight: 600;
  font-size: 14px;
}

.form-group input,
.form-group textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ddd;
  border-radius: 6px;
  font-size: 14px;
  font-family: inherit;
  transition: border 0.2s;
  box-sizing: border-box;
}

.form-group input:focus,
.form-group textarea:focus {
  outline: none;
  border-color: #cda34f;
  box-shadow: 0 0 0 3px rgba(205,163,79,0.1);
}

.error {
  color: #d32f2f;
  font-size: 13px;
  margin-bottom: 20px;
  padding: 10px;
  background: #ffebee;
  border-radius: 6px;
  border-left: 3px solid #d32f2f;
}

.success {
  color: #388e3c;
  font-size: 13px;
  margin-bottom: 20px;
  padding: 10px;
  background: #e8f5e9;
  border-radius: 6px;
  border-left: 3px solid #388e3c;
}

.info {
  color: #1976d2;
  font-size: 13px;
  margin-bottom: 20px;
  padding: 10px;
  background: #e3f2fd;
  border-radius: 6px;
  border-left: 3px solid #1976d2;
}

button {
  width: 100%;
  padding: 12px;
  background: linear-gradient(180deg, #cda34f, #b0852b);
  color: white;
  border: none;
  border-radius: 6px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s;
  font-size: 15px;
}

button:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 18px rgba(205,163,79,0.3);
}

.back-link {
  text-align: center;
  margin-top: 15px;
}

.back-link a {
  color: #1976d2;
  text-decoration: none;
  font-size: 14px;
}

.back-link a:hover {
  text-decoration: underline;
}

.step-info {
  font-size: 13px;
  color: #666;
  margin-top: 10px;
  padding: 10px;
  background: #f5f5f5;
  border-radius: 6px;
}
</style>

<div class="forgot-container">
  <h1 class="forgot-title">🔐 Reset Password</h1>

  <div class="step-indicator">
    <div class="step <?php echo ($step >= 1) ? 'active' : ''; ?> <?php echo ($step > 1) ? 'completed' : ''; ?>">
      <div style="font-weight: 700; margin-bottom: 3px;">1</div>
      <div>Identify</div>
    </div>
    <div class="step <?php echo ($step >= 2) ? 'active' : ''; ?> <?php echo ($step > 2) ? 'completed' : ''; ?>">
      <div style="font-weight: 700; margin-bottom: 3px;">2</div>
      <div>Verify</div>
    </div>
    <div class="step <?php echo ($step >= 3) ? 'active' : ''; ?> <?php echo ($step > 3) ? 'completed' : ''; ?>">
      <div style="font-weight: 700; margin-bottom: 3px;">3</div>
      <div>Reset</div>
    </div>
  </div>

  <?php if ($error): ?>
    <div class="error">❌ <?php echo e($error); ?></div>
  <?php endif; ?>

  <?php if ($message): ?>
    <div class="success">✅ <?php echo e($message); ?></div>
  <?php endif; ?>

  <!-- STEP 1: Enter phone/email -->
  <?php if ($step == 1): ?>
    <form method="POST">
      <div class="form-group">
        <label for="phone_email">Phone Number or Email</label>
        <input type="text" id="phone_email" name="phone_email" placeholder="Enter your phone or email" required>
      </div>
      <button type="submit">Continue →</button>
      <div class="back-link"><a href="<?php echo base_url('/login.php'); ?>">← Back to Login</a></div>
    </form>
  <?php endif; ?>

  <!-- STEP 2: Verify OTP -->
  <?php if ($step == 2 && isset($_SESSION['reset_user_id'])): ?>
    <div class="info">
      ℹ️ An OTP has been sent to your registered phone/email<br>
      <strong>Demo OTP: 123456</strong>
    </div>
    <form method="POST">
      <div class="form-group">
        <label for="otp">Enter OTP</label>
        <input type="text" id="otp" name="otp" placeholder="6-digit OTP" maxlength="6" required>
      </div>
      <button type="submit">Verify OTP →</button>
      <div class="back-link"><a href="<?php echo base_url('/forgot_password.php?step=1'); ?>">← Change phone/email</a></div>
    </form>
  <?php endif; ?>

  <!-- STEP 3: New Password -->
  <?php if ($step == 3 && isset($_SESSION['otp_verified']) && $_SESSION['otp_verified']): ?>
    <form method="POST">
      <div class="form-group">
        <label for="password">New Password</label>
        <input type="password" id="password" name="password" placeholder="Minimum 6 characters" required>
      </div>
      <div class="form-group">
        <label for="confirm_password">Confirm Password</label>
        <input type="password" id="confirm_password" name="confirm_password" placeholder="Re-enter password" required>
      </div>
      <button type="submit">Reset Password →</button>
      <div class="back-link"><a href="<?php echo base_url('/forgot_password.php?step=1'); ?>">← Start Over</a></div>
    </form>
  <?php endif; ?>

</div>

<?php require 'includes/footer.php'; ?>
