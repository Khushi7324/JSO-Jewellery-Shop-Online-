<?php
// Handle login before sending any HTML to avoid header() warnings.
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/functions.php';

$body_class = 'gold-glitter-bg';
$errors = [];
if($_SERVER['REQUEST_METHOD']=='POST'){
    $login = trim($_POST['login']); // Can be email or phone
    $password = $_POST['password'];
    
    // Check if login is email or phone format
    $is_email = filter_var($login, FILTER_VALIDATE_EMAIL);
    $is_phone = preg_match('/^\d{10}$/', $login);
    
    if(!$is_email && !$is_phone) {
        $errors[] = '❌ Please enter a valid email or 10-digit phone number';
    } else {
        // Query by email OR phone
        $stmt = $mysqli->prepare("SELECT id, password FROM users WHERE email = ? OR phone = ?");
        $stmt->bind_param('ss', $login, $login);
        $stmt->execute();
        $stmt->bind_result($id, $hash);
        
        if($stmt->fetch()){
            if(password_verify($password, $hash)){
                $_SESSION['user_id'] = $id;
                header('Location: ' . base_url('/')); exit;
            } else {
                $errors[] = '❌ Invalid password';
            }
        } else {
            $errors[] = '❌ No account found with this email or phone';
        }
        $stmt->close();
    }
}

require 'includes/header.php';
?>
<div style="min-height:70vh;display:flex;align-items:center;justify-content:center;position:relative;padding-top:80px">
  <div class="rotating-diamond" aria-hidden>
    <!-- diamond SVG -->
    <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid meet" style="width:100%;height:100%">
      <defs>
        <linearGradient id="g1" x1="0" x2="1">
          <stop offset="0%" stop-color="#fff" stop-opacity="0.9"/>
          <stop offset="100%" stop-color="#ffeaa7" stop-opacity="0.8"/>
        </linearGradient>
      </defs>
      <g transform="translate(50,50)">
        <path d="M0,-36 L28,-4 L0,36 L-28,-4 Z" fill="url(#g1)" stroke="#f7f2e6" stroke-width="0.8"/>
        <path d="M0,-36 L28,-4 L0,0 L-28,-4 Z" fill="rgba(255,255,255,0.04)"/>
      </g>
    </svg>
  </div>

  <div class="glass-card fade-in-up" style="max-width:420px;width:100%">
    <h2 style="margin-top:0;color:var(--gold-dark)">Welcome back</h2>
    <p style="color:#777;font-size:14px;margin:0 0 16px 0">Login with Email or 10-digit Phone</p>
    <?php if($errors): ?><div style="color:#a33; margin-bottom:8px"><?=implode('<br>',$errors)?></div><?php endif; ?>
    <form method="post" style="display:flex;flex-direction:column;gap:10px">
      <input class="gold-border" type="text" name="login" placeholder="Email or Phone (10 digits)" required>
      <input class="gold-border" type="password" name="password" placeholder="Password" required>
      <div style="display:flex;justify-content:space-between;align-items:center">
        <label style="font-size:13px;color:#666"><input type="checkbox" name="remember"> Remember me</label>
        <a href="<?php echo base_url('/register.php'); ?>" style="color:var(--gold-dark);text-decoration:none;font-weight:600">Create account</a>
      </div>
      <div style="margin-top:6px">
        <button class="btn btn-glow" type="submit">Sign in</button>
      </div>
    </form>
  </div>
</div>

<?php require 'includes/footer.php';?>