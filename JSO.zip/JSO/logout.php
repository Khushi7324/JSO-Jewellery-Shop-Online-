<?php
session_start();
session_unset();
session_destroy();
require 'includes/functions.php';
header('Location: ' . base_url('/'));
?>