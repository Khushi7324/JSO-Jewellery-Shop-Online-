// Pincode check with express delivery availability
function checkPincode(){
  var p = document.getElementById('pincode').value;
  var resultEl = document.getElementById('pincodeResult');
  if(!p) { resultEl.textContent = ''; return; }
  resultEl.textContent = '⏳ Checking...';
  var base = (window.APP_BASE && window.APP_BASE !== '/') ? window.APP_BASE : '/';
  fetch(base + 'pincode_check.php?p='+encodeURIComponent(p))
    .then(r=>r.json())
    .then(data=>{
      if(data.express) {
        resultEl.textContent = '✨ Express delivery available';
        resultEl.style.color = '#27ae60';
      } else {
        resultEl.textContent = '📦 Standard delivery only';
        resultEl.style.color = '#f39c12';
      }
    })
    .catch(e=>{ resultEl.textContent = 'Error checking'; console.error(e); });
}

// Invoice print (uses browser print dialog)
function printInvoice(){ 
  window.print(); 
}

// Page fade-in animation
document.addEventListener('DOMContentLoaded', function(){
  document.body.style.opacity = '0';
  setTimeout(()=>{ document.body.style.opacity = '1'; }, 50);
});

// Smooth scroll for anchors
document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener('click', function(e){
    e.preventDefault();
    var target = document.querySelector(this.getAttribute('href'));
    if(target) target.scrollIntoView({ behavior: 'smooth' });
  });
});
