<?php
$body_class = 'diamond-shine-bg';
require 'includes/header.php';

// Pagination setup
$per_page = 12;
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$offset = ($page - 1) * $per_page;

// filters
$cat = isset($_GET['cat'])?intval($_GET['cat']):0;
$q = isset($_GET['q'])?trim($_GET['q']):'';
$sort = isset($_GET['sort'])?$_GET['sort']:'';
$price_min = isset($_GET['price_min']) ? floatval($_GET['price_min']) : 0;
$price_max = isset($_GET['price_max']) ? floatval($_GET['price_max']) : 1000000;

$where = [];
$params = [];
if($cat) { $where[] = 'category_id=?'; $params[] = $cat; }
if($q) { $where[] = '(name LIKE ? OR description LIKE ?)'; $params[] = '%'.$q.'%'; $params[] = '%'.$q.'%'; }
$where[] = 'price BETWEEN ? AND ?';
$params[] = $price_min;
$params[] = $price_max;

$where_sql = 'WHERE '.implode(' AND ',$where);
$order = '';
if($sort=='low') $order='ORDER BY price ASC';
elseif($sort=='high') $order='ORDER BY price DESC';
else $order='ORDER BY created_at DESC';

// Get total count
$count_sql = "SELECT COUNT(*) as total FROM products " . $where_sql;
$count_stmt = $mysqli->prepare($count_sql);
if($params){
    $types = str_repeat('s', count($params));
    $count_stmt->bind_param($types, ...$params);
}
$count_stmt->execute();
$total = $count_stmt->get_result()->fetch_assoc()['total'];
$count_stmt->close();
$total_pages = ceil($total / $per_page);

// Get products for current page
$sql = "SELECT * FROM products " . $where_sql . " $order LIMIT ? OFFSET ?";
$stmt = $mysqli->prepare($sql);
$types = str_repeat('s', count($params)) . 'ii';
$stmt->bind_param($types, ...array_merge($params, [$per_page, $offset]));
$stmt->execute();
$res = $stmt->get_result();
$products = $res->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Get categories for filter
$cat_stmt = $mysqli->prepare("SELECT id, name FROM categories");
$cat_stmt->execute();
$categories = $cat_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$cat_stmt->close();
?>

<style>
.container {
  max-width: 1400px;
  margin: 0 auto;
  padding: 0 10px;
}

.catalog-wrapper {
  display: grid;
  grid-template-columns: 260px 1fr;
  gap: 20px;
  margin: 20px 0;
}

.filters-panel {
  background: white;
  border-radius: 8px;
  padding: 20px;
  height: fit-content;
  position: sticky;
  top: 100px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
}

.filters-panel h3 {
  margin: 0 0 16px 0;
  color: #333;
  font-size: 16px;
  font-weight: 700;
}

.filter-group {
  margin-bottom: 20px;
  padding-bottom: 16px;
  border-bottom: 1px solid #eee;
}

.filter-group:last-child {
  border-bottom: none;
  margin-bottom: 0;
  padding-bottom: 0;
}

.filter-group label {
  display: block;
  font-size: 12px;
  font-weight: 700;
  color: #666;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  margin-bottom: 10px;
}

.filter-group input,
.filter-group select {
  width: 100%;
  padding: 10px;
  border: 1px solid #ddd;
  border-radius: 4px;
  font-size: 13px;
  background: white;
  color: #333;
  transition: all 0.2s ease;
}

.filter-group input:focus,
.filter-group select:focus {
  outline: none;
  border-color: #667eea;
  box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
}

.filter-buttons {
  display: flex;
  gap: 8px;
  margin-top: 16px;
}

.filter-btn {
  flex: 1;
  padding: 10px;
  border: none;
  border-radius: 4px;
  font-weight: 700;
  cursor: pointer;
  transition: all 0.2s ease;
  font-size: 12px;
}

.filter-btn-apply {
  background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
  color: white;
}

.filter-btn-apply:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
}

.filter-btn-reset {
  background: #f5f5f5;
  color: #333;
  border: 1px solid #ddd;
}

.filter-btn-reset:hover {
  background: #eee;
}

.products-section {
  display: flex;
  flex-direction: column;
}

.products-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
  padding: 16px;
  background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
  border-radius: 8px;
  color: white;
}

.products-header h2 {
  margin: 0;
  font-size: 22px;
  font-weight: 700;
}

.results-count {
  font-size: 13px;
  opacity: 0.9;
}

.products-grid-flipcart {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
  gap: 16px;
  margin-bottom: 30px;
}

.product-card-flipcart {
  background: white;
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
  transition: all 0.3s ease;
  display: flex;
  flex-direction: column;
  height: 100%;
}

.product-card-flipcart:hover {
  transform: translateY(-8px);
  box-shadow: 0 12px 24px rgba(102, 126, 234, 0.2);
}

.product-image-wrapper {
  position: relative;
  width: 100%;
  aspect-ratio: 1;
  background: #f5f5f5;
  overflow: hidden;
  display: flex;
  align-items: center;
  justify-content: center;
}

.product-image-wrapper img {
  width: 100%;
  height: 100%;
  object-fit: contain;
  padding: 12px;
  transition: transform 0.3s ease;
}

.product-card-flipcart:hover .product-image-wrapper img {
  transform: scale(1.15);
}

.product-badge-flipcart {
  position: absolute;
  top: 12px;
  right: 12px;
  background: linear-gradient(135deg, #ff6b6b 0%, #ee5a6f 100%);
  color: white;
  padding: 6px 10px;
  border-radius: 4px;
  font-size: 11px;
  font-weight: 700;
}

.product-info-flipcart {
  padding: 12px;
  flex: 1;
  display: flex;
  flex-direction: column;
}

.product-name-flipcart {
  font-size: 13px;
  font-weight: 600;
  color: #333;
  margin: 0 0 6px 0;
  line-height: 1.3;
  min-height: 32px;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.product-rating-flipcart {
  display: flex;
  gap: 2px;
  align-items: center;
  margin-bottom: 6px;
  font-size: 12px;
}

.stars {
  color: #ffc107;
}

.rating-count {
  color: #999;
  margin-left: 4px;
}

.product-price-flipcart {
  font-size: 16px;
  font-weight: 900;
  color: #1a73e8;
  margin: 4px 0;
}

.product-original-price {
  font-size: 11px;
  color: #999;
  text-decoration: line-through;
  margin-right: 6px;
}

.product-discount {
  font-size: 11px;
  color: #ff6b6b;
  font-weight: 700;
}

.product-stock-flipcart {
  font-size: 11px;
  color: #27ae60;
  margin-bottom: 8px;
  font-weight: 600;
}

.product-button-flipcart {
  margin-top: auto;
  padding: 10px;
  background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
  color: white;
  border: none;
  border-radius: 4px;
  font-weight: 700;
  cursor: pointer;
  transition: all 0.2s ease;
  font-size: 13px;
}

.product-button-flipcart:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
}

.pagination {
  display: flex;
  justify-content: center;
  gap: 8px;
  margin: 40px 0;
  flex-wrap: wrap;
  align-items: center;
}

.pagination a,
.pagination span {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 36px;
  height: 36px;
  padding: 0 8px;
  border: 1px solid #ddd;
  border-radius: 4px;
  background: white;
  color: #333;
  text-decoration: none;
  font-weight: 600;
  transition: all 0.2s ease;
  font-size: 13px;
}

.pagination a:hover {
  border-color: #667eea;
  color: #667eea;
  transform: translateY(-2px);
}

.pagination .active {
  background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
  color: white;
  border-color: transparent;
}

.pagination .disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.no-products {
  grid-column: 1 / -1;
  text-align: center;
  padding: 60px 20px;
  color: #999;
}

.no-products p {
  margin: 12px 0;
  font-size: 16px;
}

@media(max-width: 1024px) {
  .catalog-wrapper {
    grid-template-columns: 220px 1fr;
  }
  
  .products-grid-flipcart {
    grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
    gap: 12px;
  }
}

@media(max-width: 768px) {
  .catalog-wrapper {
    grid-template-columns: 1fr;
  }
  
  .filters-panel {
    position: static;
    top: auto;
  }
  
  .products-grid-flipcart {
    grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
    gap: 10px;
  }
}

@media(max-width: 600px) {
  .products-grid-flipcart {
    grid-template-columns: repeat(2, 1fr);
    gap: 8px;
  }
  
  .products-header {
    padding: 12px;
    margin-bottom: 16px;
  }
  
  .products-header h2 {
    font-size: 18px;
  }
  
  .filter-group {
    margin-bottom: 16px;
    padding-bottom: 12px;
  }
}
</style>

<div class="container">
  <div class="catalog-wrapper">
    <!-- Filters Sidebar -->
    <aside class="filters-panel">
      <h3>🔍 Filters</h3>
      
      <form method="get" action="<?php echo base_url('/catalog.php'); ?>">
        <div class="filter-group">
          <label>Search Products</label>
          <input type="text" name="q" placeholder="Search..." value="<?=e($q)?>">
        </div>

        <div class="filter-group">
          <label>Category</label>
          <select name="cat">
            <option value="">All Categories</option>
            <?php foreach($categories as $c): ?>
              <option value="<?=$c['id']?>" <?=$cat == $c['id'] ? 'selected' : ''?>>
                <?=e($c['name'])?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="filter-group">
          <label>Price Range</label>
          <div style="display: flex; gap: 8px; margin-bottom: 8px;">
            <input type="number" name="price_min" placeholder="Min" value="<?=$price_min?>" min="0">
            <input type="number" name="price_max" placeholder="Max" value="<?=$price_max?>" min="0">
          </div>
        </div>

        <div class="filter-group">
          <label>Sort By</label>
          <select name="sort">
            <option value="">Newest</option>
            <option value="low" <?=$sort == 'low' ? 'selected' : ''?>>Price: Low to High</option>
            <option value="high" <?=$sort == 'high' ? 'selected' : ''?>>Price: High to Low</option>
          </select>
        </div>

        <div class="filter-buttons">
          <button type="submit" class="filter-btn filter-btn-apply">Apply</button>
          <a href="<?php echo base_url('/catalog.php'); ?>" class="filter-btn filter-btn-reset">Reset</a>
        </div>
      </form>
    </aside>

    <!-- Products Section -->
    <main class="products-section">
      <div class="products-header">
        <h2>💎 Products</h2>
        <div class="results-count">
          <?php if($total > 0): ?>
            Showing <?=min(($page-1)*$per_page + 1, $total)?> - <?=min($page*$per_page, $total)?> of <?=$total?>
          <?php else: ?>
            No products found
          <?php endif; ?>
        </div>
      </div>

      <?php if(count($products) > 0): ?>
        <div class="products-grid-flipcart">
          <?php foreach($products as $p): ?>
            <div class="product-card-flipcart">
              <div class="product-image-wrapper">
                <span class="product-badge-flipcart">Sale -20%</span>
                <img src="<?php echo resolve_asset_url($p['image']); ?>" alt="<?=e($p['name'])?>">
              </div>
              <div class="product-info-flipcart">
                <h3 class="product-name-flipcart"><?=e($p['name'])?></h3>
                <div class="product-rating-flipcart">
                  <span class="stars">★★★★★</span>
                  <span class="rating-count">(<?=rand(50, 500)?>)</span>
                </div>
                <div style="margin-bottom: 6px;">
                  <span class="product-price-flipcart">₹<?=number_format($p['price'], 0)?></span>
                  <span class="product-original-price">₹<?=number_format($p['price'] * 1.25, 0)?></span>
                  <span class="product-discount">20% OFF</span>
                </div>
                <div class="product-stock-flipcart">✓ In Stock</div>
                <button class="product-button-flipcart" onclick="location.href='<?php echo base_url('/product.php?id=' . $p['id']); ?>'">View & Buy</button>
              </div>
            </div>
          <?php endforeach; ?>
        </div>

        <!-- Pagination -->
        <?php if($total_pages > 1): ?>
          <div class="pagination">
            <?php if($page > 1): ?>
              <a href="?page=1<?=($cat ? '&cat='.$cat : '').(isset($_GET['q']) ? '&q='.urlencode($q) : '').(isset($_GET['sort']) ? '&sort='.$_GET['sort'] : '')?>">« First</a>
              <a href="?page=<?=$page-1?><?=($cat ? '&cat='.$cat : '').(isset($_GET['q']) ? '&q='.urlencode($q) : '').(isset($_GET['sort']) ? '&sort='.$_GET['sort'] : '')?>">‹ Prev</a>
            <?php else: ?>
              <span class="disabled">« First</span>
              <span class="disabled">‹ Prev</span>
            <?php endif; ?>

            <span style="margin: 0 8px; font-weight: 700;">Page <?=$page?> of <?=$total_pages?></span>

            <?php if($page < $total_pages): ?>
              <a href="?page=<?=$page+1?><?=($cat ? '&cat='.$cat : '').(isset($_GET['q']) ? '&q='.urlencode($q) : '').(isset($_GET['sort']) ? '&sort='.$_GET['sort'] : '')?>">Next ›</a>
              <a href="?page=<?=$total_pages?><?=($cat ? '&cat='.$cat : '').(isset($_GET['q']) ? '&q='.urlencode($q) : '').(isset($_GET['sort']) ? '&sort='.$_GET['sort'] : '')?>">Last »</a>
            <?php else: ?>
              <span class="disabled">Next ›</span>
              <span class="disabled">Last »</span>
            <?php endif; ?>
          </div>
        <?php endif; ?>
      <?php else: ?>
        <div class="no-products">
          <p>😔 No products found</p>
          <p style="font-size: 14px;">Try adjusting your filters or search terms</p>
        </div>
      <?php endif; ?>
    </main>
  </div>
  </div>

  <?php require 'includes/footer.php';?>