<?php
$body_class = 'gold-glitter-bg';
require 'includes/header.php';
?>
<div style="min-height:70vh;display:flex;align-items:center;justify-content:center;position:relative;padding-top:80px">
  <div class="glass-card fade-in-up" style="max-width:600px;width:100%;text-align:center">
    <h1 style="font-size:48px;margin-top:0;color:#ff6b6b">403</h1>
    <h2 style="color:var(--color-secondary);margin:0 0 16px 0">Access Denied</h2>
    <p style="color:var(--color-text-muted);font-size:16px;margin-bottom:24px">
      You do not have permission to access this resource. Admin access is required.
    </p>
    
    <div style="display:flex;gap:12px;justify-content:center;flex-wrap:wrap">
      <a href="<?php echo base_url('/'); ?>" class="btn btn-glow" style="text-decoration:none">← Back to Home</a>
      <?php if(!isLoggedIn()): ?>
        <a href="<?php echo base_url('/login.php'); ?>" class="btn btn-glow" style="text-decoration:none">🔑 Login</a>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php require 'includes/footer.php'; ?>
