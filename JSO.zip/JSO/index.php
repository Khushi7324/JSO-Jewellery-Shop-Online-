<?php
$body_class = 'gold-glitter-bg';
require 'includes/header.php';
// fetch categories
$cats = [];
$res = $mysqli->query("SELECT * FROM categories LIMIT 8");
while($r = $res->fetch_assoc()) $cats[] = $r;
// trending: show recent products
$tr = $mysqli->query("SELECT * FROM products ORDER BY created_at DESC LIMIT 20");
$trending = [];
while($p = $tr->fetch_assoc()) $trending[] = $p;
?>

<style>
* {
  box-sizing: border-box;
}

html, body {
  width: 100%;
  height: 100%;
  margin: 0;
  /* Do NOT reset body padding here so the fixed header spacing from includes/header.php is preserved */
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
}

.container {
  max-width: 1400px;
  margin: 0 auto;
  padding: 0 max(10px, 2vw);
  width: 100%;
}

/* Hero Banner Carousel */
.hero-carousel {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-radius: 8px;
  overflow: hidden;
  margin: clamp(12px, 3vh, 30px) 0;
  height: clamp(160px, 40vh, 400px);
  min-height: 160px;
  position: relative;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  width: 100%;
}

.hero-carousel-content {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: clamp(16px, 5vh, 60px) clamp(16px, 4vw, 60px);
  height: 100%;
  color: white;
  animation: slideIn 0.8s ease;
  flex-wrap: wrap;
  gap: clamp(12px, 3vw, 24px);
}

.hero-carousel-text h1 {
  font-size: clamp(18px, 6vw, 42px);
  font-weight: 900;
  margin: 0 0 12px 0;
  letter-spacing: -1px;
  line-height: 1.2;
}

.hero-carousel-text p {
  font-size: clamp(14px, 2.5vw, 18px);
  margin: 0 0 20px 0;
  opacity: 0.95;
  line-height: 1.4;
}

.hero-cta {
  display: inline-block;
  background: white;
  color: #667eea;
  padding: clamp(10px, 2vh, 12px) clamp(16px, 4vw, 28px);
  border-radius: 4px;
  text-decoration: none;
  font-weight: 700;
  font-size: clamp(12px, 1.5vw, 15px);
  transition: all 0.3s ease;
  white-space: nowrap;
}

.hero-cta:hover {
  transform: translateY(-3px);
  box-shadow: 0 6px 16px rgba(0, 0, 0, 0.2);
}

.hero-carousel-image {
  animation: float 3s ease-in-out infinite;
  width: clamp(100px, 25vw, 200px);
  height: clamp(100px, 25vw, 200px);
  flex-shrink: 0;
}

.hero-carousel-image img {
  width: 100%;
  height: 100%;
  object-fit: contain;
}

@keyframes slideIn {
  from { opacity: 0; transform: translateX(-30px); }
  to { opacity: 1; transform: none; }
}

@keyframes float {
  0%, 100% { transform: translateY(0px); }
  50% { transform: translateY(-20px); }
}

/* Category Strip */
.category-strip {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(clamp(100px, 15vw, 140px), 1fr));
  gap: clamp(8px, 2vw, 16px);
  margin: clamp(16px, 4vh, 30px) 0;
  background: white;
  padding: clamp(12px, 3vh, 20px);
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
  width: 100%;
}

.category-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  padding: clamp(10px, 2.5vh, 16px) clamp(8px, 2vw, 12px);
  background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
  border-radius: 8px;
  text-decoration: none;
  color: #333;
  transition: all 0.3s ease;
  cursor: pointer;
  min-height: 70px;
  justify-content: center;
}

.category-item:hover {
  transform: scale(1.08);
  box-shadow: 0 8px 20px rgba(102, 126, 234, 0.2);
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
}

.category-icon {
  font-size: clamp(20px, 4vw, 32px);
  margin-bottom: clamp(4px, 1.5vh, 8px);
}

.category-name {
  font-weight: 700;
  font-size: clamp(10px, 2vw, 13px);
  line-height: 1.2;
}

/* Section Header */
.section-header {
  display: flex;
  align-items: center;
  gap: clamp(8px, 2vw, 16px);
  margin: clamp(24px, 5vh, 40px) 0 clamp(12px, 3vh, 20px) 0;
  padding: clamp(12px, 3vh, 20px);
  background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
  border-radius: 8px;
  color: white;
  flex-wrap: wrap;
}

.section-header::before {
  content: '';
  width: 4px;
  height: clamp(16px, 3vh, 24px);
  background: #ffd700;
  border-radius: 2px;
}

.section-header h2 {
  margin: 0;
  font-size: clamp(18px, 5vw, 28px);
  font-weight: 900;
}

.section-header-subtitle {
  margin-left: auto;
  font-size: clamp(11px, 1.8vw, 14px);
  opacity: 0.9;
}

/* Products Grid - Flipcart Style */
.products-grid-flipcart {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(clamp(140px, 18vw, 200px), 1fr));
  gap: clamp(10px, 2.5vw, 16px);
  margin-bottom: clamp(24px, 5vh, 50px);
  width: 100%;
}

.product-card-flipcart {
  background: white;
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
  transition: all 0.3s ease;
  display: flex;
  flex-direction: column;
  height: 100%;
  position: relative;
  min-height: 250px;
}

.product-card-flipcart:hover {
  transform: translateY(-8px);
  box-shadow: 0 12px 24px rgba(102, 126, 234, 0.2);
}

.product-image-wrapper {
  position: relative;
  width: 100%;
  aspect-ratio: 1;
  background: #f5f5f5;
  overflow: hidden;
  display: flex;
  align-items: center;
  justify-content: center;
}

.product-image-wrapper img {
  width: 100%;
  height: 100%;
  object-fit: contain;
  padding: 12px;
  transition: transform 0.3s ease;
}

.product-card-flipcart:hover .product-image-wrapper img {
  transform: scale(1.15);
}

.product-badge-flipcart {
  position: absolute;
  top: 12px;
  right: 12px;
  background: linear-gradient(135deg, #ff6b6b 0%, #ee5a6f 100%);
  color: white;
  padding: 6px 10px;
  border-radius: 4px;
  font-size: 11px;
  font-weight: 700;
  animation: bounce 2s infinite;
}

@keyframes bounce {
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-8px); }
}

.product-info-flipcart {
  padding: clamp(10px, 2.5vh, 16px);
  flex: 1;
  display: flex;
  flex-direction: column;
}

.product-name-flipcart {
  font-size: clamp(11px, 1.8vw, 14px);
  font-weight: 600;
  color: #333;
  margin: 0 0 clamp(4px, 1vh, 8px) 0;
  line-height: 1.3;
  min-height: 32px;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.product-rating-flipcart {
  display: flex;
  gap: 2px;
  align-items: center;
  margin-bottom: clamp(4px, 1vh, 8px);
  font-size: clamp(10px, 1.5vw, 13px);
}

.stars {
  color: #ffc107;
}

.rating-count {
  color: #999;
  margin-left: 4px;
}

.product-price-flipcart {
  font-size: clamp(16px, 3vw, 20px);
  font-weight: 900;
  color: #1a73e8;
  margin: clamp(4px, 1.5vh, 8px) 0;
}

.product-original-price {
  font-size: clamp(10px, 1.5vw, 12px);
  color: #999;
  text-decoration: line-through;
  margin-right: 6px;
}

.product-discount {
  font-size: clamp(10px, 1.5vw, 12px);
  color: #ff6b6b;
  font-weight: 700;
}

.product-stock-flipcart {
  font-size: clamp(9px, 1.3vw, 11px);
  color: #27ae60;
  margin-bottom: clamp(6px, 1.5vh, 10px);
  font-weight: 600;
}

.product-button-flipcart {
  margin-top: auto;
  padding: clamp(8px, 1.5vh, 12px) clamp(8px, 2vw, 14px);
  background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
  color: white;
  border: none;
  border-radius: 4px;
  font-weight: 700;
  cursor: pointer;
  transition: all 0.2s ease;
  font-size: clamp(11px, 1.8vw, 14px);
  width: 100%;
}

.product-button-flipcart:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
}

/* Load More Button */
.load-more-section {
  text-align: center;
  margin: clamp(24px, 5vh, 50px) 0;
}

.load-more-btn {
  padding: clamp(12px, 2.5vh, 16px) clamp(24px, 6vw, 48px);
  background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
  color: white;
  border: none;
  border-radius: 4px;
  font-weight: 700;
  font-size: clamp(13px, 2vw, 16px);
  cursor: pointer;
  transition: all 0.3s ease;
  display: inline-block;
  white-space: nowrap;
}

.load-more-btn:hover {
  transform: translateY(-3px);
  box-shadow: 0 8px 20px rgba(102, 126, 234, 0.3);
}

/* Responsive - Fine Tuning */
@media(max-width: 1024px) {
  .products-grid-flipcart {
    grid-template-columns: repeat(auto-fill, minmax(clamp(130px, 17vw, 180px), 1fr));
  }
}

@media(max-width: 768px) {
  .category-strip {
    grid-template-columns: repeat(auto-fit, minmax(clamp(90px, 12vw, 120px), 1fr));
  }
  
  .products-grid-flipcart {
    grid-template-columns: repeat(auto-fill, minmax(clamp(110px, 15vw, 150px), 1fr));
  }
}

@media(max-width: 600px) {
  .hero-carousel-text p {
    display: none;
  }
  
  .category-strip {
    grid-template-columns: repeat(auto-fit, minmax(clamp(70px, 10vw, 100px), 1fr));
  }
  
  .products-grid-flipcart {
    grid-template-columns: repeat(auto-fill, minmax(clamp(100px, 12vw, 140px), 1fr));
  }
}

@media(max-width: 480px) {
  .hero-carousel-image {
    display: none;
  }
  
  .category-strip {
    grid-template-columns: repeat(4, 1fr);
  }
  
  .products-grid-flipcart {
    grid-template-columns: repeat(2, 1fr);
  }
  
  .section-header {
    flex-direction: column;
    align-items: flex-start;
  }
  
  .section-header-subtitle {
    margin-left: 0;
    margin-top: 8px;
  }
}
</style>

<div class="container">
  <!-- Hero Carousel Banner -->
  <div class="hero-carousel">
    <div class="hero-carousel-content">
      <div class="hero-carousel-text">
        <h1>✨ Premium Jewellery Collection</h1>
        <p>Handcrafted elegance for every occasion</p>
        <a href="<?php echo base_url('/catalog.php'); ?>" class="hero-cta">EXPLORE NOW</a>
      </div>
      <div class="hero-carousel-image">
        <img src="<?php echo base_url('/assets/Photo/vmd-logo.png'); ?>" alt="VMD Jewels Logo">
      </div>
    </div>
  </div>

  <!-- Category Strip -->
  <div class="category-strip">
    <?php 
    // Map category names to appropriate icons
    $category_icons = [
      'gold'     => '💍',
      'diamond'  => '💎',
      'platinum' => '🏆',
      'gemstone' => '🔮',
      'silver'   => '🥈',
      'ring'     => '💍',
      'rings'    => '💍',
      'earring'  => '👂',
      'earrings' => '👂',
      'necklace' => '📿',
      'bracelet' => '⌚',
      'bangle'   => '✨',
      'bangles'  => '✨',
    ];
    foreach($cats as $c): 
      $key = strtolower(trim($c['name']));
      $icon = $category_icons[$key] ?? '✨';
    ?>
      <a href="<?php echo base_url('/catalog.php?cat=' . $c['id']); ?>" class="category-item">
        <div class="category-icon"><?=$icon?></div>
        <div class="category-name"><?=e($c['name'])?></div>
      </a>
    <?php endforeach; ?>
  </div>

  <!-- Best Sellers Section -->
  <div class="section-header">
    <h2>🔥 Best Sellers</h2>
    <div class="section-header-subtitle">Limited time offers</div>
  </div>

  <div class="products-grid-flipcart">
    <?php 
    $best_sellers = array_slice($trending, 0, 12);
    foreach($best_sellers as $p): 
    ?>
      <div class="product-card-flipcart">
        <div class="product-image-wrapper">
          <span class="product-badge-flipcart">Sale -20%</span>
          <img src="<?php echo resolve_asset_url($p['image']); ?>" alt="<?=e($p['name'])?>">
        </div>
        <div class="product-info-flipcart">
          <h3 class="product-name-flipcart"><?=e($p['name'])?></h3>
          <div class="product-rating-flipcart">
            <span class="stars">★★★★★</span>
            <span class="rating-count">(245)</span>
          </div>
          <div style="margin-bottom: 6px;">
            <span class="product-price-flipcart">₹<?=number_format($p['price'], 0)?></span>
            <span class="product-original-price">₹<?=number_format($p['price'] * 1.25, 0)?></span>
            <span class="product-discount">20% OFF</span>
          </div>
          <div class="product-stock-flipcart">✓ In Stock</div>
          <button class="product-button-flipcart add-to-cart" data-product-id="<?= $p['id'] ?>">Add to Cart</button>
        </div>
      </div>
    <?php endforeach; ?>
  </div>

  <!-- Load More -->
  <div class="load-more-section">
    <a href="<?php echo base_url('/catalog.php'); ?>" class="load-more-btn">View All Products</a>
  </div>

  <!-- New Arrivals Section -->
  <div class="section-header" style="margin-top: 60px;">
    <h2>✨ New Arrivals</h2>
    <div class="section-header-subtitle">Just added to our collection</div>
  </div>

  <div class="products-grid-flipcart">
    <?php 
    $new_arrivals = array_slice($trending, 12, 8);
    foreach($new_arrivals as $p): 
    ?>
      <div class="product-card-flipcart">
        <div class="product-image-wrapper">
          <span class="product-badge-flipcart" style="background: linear-gradient(135deg, #ffd700 0%, #ffed4e 100%); color: #333;">NEW</span>
          <img src="<?php echo resolve_asset_url($p['image']); ?>" alt="<?=e($p['name'])?>">
        </div>
        <div class="product-info-flipcart">
          <h3 class="product-name-flipcart"><?=e($p['name'])?></h3>
          <div class="product-rating-flipcart">
            <span class="stars">★★★★☆</span>
            <span class="rating-count">(128)</span>
          </div>
          <div style="margin-bottom: 6px;">
            <span class="product-price-flipcart">₹<?=number_format($p['price'], 0)?></span>
          </div>
          <div class="product-stock-flipcart">✓ In Stock</div>
          <button class="product-button-flipcart add-to-cart" data-product-id="<?= $p['id'] ?>">Add to Cart</button>
        </div>
      </div>
    <?php endforeach; ?>
  </div>

    <div class="load-more-section">
    <a href="<?php echo base_url('/catalog.php'); ?>" class="load-more-btn">Explore More</a>
  </div>
</div>

<?php require 'includes/footer.php';?>
<?php
// Expose CSRF token and add JS handler for add-to-cart buttons
$csrf = ensure_csrf_token();
?>
<script>
const CSRF_TOKEN = <?= json_encode($csrf) ?>;
async function addToCart(productId, qty = 1, btn = null){
  try{
    const fd = new FormData();
    fd.append('action','add');
    fd.append('product_id', String(productId));
    fd.append('quantity', String(qty));
    fd.append('csrf_token', CSRF_TOKEN);
    const res = await fetch('<?php echo base_url('/cart.php'); ?>', { method: 'POST', body: fd });
    const json = await res.json();
    if(json.success){
      // update button UI briefly
      if(btn){ const old = btn.innerText; btn.innerText = 'Added ✓'; setTimeout(()=>btn.innerText = old, 1400); }
      // update live cart count if provided
      if(json.cart_count !== undefined){
        const el = document.getElementById('cart-count');
        if(el) el.innerText = String(json.cart_count);
      }
      // show toast
      showToast(json.message || 'Added to cart');
    } else {
      showToast(json.message || 'Could not add to cart');
    }
  }catch(e){
    console.error(e);
    showToast('Network error adding to cart');
  }
}

function showToast(message, timeout = 2500){
  let toast = document.getElementById('site-toast');
  if(!toast){
    toast = document.createElement('div');
    toast.id = 'site-toast';
    Object.assign(toast.style, {
      position: 'fixed',
      right: '18px',
      bottom: '18px',
      background: 'rgba(0,0,0,0.85)',
      color: 'white',
      padding: '10px 14px',
      borderRadius: '8px',
      zIndex: 9999,
      boxShadow: '0 6px 18px rgba(0,0,0,0.25)',
      fontWeight: '600',
      opacity: '0',
      transition: 'opacity 180ms ease'
    });
    document.body.appendChild(toast);
  }
  toast.textContent = message;
  requestAnimationFrame(()=>{ toast.style.opacity = '1'; });
  clearTimeout(toast._hideTimer);
  toast._hideTimer = setTimeout(()=>{ toast.style.opacity = '0'; }, timeout);
}
document.addEventListener('click', function(e){
  const t = e.target.closest && e.target.closest('.add-to-cart');
  if(t){
    e.preventDefault();
    const id = t.dataset.productId;
    if(id) addToCart(id, 1, t);
  }
});
</script>