<?php
$DB_HOST = getenv('DB_HOST') !== false ? getenv('DB_HOST') : '127.0.0.1';
$DB_USER = getenv('DB_USER') !== false ? getenv('DB_USER') : 'root';
$DB_PASS = getenv('DB_PASS') !== false ? getenv('DB_PASS') : '';
$DB_NAME = getenv('DB_NAME') !== false ? getenv('DB_NAME') : 'jso_shop';
$DB_PORT = getenv('DB_PORT') !== false ? (int) getenv('DB_PORT') : 3306;

$mysqli = @new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME, $DB_PORT);
if ($mysqli->connect_errno) {
    die('DB connection failed: ' . $mysqli->connect_error);
}
$mysqli->set_charset('utf8mb4');
if (!defined('DEVELOPMENT')) {
    $dev = false;
    $envDev = getenv('DEVELOPMENT');
    $appEnv = getenv('APP_ENV');
    if ($envDev !== false) {
        $v = strtolower(trim($envDev));
        $dev = in_array($v, ['1', 'true', 'yes', 'on'], true);
    } elseif (isset($_SERVER['DEVELOPMENT'])) {
        $v = strtolower(trim($_SERVER['DEVELOPMENT']));
        $dev = in_array($v, ['1', 'true', 'yes', 'on'], true);
    } elseif ($appEnv !== false) {
        $v = strtolower(trim($appEnv));
        $dev = ($v === 'development' || $v === 'dev');
    } elseif (isset($_SERVER['APP_ENV'])) {
        $v = strtolower(trim($_SERVER['APP_ENV']));
        $dev = ($v === 'development' || $v === 'dev');
    }
    define('DEVELOPMENT', $dev);
}
?>
