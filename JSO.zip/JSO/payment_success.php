<?php
session_start();
require 'config/db.php';
require 'includes/functions.php';

require_login();

$uid = $_SESSION['user_id'];
$body_class = 'diamond-shine-bg';

if (!isset($_GET['order_id'])) {
  header('Location: ' . base_url('/my_orders.php'));
  exit;
}

$order_id = intval($_GET['order_id']);
$is_cod = (isset($_GET['method']) && $_GET['method'] === 'cod');

// Fetch order with full details
$stmt = $mysqli->prepare("SELECT * FROM orders WHERE id=? AND user_id=?");
$stmt->bind_param('ii', $order_id, $uid);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$order) {
  header('Location: ' . base_url('/my_orders.php'));
  exit;
}

// auto-detect COD by stored payment mode if query string missing
if (!$is_cod && isset($order['payment_mode']) && strtolower($order['payment_mode']) === 'cod') {
  $is_cod = true;
}

// Fetch order items
$stmt = $mysqli->prepare("SELECT oi.*, p.name FROM order_items oi JOIN products p ON p.id=oi.product_id WHERE oi.order_id=?");
$stmt->bind_param('i', $order_id);
$stmt->execute();
$items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

require 'includes/header.php';
?>

<style>
.success-container {
  max-width: 900px;
  margin: 40px auto;
  padding: 20px;
}

.success-box {
  background: linear-gradient(135deg, #d4edda, #c3e6cb);
  border-radius: 12px;
  padding: 40px;
  text-align: center;
  margin-bottom: 40px;
  border: 2px solid #28a745;
  box-shadow: 0 4px 12px rgba(40,167,69,0.15);
}

.success-icon {
  font-size: 80px;
  margin-bottom: 20px;
  animation: bounceIn 0.6s ease-out;
}

.success-title {
  font-size: 28px;
  font-weight: 700;
  color: #155724;
  margin-bottom: 10px;
}

.success-message {
  color: #155724;
  font-size: 16px;
  margin-bottom: 20px;
}

.order-details {
  background: white;
  border-radius: 12px;
  padding: 30px;
  margin-bottom: 30px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.08);
}

.details-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 20px;
  margin-bottom: 30px;
}

.detail-card {
  background: #f9f9f9;
  padding: 15px;
  border-radius: 8px;
  border-left: 4px solid #cda34f;
}

.detail-label {
  font-size: 12px;
  font-weight: 600;
  color: #999;
  text-transform: uppercase;
  margin-bottom: 8px;
}

.detail-value {
  font-size: 16px;
  font-weight: 700;
  color: #333;
  word-break: break-all;
}

.section-title {
  font-size: 18px;
  font-weight: 700;
  color: #333;
  margin-bottom: 15px;
  padding-bottom: 10px;
  border-bottom: 2px solid #f0f0f0;
}

.items-table {
  width: 100%;
  border-collapse: collapse;
  margin-bottom: 20px;
}

.items-table thead {
  background: #f5f5f5;
}

.items-table th {
  padding: 12px;
  text-align: left;
  font-weight: 600;
  color: #333;
  font-size: 14px;
}

.items-table td {
  padding: 12px;
  border-bottom: 1px solid #eee;
  font-size: 14px;
}

.items-table tr:hover {
  background: #fafafa;
}

.delivery-info {
  background: #f0f7ff;
  padding: 15px;
  border-radius: 8px;
  border-left: 4px solid #1976d2;
  margin-bottom: 20px;
}

.delivery-text {
  color: #1565c0;
  font-size: 14px;
}

.next-steps {
  background: white;
  border-radius: 12px;
  padding: 30px;
  margin-bottom: 30px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.08);
}

.steps {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 20px;
}

.step {
  text-align: center;
}

.step-number {
  width: 40px;
  height: 40px;
  background: linear-gradient(135deg, #cda34f, #b0852b);
  color: white;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 700;
  margin: 0 auto 10px;
}

.step-title {
  font-weight: 600;
  color: #333;
  font-size: 14px;
  margin-bottom: 5px;
}

.step-desc {
  font-size: 12px;
  color: #666;
}

.actions {
  display: flex;
  gap: 15px;
  justify-content: center;
}

.btn {
  padding: 12px 30px;
  border-radius: 6px;
  text-decoration: none;
  font-weight: 600;
  transition: all 0.2s;
  border: none;
  cursor: pointer;
  font-size: 14px;
}

.btn-primary {
  background: linear-gradient(180deg, #cda34f, #b0852b);
  color: white;
}

.btn-primary:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 18px rgba(205,163,79,0.3);
}

.btn-secondary {
  background: #f5f5f5;
  color: #333;
  border: 1px solid #ddd;
}

.btn-secondary:hover {
  background: #eee;
  border-color: #cda34f;
}

@keyframes bounceIn {
  0% { transform: scale(0); opacity: 0; }
  50% { transform: scale(1.1); }
  100% { transform: scale(1); opacity: 1; }
}

@media (max-width: 768px) {
  .details-grid {
    grid-template-columns: 1fr;
  }
  
  .steps {
    grid-template-columns: repeat(2, 1fr);
  }
  
  .actions {
    flex-direction: column;
  }
}
</style>

<div class="success-container">
  <!-- SUCCESS MESSAGE -->
  <div class="success-box">
    <div class="success-icon">✅</div>
    <h1 class="success-title">
      <?php echo $is_cod ? 'Order Placed - Cash on Delivery' : 'Payment Successful!'; ?>
    </h1>
    <p class="success-message">
      <?php echo $is_cod
        ? 'Your order has been placed with Cash on Delivery. Please keep the amount ready at delivery.'
        : 'Your order has been placed and payment has been received. Your order is now being processed.'; ?>
    </p>
  </div>

  <!-- ORDER DETAILS -->
  <div class="order-details">
    <h2 class="section-title">📋 Order Details</h2>
    
    <div class="details-grid">
      <div class="detail-card">
        <div class="detail-label">Order ID</div>
        <div class="detail-value">#<?php echo $order_id; ?></div>
      </div>
      
      <div class="detail-card">
        <div class="detail-label">Transaction / Payment</div>
        <div class="detail-value">
          <?php
            if ($is_cod) {
              echo 'Cash on Delivery';
            } else {
              echo e($order['transaction_id']);
            }
          ?>
        </div>
      </div>
      
      <div class="detail-card">
        <div class="detail-label">Bill ID</div>
        <div class="detail-value"><?php echo $is_cod ? 'N/A (COD)' : e($order['bill_id']); ?></div>
      </div>
    </div>

    <div class="details-grid">
      <div class="detail-card">
        <div class="detail-label">Tracking ID</div>
        <div class="detail-value"><?php echo e($order['tracking_id'] ?: 'Assigned soon'); ?></div>
      </div>
      
      <div class="detail-card">
        <div class="detail-label">Payment Status</div>
        <div class="detail-value">
          <?php echo $is_cod ? 'Cash on Delivery (pay on delivery)' : '✅ Completed'; ?>
        </div>
      </div>
      
      <div class="detail-card">
        <div class="detail-label">Order Status</div>
        <div class="detail-value" style="color: #ff9800;">
          <?php echo e($order['status'] ?? 'Processing'); ?>
        </div>
      </div>
    </div>

    <!-- ITEMS -->
    <h2 class="section-title">📦 Order Items</h2>
    <table class="items-table">
      <thead>
        <tr>
          <th>Product</th>
          <th>Quantity</th>
          <th>Price</th>
          <th>Total</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($items as $item): ?>
          <tr>
            <td><?php echo e($item['name']); ?></td>
            <td><?php echo $item['quantity']; ?></td>
            <td>₹<?php echo number_format($item['price']); ?></td>
            <td>₹<?php echo number_format($item['price'] * $item['quantity']); ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>

    <!-- DELIVERY INFO -->
    <div class="delivery-info">
      <strong>📍 Delivering to:</strong><br>
      <?php
        // Use new schema fields with fallbacks for older ones if present
        $addr = $order['address'] ?? ($order['shipping_address'] ?? '');
        $pin  = $order['pincode'] ?? ($order['postal_code'] ?? '');
        $city = $order['city'] ?? '';
        $state = $order['state'] ?? '';
        echo e(trim($addr));
        if ($city)  echo ', ' . e($city);
        if ($state) echo ', ' . e($state);
        if ($pin)   echo ' - ' . e($pin);
      ?>
    </div>

    <!-- AMOUNT -->
    <div style="text-align: right; padding-top: 20px; border-top: 2px solid #f0f0f0;">
      <strong style="color: #666; font-size: 16px;">Total Amount: </strong>
      <?php $total = $order['total'] ?? ($order['total_amount'] ?? 0); ?>
      <strong style="color: #cda34f; font-size: 20px;">₹<?php echo number_format($total); ?></strong>
    </div>
  </div>

  <!-- NEXT STEPS -->
  <div class="next-steps">
    <h2 class="section-title">📅 What Happens Next?</h2>
    <div class="steps">
      <div class="step">
        <div class="step-number">1</div>
        <div class="step-title">Processing</div>
        <div class="step-desc">Order being prepared for shipment</div>
      </div>
      <div class="step">
        <div class="step-number">2</div>
        <div class="step-title">Packing</div>
        <div class="step-desc">Items packed carefully</div>
      </div>
      <div class="step">
        <div class="step-number">3</div>
        <div class="step-title">Shipped</div>
        <div class="step-desc">Order dispatched to you</div>
      </div>
      <div class="step">
        <div class="step-number">4</div>
        <div class="step-title">Delivered</div>
        <div class="step-desc">Received at your doorstep</div>
      </div>
    </div>
  </div>

  <!-- ACTIONS -->
  <div class="actions">
    <a href="<?php echo base_url('/track_order.php?id=' . $order_id); ?>" class="btn btn-primary">Track Order</a>
    <a href="<?php echo base_url('/my_orders.php'); ?>" class="btn btn-secondary">View All Orders</a>
    <a href="<?php echo base_url('/catalog.php'); ?>" class="btn btn-secondary">Continue Shopping</a>
  </div>
</div>

<?php require 'includes/footer.php'; ?>
