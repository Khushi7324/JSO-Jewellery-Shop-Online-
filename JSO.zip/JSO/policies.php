<?php
$body_class = 'gold-glitter-bg';
require 'includes/header.php';
?>

<style>
.info-page {
  max-width: 900px;
  margin: 40px auto;
  padding: 20px;
}
.info-section {
  background: white;
  border-radius: 10px;
  padding: 20px 24px;
  margin-bottom: 20px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.06);
}
.info-section h2 {
  margin: 0 0 10px 0;
  font-size: 22px;
  color: #333;
}
.info-section p, .info-section li {
  margin: 0 0 6px 0;
  color: #555;
  line-height: 1.6;
  font-size: 14px;
}
.info-section ul {
  padding-left: 18px;
}
</style>

<div class="info-page">
  <div class="info-section" id="privacy">
    <h2>Privacy Policy</h2>
    <p>This demo application does not collect or store real customer data, but the structure is ready for a production policy.</p>
    <p>In a live store, this section would describe how you collect, use, and protect customer information.</p>
  </div>

  <div class="info-section" id="terms">
    <h2>Terms &amp; Conditions</h2>
    <p>Here you can outline purchase terms, limitations of liability, acceptable use, and other legal details for your jewellery shop.</p>
  </div>

  <div class="info-section" id="refund">
    <h2>Refund Policy</h2>
    <p>Returns in this demo are accepted within 7 days of delivery; admins can approve, receive and mark refunds from the returns dashboard.</p>
    <p>Real refund timelines and conditions should be documented here for your customers.</p>
  </div>

  <div class="info-section" id="warranty">
    <h2>Warranty</h2>
    <p>This section is a placeholder for your product warranty terms (e.g., plating guarantee, stone setting guarantee, repairs, etc.).</p>
  </div>
</div>

<?php require 'includes/footer.php'; ?>


