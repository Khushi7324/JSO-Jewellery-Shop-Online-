<?php
$body_class = 'gold-glitter-bg';
require 'includes/header.php';
require 'config/db.php';

$stmt = $mysqli->prepare("SELECT * FROM offers WHERE is_active=1 AND NOW() BETWEEN valid_from AND valid_till ORDER BY created_at DESC");
$stmt->execute();
$offers = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$stmt = $mysqli->prepare("SELECT * FROM coupons WHERE is_active=1 AND NOW() BETWEEN valid_from AND valid_till ORDER BY created_at DESC");
$stmt->execute();
$coupons = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>

<style>
.offers-container {
  max-width: 1200px;
  margin: 40px auto;
  padding: 20px;
}

.offers-hero {
  background: linear-gradient(135deg, #cda34f 0%, #b0852b 100%);
  color: white;
  padding: 40px 20px;
  border-radius: 10px;
  margin-bottom: 40px;
  text-align: center;
}

.offers-hero h1 {
  font-size: 36px;
  margin: 0 0 10px 0;
  font-weight: 900;
}

.offers-hero p {
  font-size: 16px;
  margin: 0;
  opacity: 0.9;
}

.section-header {
  font-size: 28px;
  font-weight: 700;
  color: #333;
  margin-bottom: 20px;
  padding-bottom: 15px;
  border-bottom: 3px solid #cda34f;
}

.offers-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
  gap: 20px;
  margin-bottom: 40px;
}

.offer-card {
  background: white;
  border-radius: 10px;
  overflow: hidden;
  box-shadow: 0 4px 12px rgba(0,0,0,0.1);
  transition: all 0.3s;
}

.offer-card:hover {
  transform: translateY(-8px);
  box-shadow: 0 12px 30px rgba(205,163,79,0.2);
}

.offer-image {
  width: 100%;
  height: 150px;
  background: linear-gradient(135deg, #f5f5f5, #e0e0e0);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 60px;
}

.offer-content {
  padding: 20px;
}

.offer-title {
  font-size: 16px;
  font-weight: 700;
  color: #333;
  margin-bottom: 8px;
}

.offer-description {
  font-size: 13px;
  color: #666;
  margin-bottom: 12px;
  line-height: 1.5;
}

.offer-discount {
  font-size: 24px;
  font-weight: 900;
  color: #cda34f;
  margin-bottom: 10px;
}

.offer-conditions {
  font-size: 12px;
  color: #999;
  margin-bottom: 12px;
}

.apply-btn {
  width: 100%;
  padding: 10px;
  background: linear-gradient(180deg, #cda34f, #b0852b);
  color: white;
  border: none;
  border-radius: 6px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s;
}

.apply-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 15px rgba(205,163,79,0.3);
}

.coupons-section {
  background: white;
  padding: 30px;
  border-radius: 10px;
  box-shadow: 0 4px 12px rgba(0,0,0,0.1);
  margin-bottom: 40px;
}

.coupons-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 15px;
}

.coupon-code {
  background: #f9f9f9;
  border: 2px dashed #cda34f;
  border-radius: 8px;
  padding: 15px;
  text-align: center;
}

.coupon-header {
  font-weight: 700;
  color: #333;
  margin-bottom: 8px;
}

.coupon-value {
  font-size: 28px;
  font-weight: 900;
  color: #cda34f;
  margin-bottom: 8px;
}

.coupon-code-text {
  font-family: 'Courier New', monospace;
  font-weight: 700;
  color: #666;
  background: white;
  padding: 8px 12px;
  border-radius: 4px;
  margin-bottom: 10px;
  font-size: 14px;
}

.copy-btn {
  width: 100%;
  padding: 8px;
  background: #e0e0e0;
  color: #333;
  border: none;
  border-radius: 4px;
  font-weight: 600;
  cursor: pointer;
  font-size: 12px;
  transition: all 0.2s;
}

.copy-btn:hover {
  background: #d0d0d0;
}

.copy-btn.copied {
  background: #4caf50;
  color: white;
}

.empty-state {
  text-align: center;
  padding: 40px 20px;
  color: #999;
}

.empty-icon {
  font-size: 60px;
  margin-bottom: 15px;
}

@media (max-width: 768px) {
  .offers-hero h1 {
    font-size: 24px;
  }

  .offers-grid {
    grid-template-columns: 1fr;
  }

  .coupons-grid {
    grid-template-columns: 1fr;
  }
}
</style>

<div class="offers-container">
  <div class="offers-hero">
    <h1>🎉 Special Offers & Deals</h1>
    <p>Save big on your favorite jewelry with our exclusive offers and coupons</p>
  </div>

  <!-- ACTIVE OFFERS -->
  <?php if (!empty($offers)): ?>
    <h2 class="section-header">💎 Current Offers</h2>
    <div class="offers-grid">
      <?php foreach ($offers as $offer): ?>
        <div class="offer-card">
          <div class="offer-image">
            <?php if ($offer['offer_type'] === 'category'): ?>
              💍
            <?php elseif ($offer['offer_type'] === 'product'): ?>
              ✨
            <?php else: ?>
              🎁
            <?php endif; ?>
          </div>
          <div class="offer-content">
            <div class="offer-title"><?php echo e($offer['title']); ?></div>
            <div class="offer-description"><?php echo e($offer['description']); ?></div>
            <div class="offer-discount">
              <?php if ($offer['discount_type'] === 'percentage'): ?>
                <?php echo $offer['discount_value']; ?>% OFF
              <?php else: ?>
                ₹<?php echo number_format($offer['discount_value']); ?> OFF
              <?php endif; ?>
            </div>
            <div class="offer-conditions">
              Min purchase: ₹<?php echo number_format($offer['min_purchase']); ?>
            </div>
            <button class="apply-btn" onclick="applyOffer(<?php echo $offer['id']; ?>, '<?php echo e($offer['title']); ?>')">
              Apply Offer
            </button>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php else: ?>
    <div class="empty-state">
      <div class="empty-icon">📭</div>
      <p>No active offers at the moment</p>
    </div>
  <?php endif; ?>

  <!-- COUPON CODES -->
  <?php if (!empty($coupons)): ?>
    <h2 class="section-header">🎟️ Coupon Codes</h2>
    <div class="coupons-section">
      <div class="coupons-grid">
        <?php foreach ($coupons as $coupon): ?>
          <div class="coupon-code">
            <div class="coupon-header"><?php echo e($coupon['description']); ?></div>
            <div class="coupon-value">
              <?php if ($coupon['discount_type'] === 'percentage'): ?>
                <?php echo $coupon['discount_value']; ?>%
              <?php else: ?>
                ₹<?php echo number_format($coupon['discount_value']); ?>
              <?php endif; ?>
            </div>
            <div class="coupon-code-text"><?php echo $coupon['code']; ?></div>
            <button class="copy-btn" onclick="copyCoupon('<?php echo $coupon['code']; ?>', this)">
              📋 Copy Code
            </button>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  <?php endif; ?>

  <!-- HOW TO USE -->
  <div style="background: #f5f5f5; padding: 30px; border-radius: 10px; margin-top: 40px;">
    <h2 class="section-header" style="border-bottom-color: #999;">📖 How to Use</h2>
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px;">
      <div style="padding: 20px;">
        <div style="font-size: 32px; margin-bottom: 10px;">1️⃣</div>
        <div style="font-weight: 700; color: #333; margin-bottom: 8px;">Add to Cart</div>
        <div style="color: #666; font-size: 14px;">Select your favorite jewelry items and add them to your cart.</div>
      </div>
      <div style="padding: 20px;">
        <div style="font-size: 32px; margin-bottom: 10px;">2️⃣</div>
        <div style="font-weight: 700; color: #333; margin-bottom: 8px;">Enter Coupon</div>
        <div style="color: #666; font-size: 14px;">Go to cart and enter your coupon code in the designated field.</div>
      </div>
      <div style="padding: 20px;">
        <div style="font-size: 32px; margin-bottom: 10px;">3️⃣</div>
        <div style="font-weight: 700; color: #333; margin-bottom: 8px;">Get Discount</div>
        <div style="color: #666; font-size: 14px;">Discount will be applied automatically before checkout.</div>
      </div>
      <div style="padding: 20px;">
        <div style="font-size: 32px; margin-bottom: 10px;">4️⃣</div>
        <div style="font-weight: 700; color: #333; margin-bottom: 8px;">Place Order</div>
        <div style="color: #666; font-size: 14px;">Complete checkout with the discounted price and enjoy!</div>
      </div>
    </div>
  </div>

</div>

<script>
function copyCoupon(code, btn) {
  navigator.clipboard.writeText(code).then(() => {
    btn.textContent = '✅ Copied!';
    btn.classList.add('copied');
    setTimeout(() => {
      btn.textContent = '📋 Copy Code';
      btn.classList.remove('copied');
    }, 2000);
  });
}

function applyOffer(offerId, title) {
  fetch('<?php echo base_url('/api/coupon_handler.php?action=apply_offer'); ?>', {
    method: 'POST',
    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
    body: 'offer_id=' + offerId
  })
  .then(r => r.json())
  .then(data => {
    if (data.success) {
      alert('✅ ' + title + ' offer applied! Go to cart to view savings.');
      setTimeout(() => location.href = '<?php echo base_url('/cart.php'); ?>', 1000);
    } else {
      alert('❌ ' + data.message);
    }
  });
}
</script>

<?php require 'includes/footer.php'; ?>
