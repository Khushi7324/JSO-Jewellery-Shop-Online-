<?php
session_start();
require 'config/db.php';
require 'includes/functions.php';

require_login();

$body_class = 'diamond-shine-bg';
$user_id = $_SESSION['user_id'];

$stmt = $mysqli->prepare("SELECT * FROM orders WHERE user_id=? ORDER BY order_date DESC");
$stmt->bind_param('i', $user_id);
$stmt->execute();
$orders = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

require 'includes/header.php';
?>

<style>
.orders-container {
  max-width: 1000px;
  margin: 40px auto;
  padding: 20px;
}

.orders-header {
  margin-bottom: 30px;
}

.orders-title {
  font-size: 28px;
  font-weight: 700;
  color: #333;
  margin-bottom: 10px;
}

.orders-subtitle {
  color: #666;
  font-size: 14px;
}

.empty-state {
  text-align: center;
  padding: 60px 20px;
  background: white;
  border-radius: 10px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.08);
}

.empty-icon {
  font-size: 60px;
  margin-bottom: 20px;
}

.empty-title {
  font-size: 20px;
  font-weight: 700;
  color: #333;
  margin-bottom: 10px;
}

.empty-text {
  color: #666;
  margin-bottom: 20px;
}

.empty-link {
  display: inline-block;
  padding: 10px 24px;
  background: linear-gradient(180deg, #cda34f, #b0852b);
  color: white;
  text-decoration: none;
  border-radius: 6px;
  font-weight: 600;
  transition: all 0.2s;
}

.empty-link:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 18px rgba(205,163,79,0.3);
}

.orders-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 20px;
}

.order-card {
  background: white;
  border-radius: 8px;
  padding: 20px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.08);
  transition: all 0.3s;
  display: flex;
  flex-direction: column;
}

.order-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 8px 20px rgba(0,0,0,0.12);
}

.order-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 15px;
}

.order-number {
  font-weight: 700;
  color: #333;
  font-size: 16px;
}

.order-status {
  padding: 4px 10px;
  border-radius: 20px;
  font-size: 11px;
  font-weight: 600;
  text-transform: uppercase;
}

.status-pending {
  background: #fff3cd;
  color: #856404;
}

.status-confirmed {
  background: #cfe2ff;
  color: #084298;
}

.status-shipped {
  background: #d1ecf1;
  color: #0c5460;
}

.status-delivered {
  background: #d4edda;
  color: #155724;
}

.status-cancelled {
  background: #f8d7da;
  color: #721c24;
}

.order-date {
  color: #999;
  font-size: 12px;
  margin-bottom: 12px;
}

.order-items {
  color: #666;
  font-size: 13px;
  margin-bottom: 12px;
  padding-bottom: 12px;
  border-bottom: 1px solid #eee;
}

.order-amount {
  font-weight: 700;
  color: #cda34f;
  font-size: 18px;
  margin-bottom: 15px;
}

.order-actions {
  display: flex;
  gap: 8px;
  margin-top: auto;
}

.btn {
  flex: 1;
  padding: 8px 12px;
  border: none;
  border-radius: 4px;
  font-size: 12px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s;
  text-align: center;
  text-decoration: none;
  display: flex;
  align-items: center;
  justify-content: center;
}

.btn-primary {
  background: linear-gradient(180deg, #cda34f, #b0852b);
  color: white;
}

.btn-primary:hover {
  transform: translateY(-1px);
  box-shadow: 0 4px 12px rgba(205,163,79,0.3);
}

.btn-secondary {
  background: #f5f5f5;
  color: #333;
  border: 1px solid #ddd;
}

.btn-secondary:hover {
  background: #efefef;
}

.btn-danger {
  background: #ffebee;
  color: #d32f2f;
  border: 1px solid #ffcdd2;
}

.btn-danger:hover {
  background: #ffcdd2;
}

@media (max-width: 768px) {
  .orders-grid {
    grid-template-columns: 1fr;
  }

  .order-actions {
    flex-direction: column;
  }

  .btn {
    width: 100%;
  }
}
</style>

<div class="orders-container">
  <div class="orders-header">
    <h1 class="orders-title">📦 My Orders</h1>
    <p class="orders-subtitle"><?php echo count($orders); ?> order(s) found</p>
  </div>

  <?php if (empty($orders)): ?>
    <div class="empty-state">
      <div class="empty-icon">🛍️</div>
      <h2 class="empty-title">No Orders Yet</h2>
      <p class="empty-text">You haven't placed any orders. Start shopping now!</p>
      <a href="<?php echo base_url('/catalog.php'); ?>" class="empty-link">Continue Shopping →</a>
    </div>
  <?php else: ?>
    <div class="orders-grid">
      <?php foreach ($orders as $order): ?>
        <div class="order-card">
          <div class="order-header">
            <div class="order-number">Order #<?php echo e($order['id']); ?></div>
            <div class="order-status status-<?php echo strtolower($order['status']); ?>">
              <?php echo ucfirst($order['status']); ?>
            </div>
          </div>
          
          <div class="order-date">
            <?php echo date('M d, Y h:i A', strtotime($order['order_date'])); ?>
          </div>

          <div class="order-items">
            <?php
            $stmt = $mysqli->prepare("SELECT COUNT(*) as cnt FROM order_items WHERE order_id=?");
            $stmt->bind_param('i', $order['id']);
            $stmt->execute();
            $result = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            echo $result['cnt'] . ' item(s)';
            ?>
          </div>

          <div class="order-amount">₹<?php echo number_format($order['total']); ?></div>

          <div class="order-actions">
            <a href="<?php echo base_url('/track_order.php?id=' . $order['id']); ?>" class="btn btn-primary">Track</a>
            <?php if ($order['status'] === 'pending' || $order['status'] === 'confirmed'): ?>
                <a href="<?php echo base_url('/cancel_order.php?id=' . $order['id']); ?>" class="btn btn-danger">Cancel</a>
            <?php elseif ($order['status'] === 'delivered'): ?>
                <a href="<?php echo base_url('/return_product.php?id=' . $order['id']); ?>" class="btn btn-secondary">Return</a>
            <?php endif; ?>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>

  <div style="text-align: center; margin-top: 40px;">
    <a href="<?php echo base_url('/catalog.php'); ?>" style="color: #1976d2; text-decoration: none; font-weight: 600;">← Back to Shopping</a>
  </div>
</div>

<?php require 'includes/footer.php'; ?>
