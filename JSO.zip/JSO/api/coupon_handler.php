<?php
session_start();
require '../config/db.php';
require '../includes/functions.php';

header('Content-Type: application/json');

$action = $_GET['action'] ?? '';

// Apply coupon code
if ($action === 'apply_coupon') {
    $code = strtoupper(trim($_POST['coupon_code'] ?? ''));
    
    if (empty($code)) {
        echo json_encode(['success' => false, 'message' => 'Please enter a coupon code']);
        exit;
    }

    // Check if coupon exists and is valid
    $stmt = $mysqli->prepare("SELECT * FROM coupons WHERE code=? AND is_active=1 AND NOW() BETWEEN valid_from AND valid_till");
    $stmt->bind_param('s', $code);
    $stmt->execute();
    $coupon = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$coupon) {
        echo json_encode(['success' => false, 'message' => 'Invalid or expired coupon code']);
        exit;
    }

    // Check usage limit
    if ($coupon['max_uses'] !== -1 && $coupon['used_count'] >= $coupon['max_uses']) {
        echo json_encode(['success' => false, 'message' => 'Coupon usage limit exceeded']);
        exit;
    }

    // Check if already applied
    if (isset($_SESSION['applied_coupon']) && $_SESSION['applied_coupon']['code'] === $code) {
        echo json_encode(['success' => false, 'message' => 'Coupon already applied']);
        exit;
    }

    // Store coupon in session
    $_SESSION['applied_coupon'] = [
        'id' => $coupon['id'],
        'code' => $coupon['code'],
        'discount_type' => $coupon['discount_type'],
        'discount_value' => $coupon['discount_value'],
        'min_purchase' => $coupon['min_purchase']
    ];

    echo json_encode([
        'success' => true,
        'message' => 'Coupon applied successfully!',
        'discount' => $coupon['discount_value'],
        'type' => $coupon['discount_type']
    ]);
    exit;
}

// Remove coupon
if ($action === 'remove_coupon') {
    unset($_SESSION['applied_coupon']);
    echo json_encode(['success' => true, 'message' => 'Coupon removed']);
    exit;
}

// Get available offers
if ($action === 'get_offers') {
    $stmt = $mysqli->prepare("SELECT id, title, description, discount_type, discount_value, image_url FROM offers WHERE is_active=1 AND NOW() BETWEEN valid_from AND valid_till ORDER BY created_at DESC LIMIT 10");
    $stmt->execute();
    $offers = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    echo json_encode(['success' => true, 'offers' => $offers]);
    exit;
}

// Apply offer to cart
if ($action === 'apply_offer') {
    $offer_id = intval($_POST['offer_id'] ?? 0);
    
    if ($offer_id <= 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid offer']);
        exit;
    }

    $stmt = $mysqli->prepare("SELECT * FROM offers WHERE id=? AND is_active=1 AND NOW() BETWEEN valid_from AND valid_till");
    $stmt->bind_param('i', $offer_id);
    $stmt->execute();
    $offer = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$offer) {
        echo json_encode(['success' => false, 'message' => 'Invalid or expired offer']);
        exit;
    }

    $_SESSION['applied_offer'] = [
        'id' => $offer['id'],
        'title' => $offer['title'],
        'discount_type' => $offer['discount_type'],
        'discount_value' => $offer['discount_value'],
        'min_purchase' => $offer['min_purchase']
    ];

    echo json_encode([
        'success' => true,
        'message' => 'Offer applied!',
        'discount' => $offer['discount_value'],
        'type' => $offer['discount_type']
    ]);
    exit;
}

echo json_encode(['success' => false, 'message' => 'Invalid action']);
?>
