<?php
// Generate beautiful SVG jewelry images - simpler approach

$images = [
  'jewelry_gold_001.jpg' => [
    'title' => 'Gold Jewelry',
    'colors' => ['#FFD700', '#FDB813', '#FFC200'],
    'accent' => '#FF6B9D',
  ],
  'jewelry_gold_002.jpg' => [
    'title' => 'Gold Earrings',
    'colors' => ['#D4AF37', '#FFD700', '#F0E68C'],
    'accent' => '#FF1493',
  ],
  'jewelry_diamond_001.jpg' => [
    'title' => 'Diamond Ring',
    'colors' => ['#E0E0E0', '#FFFFFF', '#D3D3D3'],
    'accent' => '#00CED1',
  ],
  'jewelry_diamond_002.jpg' => [
    'title' => 'Diamond Necklace',
    'colors' => ['#F0F8FF', '#E8E8E8', '#DCDCDC'],
    'accent' => '#4169E1',
  ],
  'jewelry_platinum_001.jpg' => [
    'title' => 'Platinum Jewelry',
    'colors' => ['#E5E4E2', '#D0D0D0', '#C0C0C0'],
    'accent' => '#696969',
  ],
  'jewelry_platinum_002.jpg' => [
    'title' => 'Platinum Ring',
    'colors' => ['#F5F5F5', '#DCDCDC', '#A9A9A9'],
    'accent' => '#2F4F4F',
  ],
  'jewelry_gemstone_001.jpg' => [
    'title' => 'Ruby Jewels',
    'colors' => ['#E0115F', '#DC143C', '#FF1493'],
    'accent' => '#FFD700',
  ],
  'jewelry_gemstone_002.jpg' => [
    'title' => 'Sapphire Stones',
    'colors' => ['#0F52BA', '#4169E1', '#1E90FF'],
    'accent' => '#FFD700',
  ],
  'jewelry_silver_001.jpg' => [
    'title' => 'Silver Jewelry',
    'colors' => ['#C0C0C0', '#E8E8E8', '#D3D3D3'],
    'accent' => '#696969',
  ],
  'jewelry_silver_002.jpg' => [
    'title' => 'Silver Bracelet',
    'colors' => ['#D3D3D3', '#BEBEBE', '#A9A9A9'],
    'accent' => '#4A4A4A',
  ],
];

foreach($images as $filename => $data) {
  $filepath = __DIR__ . '/uploads/' . $filename;
  
  // Create beautiful SVG jewelry image
  $svg = <<<SVG
<?xml version="1.0" encoding="UTF-8"?>
<svg width="500" height="600" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="mainGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:{$data['colors'][0]};stop-opacity:1" />
      <stop offset="50%" style="stop-color:{$data['colors'][1]};stop-opacity:1" />
      <stop offset="100%" style="stop-color:{$data['colors'][2]};stop-opacity:1" />
    </linearGradient>
    <filter id="shadow" x="-50%" y="-50%" width="200%" height="200%">
      <feDropShadow dx="2" dy="4" stdDeviation="3" flood-opacity="0.3" />
    </filter>
    <radialGradient id="shine" cx="35%" cy="35%">
      <stop offset="0%" style="stop-color:#FFFFFF;stop-opacity:0.9" />
      <stop offset="50%" style="stop-color:#FFFFFF;stop-opacity:0.3" />
      <stop offset="100%" style="stop-color:#FFFFFF;stop-opacity:0" />
    </radialGradient>
  </defs>
  
  <!-- Background -->
  <rect width="500" height="600" fill="#F8F8F8"/>
  
  <!-- Decorative background pattern -->
  <circle cx="50" cy="50" r="30" fill="{$data['accent']}" opacity="0.05"/>
  <circle cx="450" cy="550" r="40" fill="{$data['accent']}" opacity="0.05"/>
  
  <!-- Main jewelry piece -->
  <g filter="url(#shadow)">
    <!-- Main body -->
    <ellipse cx="250" cy="250" rx="140" ry="170" fill="url(#mainGrad)"/>
    
    <!-- Shine overlay -->
    <ellipse cx="250" cy="220" rx="120" ry="140" fill="url(#shine)"/>
    
    <!-- Highlights -->
    <ellipse cx="200" cy="180" rx="45" ry="60" fill="#FFFFFF" opacity="0.5"/>
    <circle cx="280" cy="260" r="25" fill="#FFFFFF" opacity="0.3"/>
  </g>
  
  <!-- Main gem/accent stone -->
  <circle cx="250" cy="250" r="35" fill="{$data['accent']}" filter="url(#shadow)"/>
  <circle cx="250" cy="250" r="30" fill="{$data['accent']}"/>
  <circle cx="240" cy="240" r="12" fill="#FFFFFF" opacity="0.6"/>
  
  <!-- Secondary gem accents -->
  <circle cx="150" cy="180" r="15" fill="{$data['accent']}" opacity="0.7"/>
  <circle cx="350" cy="180" r="15" fill="{$data['accent']}" opacity="0.7"/>
  <circle cx="130" cy="280" r="12" fill="{$data['accent']}" opacity="0.5"/>
  <circle cx="370" cy="280" r="12" fill="{$data['accent']}" opacity="0.5"/>
  
  <!-- Decorative flourishes -->
  <g opacity="0.2">
    <line x1="100" y1="150" x2="180" y2="160" stroke="{$data['accent']}" stroke-width="2"/>
    <line x1="400" y1="140" x2="320" y2="160" stroke="{$data['accent']}" stroke-width="2"/>
    <line x1="80" y1="350" x2="150" y2="360" stroke="{$data['accent']}" stroke-width="2"/>
  </g>
  
  <!-- Text content -->
  <text x="250" y="480" font-size="24" font-weight="bold" text-anchor="middle" fill="#333" font-family="Arial, sans-serif">
    {$data['title']}
  </text>
  <text x="250" y="520" font-size="16" text-anchor="middle" fill="#666" font-family="Arial, sans-serif" letter-spacing="1">
    Premium Quality ✨
  </text>
  <text x="250" y="560" font-size="12" text-anchor="middle" fill="#999" font-family="Arial, sans-serif">
    Hand-Crafted Jewelry
  </text>
</svg>
SVG;

  // Save SVG
  file_put_contents($filepath . '.svg', $svg);
  
  // Convert SVG to base64 or use as data URI
  // For now, we'll create a simple redirect to the SVG
  echo "Created: " . $filename . " (SVG)\n";
}

echo "\nAll beautiful jewelry SVG images created successfully!\n";
echo "Images are stored in: uploads/\n";
?>
