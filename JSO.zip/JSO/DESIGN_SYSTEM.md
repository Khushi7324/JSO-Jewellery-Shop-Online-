# JSO Unified Design System

## Overview
This document describes the unified design system implemented across the JSO (Jewelry Shop Online) website. All pages now use consistent fonts, colors, spacing, shadows, and component styles.

## Design System Files

### 1. `assets/css/design-system.css`
The core design system file that defines:
- **Fonts**: Primary (Inter) and Secondary (Playfair Display)
- **Color Palette**: Primary, Secondary, Accent, Background, Text colors
- **Spacing System**: Consistent spacing scale (xs, sm, md, lg, xl, 2xl, 3xl)
- **Border Radius**: Unified radius values
- **Shadows**: Consistent shadow system
- **Transitions**: Standardized animation timings
- **Base Styles**: Typography, buttons, forms, links, tables, cards

### 2. `assets/css/style.css`
Main stylesheet that uses the design system variables for:
- Header and navigation
- Search bar
- Product grids
- Banners
- Filters
- Responsive breakpoints

### 3. `assets/css/background.css`
Background styles and animations using design system colors:
- Gold glitter background (home)
- Diamond shine background (product pages)
- Dark elegant background (admin)
- Moving gradient background (user pages)

## Color Palette

### Primary Colors
- **Primary**: `#1a73e8` (Blue)
- **Primary Dark**: `#1557b0`
- **Primary Light**: `#4285f4`

### Secondary Colors
- **Secondary**: `#cda34f` (Gold)
- **Secondary Dark**: `#b0852b`
- **Secondary Light**: `#e5c97a`

### Accent Colors
- **Accent**: `#764ba2` (Purple)
- **Accent Light**: `#9b6fc9`

### Background Colors
- **Background Primary**: `#ffffff`
- **Background Secondary**: `#f8f9fa`
- **Background Tertiary**: `#f0f2f5`
- **Background Dark**: `#1a1a2e`
- **Background Dark Secondary**: `#16213e`

### Text Colors
- **Text Primary**: `#1a1a1a`
- **Text Secondary**: `#4a4a4a`
- **Text Tertiary**: `#6c6c6c`
- **Text Light**: `#ffffff`
- **Text Muted**: `#999999`

## Typography

### Primary Font (Body, Buttons, Forms)
- **Font Family**: `'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif`
- Used for: Body text, buttons, forms, navigation, tables

### Secondary Font (Headings, Logo)
- **Font Family**: `'Playfair Display', Georgia, serif`
- Used for: Headings (h1-h6), logo, accent text

## Components

### Buttons
All buttons use consistent styling with hover effects:
- `.btn` or `.btn-primary`: Primary blue gradient button
- `.btn-secondary`: Secondary outline button
- `.btn-accent`: Gold accent button
- `.btn-outline`: Transparent outline button
- `.btn-danger`: Red error button
- Sizes: `.btn-sm`, `.btn-lg`

### Forms
- Consistent input styling with focus states
- Unified border radius and padding
- Focus states use primary color with shadow

### Links
- Primary color by default
- Hover states with underline
- Variants: `.link-secondary`, `.link-light`

### Cards
- White background with shadow
- Hover effects with elevation
- Consistent border radius

### Tables
- Clean, modern styling
- Hover states for rows
- Consistent header styling

## Spacing System

All spacing uses CSS variables:
- `--spacing-xs`: 4px
- `--spacing-sm`: 8px
- `--spacing-md`: 16px
- `--spacing-lg`: 24px
- `--spacing-xl`: 32px
- `--spacing-2xl`: 48px
- `--spacing-3xl`: 64px

## Responsive Breakpoints

- **Desktop**: Default (1024px+)
- **Tablet**: 768px - 1024px
- **Mobile**: < 768px
- **Small Mobile**: < 480px

## Implementation

### Loading Order
CSS files must be loaded in this order:
1. `design-system.css` (defines all variables)
2. `style.css` (uses variables)
3. `background.css` (uses variables)

### Usage in PHP
All pages should include the design system via `includes/header.php`:
```php
<link rel="stylesheet" href="<?php echo base_url('/assets/css/design-system.css'); ?>">
<link rel="stylesheet" href="<?php echo base_url('/assets/css/style.css'); ?>">
<link rel="stylesheet" href="<?php echo base_url('/assets/css/background.css'); ?>">
```

### Using CSS Variables
Instead of hardcoded colors, use variables:
```css
/* Bad */
color: #1a73e8;

/* Good */
color: var(--color-primary);
```

## Benefits

1. **Consistency**: All pages use the same fonts, colors, and spacing
2. **Maintainability**: Change colors/fonts in one place (design-system.css)
3. **Scalability**: Easy to add new components using the system
4. **Responsive**: Built-in responsive design patterns
5. **Accessibility**: Proper contrast ratios and focus states

## Future Enhancements

- Add dark mode support
- Expand component library (modals, dropdowns, etc.)
- Add animation utilities
- Create component documentation

