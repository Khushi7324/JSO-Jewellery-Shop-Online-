<?php
$body_class = 'moving-gradient-bg';
require 'includes/header.php';
$id = isset($_GET['id'])?intval($_GET['id']):0;
$stmt = $mysqli->prepare("SELECT o.*, u.name as customer FROM orders o LEFT JOIN users u ON o.user_id=u.id WHERE o.id=?");
$stmt->bind_param('i',$id); $stmt->execute(); $order = $stmt->get_result()->fetch_assoc(); $stmt->close();
if(!$order){ echo '<p>Order not found</p>'; require 'includes/footer.php'; exit; }
$stmt = $mysqli->prepare("SELECT oi.*, p.name FROM order_items oi LEFT JOIN products p ON p.id=oi.product_id WHERE oi.order_id=?"); $stmt->bind_param('i',$id); $stmt->execute(); $items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();
?>
<div style="max-width:800px;margin:0 auto">
  <div style="background:#fff;padding:28px;border-radius:12px;box-shadow:0 12px 36px rgba(0,0,0,0.08)">
    <div style="text-align:center;margin-bottom:28px;padding-bottom:16px;border-bottom:2px solid #f0f0f0">
      <h2 style="margin:0 0 6px;color:var(--gold-dark)">Invoice</h2>
      <p style="margin:0;color:#666;font-size:14px">Order #<?=e($order['id'])?></p>
    </div>
    
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:24px;margin-bottom:28px">
      <div>
        <p style="font-weight:600;margin:0 0 6px;color:#333">Customer</p>
        <p style="margin:0;color:#666"><?=e($order['customer'])?></p>
      </div>
      <div>
        <p style="font-weight:600;margin:0 0 6px;color:#333">Order Date</p>
        <p style="margin:0;color:#666"><?=date('d M Y', strtotime($order['order_date']))?></p>
      </div>
      <div>
        <p style="font-weight:600;margin:0 0 6px;color:#333">Delivery Address</p>
        <p style="margin:0;color:#666"><?=e($order['address'])?><br>Pincode: <?=e($order['pincode'])?></p>
      </div>
      <div>
        <p style="font-weight:600;margin:0 0 6px;color:#333">Payment Details</p>
        <p style="margin:0;color:#666"><?=e($order['payment_mode'])?><br>Status: <span style="color:var(--gold-dark);font-weight:600"><?=e($order['payment_status'])?></span></p>
      </div>
    </div>
    
    <table style="width:100%;border-collapse:collapse;margin:20px 0">
      <tr style="background:#f9f7f5">
        <th style="padding:12px;text-align:left;font-weight:600;border-bottom:2px solid #e0e0e0">Product</th>
        <th style="padding:12px;text-align:center;font-weight:600;border-bottom:2px solid #e0e0e0">Qty</th>
        <th style="padding:12px;text-align:right;font-weight:600;border-bottom:2px solid #e0e0e0">Price</th>
      </tr>
      <?php foreach($items as $it): ?>
        <tr>
          <td style="padding:12px;border-bottom:1px solid #eee"><?=e($it['name'])?></td>
          <td style="padding:12px;text-align:center;border-bottom:1px solid #eee"><?=e($it['quantity'])?></td>
          <td style="padding:12px;text-align:right;border-bottom:1px solid #eee">₹ <?=number_format($it['price']*$it['quantity'],2)?></td>
        </tr>
      <?php endforeach; ?>
    </table>
    
    <div style="text-align:right;padding-top:16px;border-top:2px solid #f0f0f0">
      <p style="margin:12px 0;font-size:18px"><strong style="color:var(--gold-dark)">Total: ₹ <?=number_format($order['total'],2)?></strong></p>
    </div>
    
    <div style="margin-top:28px;text-align:center;display:flex;gap:12px;justify-content:center">
      <button class="btn btn-glow" onclick="printInvoice()">🖨️ Print / Save as PDF</button>
      <a class="btn" href="<?php echo base_url('/'); ?>" style="text-decoration:none">← Back to Home</a>
    </div>
  </div>
</div>

<?php require 'includes/footer.php';?>