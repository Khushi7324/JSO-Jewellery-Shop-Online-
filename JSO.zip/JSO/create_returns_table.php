<?php
require __DIR__ . '/config/db.php';

$sql = <<<SQL
CREATE TABLE IF NOT EXISTS returns (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  user_id INT NOT NULL,
  items_json JSON NULL,
  reason VARCHAR(255) NOT NULL,
  notes TEXT NULL,
  return_total DECIMAL(10,2) DEFAULT 0,
  status ENUM('pending','approved','rejected','received','refunded') DEFAULT 'pending',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_returns_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  CONSTRAINT fk_returns_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
SQL;

if ($mysqli->query($sql) === true) {
    echo "returns table ready.\n";
} else {
    echo "Error creating returns table: " . $mysqli->error . "\n";
    exit(1);
}
?>

