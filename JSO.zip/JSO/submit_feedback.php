<?php
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/functions.php';

header('Content-Type: application/json; charset=utf-8');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

if (session_status() !== PHP_SESSION_ACTIVE) session_start();
if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Authentication required']);
    exit;
}

$token = $_POST['csrf_token'] ?? '';
if (!validate_csrf_token($token)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid CSRF token']);
    exit;
}

$product_id = isset($_POST['product_id']) ? (int)$_POST['product_id'] : 0;
$rating = isset($_POST['rating']) && $_POST['rating'] !== '' ? (float)str_replace(',', '.', $_POST['rating']) : null;
$comment = trim($_POST['comment'] ?? '');

if ($product_id <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Missing product_id']);
    exit;
}

$user_id = $_SESSION['user_id'];
$res = add_feedback($user_id, $product_id, $rating, $comment);
if ($res === false) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Failed to submit feedback']);
    exit;
}

echo json_encode(['success' => true, 'feedback_id' => $res]);
exit;
